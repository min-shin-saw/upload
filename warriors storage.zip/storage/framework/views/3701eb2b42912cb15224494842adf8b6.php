<?php
    use App\Helpers\CustomHelpers;
?>

<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?> / <a
                    href="<?php echo e(route('students.index')); ?>"><?php echo e(__('admin/breadcrumb/student.students')); ?></a> /
            </span><?php echo e(__('common-breadcrumb.detail')); ?></h4>


        <h5 class="card-header mb-3 text-primary"><?php echo e(__('admin/admin-student.student_detail')); ?></h5>

        <div class="row">
            <!-- User Sidebar -->
            <div class="col-xl-4 col-lg-5 col-md-5 border-1 border-md-0 mb-4">
                <!-- User Card -->
                <div class="card ">
                    <div class="card-body">
                        <div class="user-avatar-section">
                            <div class="d-flex align-items-center flex-column">
                                <?php if($student->image): ?>
                                    <img class="img-fluid rounded mb-3 mt-4" src="<?php echo e(get_file($student->image)); ?>"
                                        height="120" width="120" alt="User avatar" />
                                <?php else: ?>
                                    <?php echo getFillerImage(120, 120); ?>

                                <?php endif; ?>
                                <div class="user-info text-center">
                                    <h4><?php echo e($student->name); ?></h4>
                                </div>
                            </div>
                        </div>

                        <div class="info-container">
                            <ul class="list-unstyled">
                                <li class="mb-3">
                                    <span
                                        class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-student.student_code_deatail')); ?>:</span>
                                    <span><?php echo e($student->student_code); ?></span>
                                </li>
                                <li class="mb-3">
                                    <span
                                        class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-student.region')); ?>:</span>
                                    <span><?php echo e($student->region() ?? '-'); ?></span>
                                </li>
                                <li class="mb-3">
                                    <span
                                        class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-student.email_detail')); ?>:</span>
                                    <span><?php echo e(isGeneratedString($student->email, 'user') ? '-' : $student->email); ?></span>
                                </li>
                                <li class="mb-3">
                                    <span
                                        class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-student.phone_detail')); ?>:</span>
                                    <span class=""><?php echo e($student->phone); ?></span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- /User Card -->
            </div>
            <!--/ User Sidebar -->

            <!-- User Content -->
            <div class="col-xl-8 col-lg-7 col-md-7 border-0 border-md-1 mb-4">
                <div class="card">
                    <div class="card-body">
                        <ul class="list-unstyled mb-4">
                            <li class="mb-3">
                                <span
                                    class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-student.other_name')); ?>:</span>
                                <span><?php echo e($student->other_name ?? '-'); ?></span>
                            </li>
                            <li class="mb-3">
                                <span
                                    class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-student.emergency_phone')); ?>:</span>
                                <span><?php echo e($student->emergency_phone ?? '-'); ?></span>
                            </li>
                            <li class="mb-3">
                                <span
                                    class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-student.date_of_birth')); ?>:</span>
                                <span><?php echo e($student->formattedDobDate() ?? '-'); ?></span>
                            </li>
                            <li class="mb-3">
                                <span class="fw-semibold text-heading me-2"><?php echo e(__('common.gender')); ?>:</span>
                                <span><?php echo e($student->gender); ?></span>
                            </li>

                            <li class="mb-3">
                                <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-student.allergy')); ?>:</span>
                                <span><?php echo e($student->allergy ?? '-'); ?></span>
                            </li>
                            <li class="mb-3">
                                <span
                                    class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-student.nationality')); ?>:</span>
                                <span><?php echo e($student->nationality ?? '-'); ?></span>
                            </li>
                            <li class="mb-3">
                                <span
                                    class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-student.family_doctor')); ?>:</span>
                                <span><?php echo e($student->family_doctor ?? '-'); ?></span>
                            </li>

                            <li class="mb-3">
                                <span
                                    class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-student.nrc_detail')); ?>:</span>
                                <span
                                    class=""><?php echo e($student->nrcInfo?->nrc_code .
                                        '/' .
                                        $student->nrcInfo?->name_en .
                                        App\Models\School\Nrc::TYPES[$student->nrc_type] .
                                        $student->nrc); ?></span>
                            </li>
                        </ul>
                        <ul class="list-unstyled mb-0">
                            

                            <li class="list-inline-item">

                                <?php if($student->vaccine_recorded == 0): ?>
                                    <a href="<?php echo e(route('students.vaccine-records.create', $student)); ?>"
                                        class="btn btn-primary btn-sm rounded-sm"><?php echo e(__('admin/vaccine-records/common.vaccine_record_add_button')); ?></a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('students.vaccine-records.index', $student)); ?>"
                                        class="btn btn-primary btn-sm rounded-sm"><?php echo e(__('admin/vaccine-records/common.vaccine_record_view_button')); ?></a>
                                <?php endif; ?>

                            </li>

                            <li class="list-inline-item">
                                <?php if(CustomHelpers::has_permission(Auth::user()->role->id, 'Student Health Examination Records List')): ?>
                                    <a href="<?php echo e(route('student-health-examination-records.index', $student)); ?>"
                                        class="btn btn-success  btn-sm rounded-sm">
                                        <?php echo e(__('admin/admin-health-examination.health_examination')); ?>

                                    </a>
                                <?php endif; ?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-12">
                <div class="accordion accordion-flush mb-4" id="accordionFlushExample">
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                                Student Remark
                            </button>
                        </h2>
                        <div id="flush-collapseOne" class="accordion-collapse collapse"
                            data-bs-parent="#accordionFlushExample">
                            <div class="accordion-body">
                                <textarea name="note" placeholder="<?php echo e(__('admin/vaccine-records/common.student_note_placeholder')); ?>"
                                    id="note"><?php echo isset($student) ? $student->student_note : ''; ?></textarea>

                                <button class="btn btn-primary btn-sm mt-2" id="note-save-btn"
                                    onclick="modifyStudentNote()">
                                    <?php if(!$student->student_note): ?>
                                        <?php echo e(__('common.save')); ?>

                                    <?php else: ?>
                                        <?php echo e(__('common.update')); ?>

                                    <?php endif; ?>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            

            <!--/ User Content -->

            <div class="col-md-6 border-1 border-md-0 mb-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="text-primary"><?php echo e(__('admin/admin-student.father_information')); ?></h5>
                        <li class="mb-3">
                            <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-student.name_detail')); ?>:</span>
                            <span><?php echo e($student->father_name); ?></span>
                        </li>
                        <li class="mb-3">
                            <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-student.nrc_detail')); ?>:</span>
                            <span><?php echo e($student->fatherNrcInfo?->nrc_code .
                                '/' .
                                $student->fatherNrcInfo?->name_en .
                                App\Models\School\Nrc::TYPES[$student->father_nrc_type] .
                                $student->father_nrc); ?></span>
                        </li>
                        <li class="mb-3">
                            <span
                                class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-student.phone_detail')); ?>:</span>
                            <span><?php echo e($student->father_phone ?? '-'); ?></span>
                        </li>
                        <li class="mb-3">
                            <span
                                class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-student.email_detail')); ?>:</span>
                            <span><?php echo e($student->father_email ?? '-'); ?></span>
                        </li>
                        <li class="mb-3">
                            <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-student.job')); ?>:</span>
                            <span><?php echo e($student->father_job ?? '-'); ?></span>
                        </li>
                    </div>
                </div>
            </div>

            <div class="col-md-6 border-1 border-md-0 mb-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="text-primary"><?php echo e(__('admin/admin-student.mother_information')); ?></h5>
                        <li class="mb-3">
                            <span
                                class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-student.name_detail')); ?>:</span>
                            <span><?php echo e($student->mother_name); ?></span>
                        </li>
                        <li class="mb-3">
                            <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-student.nrc_detail')); ?>:</span>
                            <span><?php echo e($student->motherNrcInfo?->nrc_code .
                                '/' .
                                $student->motherNrcInfo?->name_en .
                                App\Models\School\Nrc::TYPES[$student->mother_nrc_type] .
                                $student->mother_nrc); ?></span>
                        </li>
                        <li class="mb-3">
                            <span
                                class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-student.phone_detail')); ?>:</span>
                            <span><?php echo e($student->mother_phone ?? '-'); ?></span>
                        </li>
                        <li class="mb-3">
                            <span
                                class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-student.email_detail')); ?>:</span>
                            <span><?php echo e($student->mother_email ?? '-'); ?></span>
                        </li>
                        <li class="mb-3">
                            <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-student.job')); ?>:</span>
                            <span><?php echo e($student->mother_job ?? '-'); ?></span>
                        </li>
                    </div>
                </div>
            </div>

            <?php if($student->guardian): ?>
                <div class="col-md-6 border-1 border-md-0">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="text-primary"><?php echo e(__('admin/admin-student.guardian_information')); ?></h5>
                            <div class="row">
                                <div class="col-xl-4 col-lg-5 col-md-5 border-1 border-md-0">
                                    <div class="user-avatar-section">
                                        <div class="d-flex align-items-center flex-column">
                                            <?php if($student->guardian->image): ?>
                                                <img class="img-fluid rounded mb-3 mt-4"
                                                    src="<?php echo e(get_file($student->guardian?->image)); ?>" height="120"
                                                    width="120" alt="User avatar" />
                                            <?php else: ?>
                                                <?php echo getFillerImage(120, 120); ?>

                                            <?php endif; ?>
                                            
                                        </div>
                                    </div>

                                </div>

                                <div class="col-xl-8 col-lg-7 col-md-7 border-0 border-md-1">
                                    <li class="mb-3">
                                        <span
                                            class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-student.name_detail')); ?>:</span>
                                        <span><?php echo e($student->guardian?->name); ?></span>
                                    </li>
                                    <li class="mb-3">
                                        <span
                                            class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-student.email_detail')); ?>:</span>
                                        <span><?php echo e(isGeneratedString($student->guardian?->email, 'user') ? '-' : $student->guardian?->email); ?></span>
                                    </li>
                                    <li class="mb-3">
                                        <span
                                            class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-student.phone_detail')); ?>:</span>
                                        <span><?php echo e($student->guardian?->phone); ?></span>
                                    </li>
                                    <li class="mb-3">
                                        <span class="fw-semibold text-heading me-2"><?php echo e(__('common.gender')); ?>:</span>
                                        <span><?php echo e($student->guardian?->gender); ?></span>
                                    </li>
                                    <li class="mb-3">
                                        <span
                                            class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-student.nrc_detail')); ?>:</span>
                                        <span><?php echo e($student->guardian?->NrcInfo?->nrc_code .
                                            '/' .
                                            $student->guardian?->nrcInfo?->name_en .
                                            App\Models\School\Nrc::TYPES[$student->guardian?->nrc_type] .
                                            $student->guardian?->nrc); ?></span>
                                    </li>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="text-primary">Ferry Information</h5>
                        <div class="px-3">
                            <li class="mb-3">
                                <span class="fw-semibold text-heading me-2">Driver Name:</span>
                                <span><?php echo e($student->ferry->driver_name ?? '-'); ?></span>
                            </li>
                            <li class="mb-3">
                                <span class="fw-semibold text-heading me-2">Driver Phone:</span>
                                <span><?php echo e($student->ferry->driver_phone_number ?? '-'); ?></span>
                            </li>
                            <li class="mb-3">
                                <span class="fw-semibold text-heading me-2">Driver Address:</span>
                                <span><?php echo e($student->ferry->driver_address ?? '-'); ?></span>
                            </li>
                            <li class="mb-3">
                                <span class="fw-semibold text-heading me-2">Plate Number:</span>
                                <span><?php echo e($student->ferry->car_platenumber ?? '-'); ?></span>
                            </li>
                            <li class="mb-3">
                                <span class="fw-semibold text-heading me-2">Township :</span>
                                <span><?php echo e($student->ferry->township->name ?? '-'); ?></span>
                            </li>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/tinymce/tinymce.min.js')); ?>"></script>
    <script>
        $(function() {
            tinymce.init({
                selector: '#note',
            });
        })
    </script>
    <script>
        function modifyStudentNote() {
            storeStudentNote();
        }

        async function storeStudentNote() {
            try {
                const response = await fetch('<?php echo e(route('students.student-note.store', $student)); ?>', {
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                    },
                    method: 'POST',
                    body: JSON.stringify({
                        note: tinyMCE.activeEditor.getContent()
                    })
                });

                if (!response.ok) {
                    throw new Error('Network response was not ok');
                } else {
                    Swal.fire({
                        title: 'Success!',
                        text: 'Student Note has been updated!',
                        icon: 'success',
                        customClass: {
                            confirmButton: 'btn btn-primary waves-effect waves-light'
                        },
                        buttonsStyling: false
                    });

                    document.getElementById('note-save-btn').innerHTML = 'Update';
                }

            } catch (error) {
                console.error('Error fetching guides : ', error);
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/students/show.blade.php ENDPATH**/ ?>