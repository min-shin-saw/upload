<div>
    <a 
    data-bs-toggle="tooltip" data-bs-placement="top" title="Edit"
    href="<?php echo e(route('transaction-names.edit',$id)); ?>" 
    class="btn btn-sm btn-icon btn-primary waves-effect waves-light <?php echo e($id == 1  ? 'disabled' : ''); ?>">
        <span class="mdi mdi-playlist-edit"></span>
    </a>
    <button
    type="button"
    data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"
    class="btn btn-sm btn-icon btn-danger waves-effect waves-light delete-btn <?php echo e($id == 1  ? 'disabled' : ''); ?>"
    data-url="<?php echo e(route('transaction-names.destroy',$id)); ?>"
    >
            <span class="mdi mdi-delete-circle"></span>
    </button>
    <script src="<?php echo e(asset('assets/js/delete-sweet-alert.js')); ?>"></script>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/transaction-name/action.blade.php ENDPATH**/ ?>