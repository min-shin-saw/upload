<?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
<script
    src="<?php echo e(asset('assets/js/mss-repeater/mss-repeater.js')); ?>"
></script>

<div>
    <form
    class="mt-3"
    action="<?php echo e(route('additional-transaction.store',$enrollment)); ?>"
    method="post"
    id="additional-transaction-form"
    >
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('admin.enrollments.form-partials.additionalTransaction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <button type="button" id="additional-submit-btn" class="btn btn-primary btn-sm float-end">Submit</button>
    </form>
</div>

<script>
    $(function () {
        
        const transactionNames = <?php echo json_encode($transactionNames, 15, 512) ?>;

        function checkAllDueDateAreFilled (){
            let condition = true;
            $('[name="additional_due_dates[]"]').each(function() {
                if(! $(this).val()) condition = false;
            });
            return condition;
        }

        $('#additional-submit-btn').click(function (e) {

            e.preventDefault();

            let currentDate = new Date().toISOString().split('T')[0];

            let previousDate = $('[name="additional_due_dates[]:first"]').val(); ;

            let isDateNull = checkAllDueDateAreFilled();

            if(isDateNull) {
                $('#additional-transaction-form').submit();
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Errors!',
                    html: `<b class="text-secondary">All due date are required!</b>`,
                    customClass: {
                        confirmButton: 'btn btn-primary waves-effect'
                    }
                });
            }
        });


        function getFormattedDate() {
            const today = new Date();
            const year = today.getFullYear();
            const month = String(today.getMonth() + 1).padStart(2, '0');
            const day = String(today.getDate()).padStart(2, '0');
            return `${year}-${month}-${day}`;
        }

        $('.additional-payments-status').change(function (e) {
            e.preventDefault();
            const additionalDueDateInput = $(this)
                .closest('.row')
                .find('.additional-due-dates');
            if ($(this).val() === 'pending') {
                additionalDueDateInput.val(getFormattedDate());
            } else {
                additionalDueDateInput.val(null);
            }
        });

        $(document).on('click','.addition-payment-delete-btn', function(e){
            if ($("#additional-fee-repeater .additional-repeater-item").length > 1) {
                $(this).closest(".additional-repeater-item").remove();
                updateDeleteButtonStatus();
            }
        })

        $(document).on('change','.transaction-name-dropdown',function(e) {

            e.preventDefault();

            let currentValue = $(this).val();
            let value;

            transactionNames.forEach((el) => el.id == currentValue ? value = el.value : null);

            //  Get the root element and fint the value input and set the value
            $(this).parent().parent().parent().find('.additional-transaction-value-input').val(value);

            // Get an array of selected values
            let selectedValues = $('.transaction-name-dropdown').map(function() {
                return $(this).val();
            }).get();

            });

        // Add repeater item
        $(".addition-add-payment-btn-ini").click(function () {
            var newItem = $("#additional-fee-repeater .additional-repeater-item:first").clone(true);
            newItem.find("input").val("");
            newItem.find("additional_payments_status").val('unpaid')
            newItem.find("transaction-name-dropdown").val('')
            $("#additional-fee-repeater").append(newItem);
            updateDeleteButtonStatus();
            $('.addition-add-payment-btn-ini').not(':first').remove();
        });

        // Function to update delete button status
        function updateDeleteButtonStatus() {
            var deleteButtons = $(".addition-payment-delete-btn");
            deleteButtons.prop("disabled", false); // Enable all delete buttons
            deleteButtons.first().prop("disabled", true); // Disable the delete button for the first row
        }

        // Initial update of delete button status
        updateDeleteButtonStatus();
    })
</script>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/enrollments/add-additional-transaction.blade.php ENDPATH**/ ?>