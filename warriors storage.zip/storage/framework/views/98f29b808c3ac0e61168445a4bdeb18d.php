<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?> / <a href="<?php echo e(route('overall-gradings.index')); ?>"><?php echo e(__('admin/breadcrumb/overall-grading.overall_grading')); ?></a> /</span> </h4>
        <div class="table-responsive text-nowrap">
            <?php echo $dataTable->table(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <?php echo e($dataTable->scripts(attributes: ['type' => 'module'])); ?>


    <script type="module">
        $(document).ready(function() {

            let courses = <?php echo json_encode($courses, 15, 512) ?>;
            let firstRow = $('.dt-buttons').parent().addClass('d-flex');
            let urlParams = new URLSearchParams(window.location.search);

            function setBatchOptions(courseId){
                let html;
                html += '<option value="">Select Batch</option>'
                courses.map(course=>{
                    if(course.id == courseId){
                        course.batches.map(batch=>{
                            html += `<option value="${batch.id}" data-date="${batch.start_date}">${batch.name}</option>`
                        })
                    }
                    if(courseId == ''){
                        $('#batch-select').val('<option value="">Select Batch</option>');
                    }
                })
                $('#batch-select').html(html);
            }


            firstRow.append(`
                <form class="col-8 d-flex" action="<?php echo e(route('overall-gradings.index')); ?>" method="get" >
                    <?php echo csrf_field(); ?>
            
                    <div class="col-3  ms-3 form-floating form-floating-outline">
                        <select name="course" id="course-select" class="form-select  select2  subject-select" style="height:43px ;" >
                            <option value="">Select Course</option>
                            ${courses.map(course => `<option value="${course.id}">${course.name}</option>`)}
                        </select>
                    </div>
                    <div class="col-3  ms-3 form-floating form-floating-outline">
                        <select name="batch" id="batch-select" class="form-select  select2  subject-select" style="height:43px ;" >
                            <option value="">Select Batch</option>
                        </select>
                    </div>
                    <div class="col-3  ms-3 form-floating form-floating-outline">
                        <select name="is_approved" id="approve-select" class="form-select  select2  subject-select" style="height:45px ;" >
                            <option value="">Select Approve</option>
                            <option value="1">Approved</option>
                            <option value="0">UnApproved</option>
                        </select>
                    </div>
                    <button id="filter" class="btn btn-primary btn-sm  ms-2">
                        filter
                    </button>
                </form>
            `)

            $('#course-select').on('change', function() {
               setBatchOptions($(this).val());
            })

            if (urlParams.size != 0) {
               
                const courseParam = urlParams.get('course')
                const batchParam = urlParams.get('batch')
                const approveParam = urlParams.get('is_approved')
                $('#course-select').val(courseParam);
                setBatchOptions(courseParam);
                $('#batch-select').val(batchParam);
                $('#approve-select').val(approveParam);
            }

        })
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/overall-gradings/index.blade.php ENDPATH**/ ?>