<div class="text-start">

    <button
        type="button"
        class="btn btn-sm btn-icon btn-danger waves-effect waves-light delete-btn"
        data-url="<?php echo e(route('ferry-students.destroy',$id)); ?>"
    >
            <span class="mdi mdi-delete-circle" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"></span>
    </button>
    <script src="<?php echo e(asset('assets/js/delete-sweet-alert.js')); ?>"></script>

</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/ferry-students/action.blade.php ENDPATH**/ ?>