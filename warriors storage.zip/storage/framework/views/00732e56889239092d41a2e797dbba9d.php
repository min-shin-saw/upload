<?php
    use App\Helpers\CustomHelpers;
?>

<?php $__env->startSection('container'); ?>
    <h4 class="text-primary"><?php echo e(__("school-admin-dashboard.school_admin_dashboard")); ?></h4>
    <!-- Gamification Card -->

    <div class="col-12 col-md-6 col-lg-3 ">
        <a class="d-block" href="<?php echo e(route('students.index')); ?>">
            <div class="card h-100 rounded-0">
                <div class="row">
                    <div class="col-6">
                    <div class="card-body">
                        <div class="card-info mb-3 py-2 mb-lg-1 mb-xl-3">
                        <h5 class="mb-3 mb-lg-2 mb-xl-3 text-nowrap"><?php echo e(__('school-admin-dashboard.total_students')); ?> </h5>
                        </div>
                        <div class="d-flex align-items-end flex-wrap gap-1">
                        <h4 class="mb-0 me-2"><?php echo e($totalStudent); ?></h4>
                        </div>
                    </div>
                    </div>
                    <div class="col-6 text-end d-flex align-items-end justify-content-center">
                    <div class="card-body pb-0 pt-3 position-absolute bottom-0">
                        <img
                        src="<?php echo e(asset('assets/img/illustrations/faq-illustration.png')); ?>"
                        alt="Ratings"
                        width="90" />
                    </div>
                    </div>
                </div>
            </div>
        </a>
    </div>

    <div class="col-12 col-md-6 col-lg-3 ">
        <a href="<?php echo e(route('guardians.index')); ?>" class="d-block">
            <div class="card h-100 rounded-0">
                <div class="row">
                    <div class="col-6">
                    <div class="card-body">
                        <div class="card-info mb-3 py-2 mb-lg-1 mb-xl-3">
                        <h5 class="mb-3 mb-lg-2 mb-xl-3 text-nowrap"><?php echo e(__('school-admin-dashboard.total_guardians')); ?></h5>
                        </div>
                        <div class="d-flex align-items-end flex-wrap gap-1">
                        <h4 class="mb-0 me-2"><?php echo e($totalGuardian); ?></h4>
                        </div>
                    </div>
                    </div>
                    <div class="col-6 text-end d-flex align-items-end justify-content-center">
                    <div class="card-body pb-0 pt-3 position-absolute bottom-0">
                        <img
                        src="<?php echo e(asset('assets/img/illustrations/card-session-illustration.png')); ?>"
                        alt="Ratings"
                        width="78" />
                    </div>
                    </div>
                </div>
            </div></a>
    </div>

    <div class="col-12 col-md-6 col-lg-3 ">
        <a href="<?php echo e(route('teachers.index')); ?>" class="d-block">
            <div class="card h-100 rounded-0">
                <div class="row">
                    <div class="col-6">
                    <div class="card-body">
                        <div class="card-info mb-3 py-2 mb-lg-1 mb-xl-3">
                        <h5 class="mb-3 mb-lg-2 mb-xl-3 text-nowrap"><?php echo e(__('school-admin-dashboard.total_teachers')); ?></h5>
                        </div>
                        <div class="d-flex align-items-end flex-wrap gap-1">
                        <h4 class="mb-0 me-2"><?php echo e($totalTeacher); ?></h4>
                        </div>
                    </div>
                    </div>
                    <div class="col-6 text-end d-flex align-items-end justify-content-center">
                    <div class="card-body pb-0 pt-3 position-absolute bottom-0">
                        <img
                        src="<?php echo e(asset('assets/img/illustrations/card-ratings-illustration.png')); ?>"
                        alt="Ratings"
                        width="95" />
                    </div>
                    </div>
                </div>
                </div>
        </a>
    </div>

    

    <div class="col-12 col-md-6 col-lg-3 ">
        <a href="<?php echo e(route('courses.index')); ?>" class="d-block">
            <div class="card h-100 rounded-0">
                <div class="row">
                    <div class="col-6">
                    <div class="card-body">
                        <div class="card-info mb-3 py-2 mb-lg-1 mb-xl-3">
                        <h5 class="mb-3 mb-lg-2 mb-xl-3 text-nowrap"><?php echo e(__('school-admin-dashboard.total_courses')); ?></h5>
                        </div>
                        <div class="d-flex align-items-end flex-wrap gap-1">
                        <h4 class="mb-0 me-2"><?php echo e($totalCourse); ?></h4>
                        </div>
                    </div>
                    </div>
                    <div class="col-6 text-end d-flex align-items-end justify-content-center">
                    <div class="card-body pb-0 position-absolute bottom-0">
                        <img
                        class="ml-auto"
                        src="<?php echo e(asset('assets/img/illustrations/course.png')); ?>"
                        alt="Ratings"
                        width="90" />
                    </div>
                    </div>
                </div>
            </div>
        </a>
    </div>

    <div class="col-12 col-md-6 col-lg-3 ">
        <a href="<?php echo e(route('subjects.index')); ?>" class="d-block">
            <div class="card h-100 rounded-0">
                <div class="row">
                    <div class="col-6">
                    <div class="card-body">
                        <div class="card-info mb-3 py-2 mb-lg-1 mb-xl-3">
                        <h5 class="mb-3 mb-lg-2 mb-xl-3 text-nowrap"><?php echo e(__('school-admin-dashboard.total_subjects')); ?></h5>
                        </div>
                        <div class="d-flex align-items-end flex-wrap gap-1">
                        <h4 class="mb-0 me-2"><?php echo e($totalSubject); ?></h4>
                        </div>
                    </div>
                    </div>
                    <div class="col-6 text-end d-flex align-items-end justify-content-center">
                    <div class="card-body pb-0 position-absolute bottom-0">
                        <img
                        class="ml-auto"
                        src="<?php echo e(asset('assets/img/illustrations/subject.png')); ?>"
                        alt="Ratings"
                        width="90" />
                    </div>
                    </div>
                </div>
            </div>
        </a>
    </div>

    


    <div class="col-12">
        <h4 class="text-primary mt-4"><?php echo e(__("school-admin-dashboard.reminders")); ?></h4>
       <div class="row mt-4">
            <div
                class="col-md-6  p-2"

            >
                <div class="bg-white rounded p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5><?php echo e(__('school-admin-dashboard.teacher_license_expiration')); ?></h5>
                    </div>
                    <div class="thin-scrollbar overflow-auto my-2" style="height : 300px;">
                        <?php if($teachers->count() > 0): ?>
                            <table class="table">
                                <tr>
                                    <th>
                                        <?php echo e(__('school-admin-dashboard.teacher_license_expiration_name')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('school-admin-dashboard.teacher_license_expiration_date')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('school-admin-dashboard.expire_in')); ?>

                                    </th>
                                </tr>

                                <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php echo e($value->name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($value->teacher_license_expiration_date); ?>

                                        </td>
                                        <td class="">
                                            <span class="badge <?php echo e($value->date_in_different > 3 ? 'bg-warning' : 'bg-danger'); ?>"> <?php echo e($value->date_in_different > 0 ? $value->date_in_different .' days' : 'Today'); ?></span>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        <?php else: ?>
                            <div class="d-flex  flex-column align-items-center justify-content-center" style="height: 80%;">
                                <img src="<?php echo e(asset('assets/img/like.png')); ?>"  class="mt-5" alt="" style="width: 80px;height:80px;">
                                <h6 class="mt-5 text-secondary">No License Are Going To Expire</h6>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="d-flex pt-3 justify-content-end">
                        <div class="d-flex align-items-center me-3">
                            <div class="bg-danger rounded-circle me-2" style="width: 10px;height:10px;" ></div>
                            <span><?php echo e(__('school-admin-dashboard.close')); ?></span>
                        </div>
                        <div class="d-flex align-items-center">
                            <div class="bg-warning rounded-circle me-2" style="width: 10px;height:10px;" ></div>
                            <span><?php echo e(__('school-admin-dashboard.almost')); ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "General Reminder")): ?>
            <div class="col-md-6  p-2">
               <div class="bg-white rounded p-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5>
                            <?php echo e(__('school-admin-dashboard.general_reminders')); ?>

                        </h5>
                    </div>
                    <div class="thin-scrollbar overflow-auto my-2" style="height : 300px;">
                        <?php if($reminders->count() > 0): ?>
                            <table class="table">
                                <tr>
                                    <th>
                                        <?php echo e(__('school-admin-dashboard.general_reminder_name')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('school-admin-dashboard.general_reminder_date')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('school-admin-dashboard.to_reach')); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__('school-admin-dashboard.priority')); ?>

                                    </th>
                                </tr>

                                <?php $__currentLoopData = $reminders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php echo e($value->name); ?>

                                        </td>

                                        <td>
                                            <?php echo e($value->formattedDate()); ?>

                                        </td>
                                        <td class="d-flex justify-content-center">
                                            <span class="badge <?php echo e($value->date_in_different > 3 ? 'text-warning' : 'text-danger'); ?>"> <?php echo e($value->date_in_different > 0 ? $value->date_in_different .' days' : 'Today'); ?></span>
                                        </td>
                                        <td class="">
                                            <?php echo $value->generatePriorityUi(); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        <?php else: ?>
                            <div class="d-flex  flex-column align-items-center justify-content-center" style="height: 80%;">
                                <img src="<?php echo e(asset('assets/img/like.png')); ?>"  class="mt-5" alt="" style="width: 80px;height:80px;">
                                <h6 class="mt-5 text-secondary">No Reminders</h6>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="d-flex pt-3 justify-content-end">
                        <div class="d-flex align-items-center me-3">
                            <div class="bg-danger rounded-circle me-2" style="width: 10px;height:10px;" ></div>
                            <span><?php echo e(__('school-admin-dashboard.close')); ?></span>
                        </div>
                        <div class="d-flex align-items-center">
                            <div class="bg-warning rounded-circle me-2" style="width: 10px;height:10px;" ></div>
                            <span><?php echo e(__('school-admin-dashboard.almost')); ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
       </div>
    </div>
    <style>
        /* Set the width of the scrollbar to 8px */
        .thin-scrollbar::-webkit-scrollbar {
            width: 4px;
        }

        /* Set the background color of the scrollbar to transparent */
        .thin-scrollbar::-webkit-scrollbar-track {
            background: transparent;
        }

        /* Set the thumb color of the scrollbar to #888 */
        .thin-scrollbar::-webkit-scrollbar-thumb {
            background-color: #bebebe;
            border-radius: 30px;
        }

        /* Set the border radius of the scrollbar to 4px */
        .thin-scrollbar::-webkit-scrollbar-thumb:hover {
            background-color: #555;
        }
    </style>
    <!--/ Gamification Card -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>

    $(function () {
        if(<?php echo json_encode(request('success'), 15, 512) ?>) {
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: 'Changed Successfully',
                customClass: {
                    confirmButton: 'btn btn-success waves-effect'
                }
            });
        }
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/dashboards/dashboard.blade.php ENDPATH**/ ?>