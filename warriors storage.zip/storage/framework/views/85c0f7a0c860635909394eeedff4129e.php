<?php $__env->startSection('container'); ?>
    <div class="col-12">
        <h4 class="fw-bold py-3 mb-4">
            <span class="text-muted fw-light">
                Dashboard /
                <a href="<?php echo e(route('announcements.index')); ?>">
                    School Announcement
                </a> /
            </span>
            Create
        </h4>

        <div class="card p-4">
            <h5 class="card-header">Announcement Edit</h5>

            <div class="card-body">
                <form
                method="POST"
                enctype="multipart/form-data"
                action="<?php echo e(route('announcements.update',$announcement)); ?>"
                >
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-floating form-floating-outline mb-4">
                                <input
                                name="title"
                                type="text"
                                class="form-control"
                                id="title"
                                placeholder="title"
                                value="<?php echo e($announcement->title); ?>"
                                required
                                >
                                <label for="title">Announcement Title</label>
                            </div>
                        </div>

                        <div class="col-12 mb-4">
                            <h5>
                                <?php echo e(__('admin/admin-lesson.description')); ?>

                            </h5>

                            <textarea
                            name="description"
                            class="form-control"
                            id="description"
                            placeholder="Enter Description"><?php echo e($announcement->description); ?></textarea>
                        </div>

                        <div>
                            <div class="d-flex align-items-center gap-3 mb-3">
                                <h5 class="p-0 m-0">Files</h5>
                                <button
                                type="button"
                                id="repeater-add-btn"
                                class="btn btn-icon btn-label-success waves-effect"
                                >
                                    <i class="mdi mdi-plus me-1"></i>
                                </button>
                            </div>

                            <div class="row mb-3">
                                <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3 mb-3">
                                        <?php if($content->type === 'image'): ?>
                                            <img
                                            class="w-100 border"
                                            src="<?php echo e($content->content); ?>"
                                            >
                                        <?php elseif($content->type === 'zip'): ?>
                                            <img
                                            class="w-100 border"
                                            src="<?php echo e(asset('assets/img/placeholders/zip-logo-placeholder.png')); ?>" alt="">
                                        <?php elseif($content->type === 'pdf'): ?>
                                            <img
                                            class="w-100 border"
                                            src="<?php echo e(asset('assets/img/placeholders/pdf-logo-placeholder.png')); ?>" alt="">
                                        <?php endif; ?>

                                        <div class="mt-3 d-flex gap-2 align-items-center mb-0">
                                            <a
                                            target="blank"
                                            href="<?php echo e($content->content); ?>"
                                            class="btn btn-label-primary"
                                            >
                                                <i class="mdi mdi-eye me-1"></i>
                                            </a>

                                            <button
                                            type="button"
                                            data-url="<?php echo e(route('content.delete',$content->id)); ?>"
                                            class="btn btn-label-danger waves-effect api-del"
                                            >
                                                <i class="mdi mdi-close me-1"></i>
                                            </button>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <div id="file-repeater" class="row">

                            </div>
                        </div>
                    </div>
                    <div class="mt-3 d-flex justify-content-between">
                        <a href="<?php echo e(route('announcements.index')); ?>" class="btn btn-outline-secondary">
                            <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
                            <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('common.back')); ?></span>
                        </a>

                        <button class="btn btn-primary ms-2" id="submit-btn" type="button">
                            Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/dropify/dropify.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/tinymce/tinymce.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/mss-repeater/mss-repeater.js')); ?>"></script>

<script>
    $(function () {
        $('.dropify').dropify();

        tinymce.init({
            selector: '#description',
        });

        $('#repeater-add-btn').click(function (e) {
            e.preventDefault();

            $('#file-repeater').append(`
                <div class="col-md-3 mb-3">
                    <input
                    type="file"
                    name="contents[]"
                    class="dropify"
                    >
                    <div class="mt-3 d-flex align-items-center mb-0">
                        <button
                        type="button"
                        class="btn btn-label-danger waves-effect repeater-del"
                        >
                            <i class="mdi mdi-close me-1"></i>
                        </button>
                    </div>
                </div>
            `);

            $('.dropify').dropify();

            $('.repeater-del').click(function (e) {
                e.preventDefault();

                $($(this).parent().parent()).remove();
            });
        });

        $('.api-del').click(function (e) {
            e.preventDefault();

            const url    = $(this).data('url');
            const parent = $(this).parent().parent();

            console.log(url);


            $.ajax({
                type: "get",
                url: url,
                dataType: "json",
                success: function (response) {
                    parent.remove();
                }
            });
        });
    });
</script>

<?php echo MssValidation::script([
    'request'   => new App\Http\Requests\UpdateAnnouncementRequest(),
]); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dropify/dropify.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/announcements/edit.blade.php ENDPATH**/ ?>