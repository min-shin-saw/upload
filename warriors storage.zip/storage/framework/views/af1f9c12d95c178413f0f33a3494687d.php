<?php $__env->startSection('container'); ?>
  <div class="container-xxl flex-grow-1 container-p-y">
    <div class="card">
        <div class="card-header">
            <div>
                <h4 class="text-primary">Exam Result</h4>
            </div>
            <div class="row">
                <div 
                        id="dropdown-section" 
                        class="col d-flex"
                >

                    
                    <div class="form-group w-50">
                        <label for="batch_status">Status</label>
                        <select id="status-select" class="form-control" name="batch_status"  aria-label="Default select example">
                            <option value="null" selected>Select Status</option>
                            <?php $__currentLoopData = App\Models\Learning\Batch::STATUS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>" > <?php echo e($value); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    
                    <div class="form-group w-50 ms-4">
                        <label for="batch_status">Course</label>
                        <select id="course-select" class="form-control" aria-label="Default select example">
                            <option value="null"  selected>Select Course</option>
                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div 
                    class="col d-flex align-items-end justify-content-end " 
                    id="search-section"
                >
                    <input id="search-input"  class="form-control w-50 me-2" type="text" placeholder="Search" aria-label="Search">
                </div>
            </div>
        </div>
        <div class="card-body">
            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Batches</th>
                    <th scope="col"> </th>
                  </tr>
                </thead>
                <tbody id="content">
                </tbody>
            </table>
        </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script>

    $(document).ready(function() {

       /** 
        *   This state is for filtering options
        */
        let state  = {
            status : 'finished',
            course : null,
            search : ''
        }

       /**
        *   This function is to resolve the route() in balde to get the url 
        */
        let getRoute = (course,batch)=>{
            let url =  `<?php echo e(route('exam-results.studentslist',["course"=> ":course" , "batch"=> ":batch"])); ?>`
            url = url.replace(':course',course)
            url = url.replace(':batch',batch)
            return url;
        }


       /**
        *   Get all batches that are enrolled 
        */
        let batches  = <?php echo json_encode($batches, 15, 512) ?>;

       /**
        *   Set the finished batches as default
        */
        $('#status-select').val('finished');

        function renderTableRowWithFilteredData(state) {

           /**
            *   Reset the html
            */
            $('#content').html('');

           /*
            *   Data array that will be shown in UI
            */
            let filteredData = batches.filter((batch) => {
                return (
                    (state.status != null ? batch.status == state.status : true) &&
                    (state.course != null  ? batch.course.id == state.course : true) &&
                    (state.search != '' ? batch.name.toLowerCase().includes(state.search.toLowerCase()) : true)
                );
            });

           /**
            *   Create HTML element and store in html for DOM
            */
            let html = '';
            filteredData.forEach((data) => {
                let innerText = data.name + ' ( ' + data.course.name + ' ) ';
                html += `
                <tr class="pointer-on-hover">
                    <td scope="row">${innerText}</td>
                    <td class="d-flex justify-content-center">
                        <a href="${getRoute(data.course.id,data.id)}" class="btn btn-sm btn-icon btn-success waves-effect waves-light">
                            <span class="mdi mdi-checkbox-marked"></span>
                        </a>
                    </td>
                </tr>`;
            });

           /**
            *  Insert created HTML to DOM (tbody)
            */
            $('#content').html(html);
        }

       /**
        *   Default render
        */

        renderTableRowWithFilteredData(state);

        /*
        *   Event handlers
        */

        $('#status-select').change(function(){
            state.status = $(this).val() == 'null'  ? null  :  $(this).val();
            renderTableRowWithFilteredData(state);
        });

        $('#course-select').change(function(){
            state.course = $(this).val() == 'null' ? null :  $(this).val();
            renderTableRowWithFilteredData(state);
        });

        $('#search-input').on('input', function(){
            state.search = $(this).val() == '' ? '' : $(this).val();
            renderTableRowWithFilteredData(state);
        });
    });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/exam-results/index.blade.php ENDPATH**/ ?>