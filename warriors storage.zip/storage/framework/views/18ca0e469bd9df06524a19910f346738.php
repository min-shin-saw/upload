<nav class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
    id="layout-navbar">
    <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
        <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
            <i class="mdi mdi-menu mdi-24px"></i>
        </a>
    </div>

    <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">

        <!-- Search -->
        <!-- <div class="navbar-nav align-items-center">
            <div class="nav-item navbar-search-wrapper mb-0">
                <a class="nav-item nav-link search-toggler fw-normal px-0" href="javascript:void(0);">
                    <i class="mdi mdi-magnify mdi-24px scaleX-n1-rtl"></i>
                    <span class="d-none d-md-inline-block text-muted">Search (Ctrl+/)</span>
                </a>
            </div>
        </div> -->
        <!-- /Search -->

        <ul class="navbar-nav flex-row align-items-center ms-auto">
            <!-- Language -->
            <li class="nav-item  dropdown me-1 me-xl-0">
                <button id="language-dropdown" class="nav-link btn btn-text-secondary rounded-pill btn-icon dropdown-toggle hide-arrow"
                    href="javascript:void(0);" data-bs-toggle="dropdown">
                    <i class="mdi mdi-translate mdi-24px"></i>
                </button>
                <ul id="language-menu" class="dropdown-menu dropdown-menu-end"
                    style="
                        right:10px;
                        top: 50px;
                        display: none;
                    ">
                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('change-language', 'en')); ?>" >
                            <span class="align-middle">English</span>
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('change-language', 'myanmar')); ?>" >
                            <span class="align-middle">မြန်မာ</span>
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('change-language', 'thai')); ?>" >
                            <span class="align-middle">ไทย</span>
                        </a>
                    </li>
                </ul>
            </li>

            <!-- Notification -->

            <li class="nav-item dropdown-notifications navbar-dropdown dropdown me-2 me-xl-1">
                <a id="getNotificationsButton" class="nav-link btn btn-text-secondary rounded-pill btn-icon dropdown-toggle hide-arrow"
                    href="#" data-bs-toggle="dropdown" data-bs-auto-close="outside"
                    aria-expanded="false">
                    <i class="mdi mdi-bell-outline mdi-24px"></i>

                    <span id="newNotiEl" class="<?php echo e(auth()->user()->unreadNotifications->count() > 0 ? 'badge badge-dot bg-danger mt-2 border' : ''); ?> position-absolute top-0 start-50 translate-middle-y"></span>

                </a>
                <ul id="notificationDropdown" class="dropdown-menu dropdown-menu-end py-0"
                    style="
                        right:10px;
                        top: 50px;
                        display: none;
                    ">
                    <li class="dropdown-menu-header border-bottom">
                        <div class="dropdown-header d-flex align-items-center py-3">
                            <h6 class="mb-0 me-auto">
                                Notification

                                <span>| <a id="markAllAsRead" href="#">Mark all as read</a></span>
                            </h6>
                            <span id="unreadCountEl" class="badge rounded-pill bg-label-primary"><?php echo e(auth()->user()->unreadNotifications->count()); ?> New</span>
                        </div>
                    </li>
                    <li class="dropdown-notifications-list scrollable-container">
                        <ul id="notificationList" class="list-group list-group-flush">
                            <!-- Notification here -->
                        </ul>
                    </li>
                    
                </ul>
            </li>

            <!--/ Notification -->

            <!-- User -->
            <a class="nav-link" id="drop-down-open" href="javascript:void(0);">
                <div class="avatar avatar-online">
                    <img src="<?php echo e(auth()->user()->school_id == 0 ? asset('assets/img/avatars/1.png') :get_file(auth()->user()->school->logo)); ?>" alt class="w-px-40 h-auto rounded-circle" />
                </div>
            </a>

            <div
                class="card position-absolute "
                style="
                    right:10px;
                    top: 57px;
                    display: none;
                "
                id="drop-down-menu-manual"
            >
                <div class="card-body">
                    <a class="dropdown-item" href="javascript:void(0)">
                        <div class="d-flex">
                            <div class="flex-shrink-0 me-3">
                                <div class="avatar avatar-online">
                                    <img src="<?php echo e(asset('assets/img/avatars/1.png')); ?>" alt
                                        class="w-px-40 h-auto rounded-circle" />
                                </div>
                            </div>
                            <div class="flex-grow-1">
                                <span class="fw-semibold d-block">
                                    <?php echo e(auth()->user()->name); ?>

                                </span>
                                <small class="text-muted">Admin</small>
                            </div>
                        </div>
                    </a>

                    <div class="px-2 mt-3">
                        <a
                        class="dropdown-item text-secondary"
                        href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();"
                        >
                            <i class="mdi mdi-logout me-2"></i>
                            <span class="align-middle">Log Out</span>
                        </a>
                    </div>
                </div>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
            <!--/ User -->
        </ul>
    </div>

    <!-- Search Small Screens -->
    <div class="navbar-search-wrapper search-input-wrapper d-none">
        <input type="text" class="form-control search-input container-xxl border-0" placeholder="Search..."
            aria-label="Search..." />
        <i class="mdi mdi-close search-toggler cursor-pointer"></i>
    </div>
</nav>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/layout/shared/navbar.blade.php ENDPATH**/ ?>