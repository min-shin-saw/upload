<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4">
            <span class="text-muted fw-light">Admin /
                <?php if( App\Helpers\CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Admin") ): ?>
                <a href="<?php echo e(route('schools.index')); ?>">Schools</a>
                <?php else: ?>
                    Schools
                <?php endif; ?> /
            </span>
            Detail
        </h4>

        <div class="card mb-4">
            <h5 class="card-header">School Edit</h5>
            <div class="card-body">

                <form method="POST" action="<?php echo e(route('schools.update', $school)); ?>" enctype="multipart/form-data">

                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <div class="form-floating form-floating-outline">
                                <input name="name" type="text" class="form-control" id="floatingInput1" placeholder="Enter Username" aria-describedby="floatingInputHelp1" value="<?php echo e(isset($school) ? $school->name : ''); ?>" required>
                                <label for="floatingInput1"><?php echo e(__('admin/admin-school.name')); ?></label>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="form-floating form-floating-outline">
                                <select name="school_type" id="school_type" class="form-select form-select-lg" aria-describedby="floatingInputHelp2">
                                    <option
                                    <?php if($school->school_type === 'guardian'): echo 'selected'; endif; ?>
                                    value="guardian">Dependent</option>
                                    <option
                                    <?php if($school->school_type === 'independent'): echo 'selected'; endif; ?>
                                    value="independent">Independent</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <div class="form-floating form-floating-outline">
                                <input name="email" type="email" class="form-control" id="floatingInput3" placeholder="Enter Email" aria-describedby="floatingInputHelp3" value="<?php echo e(isset($school) ? $school->email : ''); ?>" required>
                                <label for="floatingInput3"><?php echo e(__('common.email')); ?></label>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="form-floating form-floating-outline">
                                <input name="phone" type="text" class="form-control" id="floatingInput4" placeholder="Enter Phone" aria-describedby="floatingInputHelp4" value="<?php echo e(isset($school) ? $school->phone : ''); ?>" required>
                                <label for="floatingInput4"><?php echo e(__('common.phone')); ?></label>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <div class="form-floating form-floating-outline">
                                <input
                                type="date"
                                class="form-control "
                                placeholder="YYYY-MM-DD"
                                name="founded_at"
                                value="<?php echo e($school->founded_at); ?>"
                                />
                                <label ><?php echo e(__('admin/admin-school.founded_at')); ?></label>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="form-floating form-floating-outline">
                                <input name="web_address" type="url" class="form-control" id="floatingInput6" placeholder="Enter School URL" aria-describedby="floatingInputHelp6" value="<?php echo e(isset($school) ? $school->web_address : ''); ?>" required>
                                <label for="floatingInput6"><?php echo e(__('admin/admin-school.url')); ?></label>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <div class="form-floating form-floating-outline">
                                <input name="address" id="floatingInput9" type="text" placeholder="Enter school Address" class="form-control" aria-describedby="floatingInputHelp9" value="<?php echo e(isset($school) ? $school->address : ''); ?>" required>
                                <label for="floatingInput9"><?php echo e(__('admin/admin-school.address')); ?></label>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="form-floating form-floating-outline">
                                <input name="description" id="floatingInput10" type="text" placeholder="Enter school Description" class="form-control" aria-describedby="floatingInputHelp10" value="<?php echo e(isset($school) ? $school->description : ''); ?>" required>
                                <label for="floatingInput10"><?php echo e(__('admin/admin-school.description')); ?></label>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <div class="form-floating form-floating-outline">
                                <input name="map_code" id="floatingInput7" type="text" placeholder="Enter school Map iframe" class="form-control" aria-describedby="floatingInputHelp7" value="<?php echo e(isset($school) ? $school->map_code : ''); ?>" required>
                                <label for="floatingInput7"><?php echo e(__('admin/admin-school.map_iframe')); ?></label>
                            </div>
                        </div>

                        <div class="col-md-6 mb-4">
                            <label class="form-label text-black">
                                School Picture
                            </label>
                            <input
                            type="file"
                            name="logo"
                            class="dropify"
                            data-default-file="<?php echo e(get_file($school->logo)); ?>"
                            >
                        </div>
                    </div>

                    <div class="mt-3 d-flex justify-content-between">
                        <a
                        <?php if(auth()->user()->school_id): ?>
                            href="<?php echo e(route('schools.show',$school)); ?>"
                        <?php else: ?>
                            href="<?php echo e(route('schools.index')); ?>"
                        <?php endif; ?>
                        class="btn btn-outline-secondary">
                            <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
                            <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('common.back')); ?></span>
                        </a>

                        <button class="btn btn-primary ms-2" id="submit-btn" type="button">
                            <?php echo e(__('common.submit')); ?>

                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/dropify/dropify.min.js')); ?>"></script>

    <script>
        $(function () {
            $('.dropify').dropify();
        });
    </script>

    <?php echo MssValidation::script([
        'request' => new App\Http\Requests\SchoolForm\UpdateSchoolRequest($school)
    ]); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dropify/dropify.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/schools/edit.blade.php ENDPATH**/ ?>