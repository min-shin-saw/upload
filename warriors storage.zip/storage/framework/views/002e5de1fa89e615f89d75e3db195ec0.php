<?php $__env->startSection('container'); ?>
    <div class="col-12">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?> / </span> <?php echo e(__('admin/users-guides/breadcrumb.admin_guide')); ?></h4>
        <div class="card">
            <div class="card-header">
                <h5><?php echo e(__('admin/users-guides/common.admin_detail_form_title')); ?></h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3">
                        <div class="row pb-3">
                            <div class="flex-grow-1 input-group input-group-merge rounded-pill">
                              <span class="input-group-text" ><i class="mdi mdi-magnify lh-1"></i></span>
                              <input type="text" id="searchInput" class="form-control chat-search-input" onkeyup="searchList()" placeholder="Search..." aria-label="Search..." aria-describedby="basic-addon-search31">
                            </div>
                        </div>
                        <ul id="list" class="list-group" style="max-height: 500px; overflow-y: auto;">
                        </ul>
                    </div>
                    <div class="col-md-9">
                        <div class="row pb-3" id="video">
                            <iframe class="card-img rounded" width="400" height="350" src="https://www.youtube.com/embed/" frameborder="0" allowfullscreen></iframe>
                        </div>
                        <div class="row">
                            <h4 id="title">Title</h4>
                        </div>
                        <div class="row pb-3">
                            <p id="description" class="card-text">Description</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        var htmlTag = $(':root');
        if(!htmlTag.hasClass('layout-menu-collapsed'))
        {
            htmlTag.addClass('layout-menu-collapsed');
        }
        getList();
        $('[data-toggle="tooltip"]').tooltip();
    });

    async function getList () {
      try {
        const response = await fetch('<?php echo e(route('guides.list')); ?>', {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            }
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

          const res = await response.json();
          bindList(res.data.lists);
          bindDetail(res.data.default);
      } catch (error) {
          console.error('Error fetching guides : ', error);
      }
    }

    function bindList(lists) {

        var list = document.getElementById('list');
        list.innerHTML = '';
        lists.forEach(element => {
            var li = document.createElement('li');
            li.classList.add('list-group-item');
            li.classList.add('list-group-item-action');
            li.classList.add('list-group-item-primary');
            li.classList.add('d-flex');
            li.classList.add('align-items-center');
            li.classList.add('cursor-pointer');
            li.onclick = function() {
                getDetail(element.id);
            };
            li.id = `li-${element.id}`
            li.innerHTML = `${element.title}`;
            li.setAttribute('data-toggle', 'tooltip');
            li.setAttribute('data-placement', 'top');
            li.setAttribute('title', `${element.title}`);
            list.appendChild(li);
        });
    }

    function searchList() {
        var input, filter, ul, li, a, i, txtValue;
        input = document.getElementById("searchInput");
        filter = input.value.toUpperCase();
        ul = document.getElementById("list");
        li = ul.getElementsByTagName("li");
        for (i = 0; i < li.length; i++) {
            txtValue = li[i].textContent || li[i].innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                li[i].classList.add('d-flex');
                li[i].style.display = "";
                // console.log(txtValue);
            } else {
                li[i].classList.remove('d-flex');
                li[i].style.display = "none";
                // console.log(txtValue);
            }
        }
    }

    function bindDetail(guide) {
        var title = document.getElementById('title');
        var description = document.getElementById('description');
        var video = document.getElementById('video');

        title.innerHTML = guide.title;
        description.innerHTML = guide.description;
        video.innerHTML = `<iframe class="card-img rounded" width="400" height="350" src="https://www.youtube.com/embed/${guide.content}" frameborder="0" allowfullscreen></iframe>`;
    }

    async function getDetail(id)
    {
        const url = `<?php echo e(route('guides.detail', ':id')); ?>`.replace(':id', id);
          try {
          const response = await fetch(url, {
              headers: {
                  'Accept': 'application/json',
                  'Content-Type': 'application/json',
                  'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
              }
          });

          if (!response.ok) {
              throw new Error('Network response was not ok');
          }

            const res = await response.json();
            bindDetail(res.data.guide);
        } catch (error) {
            console.error('Error fetching guide : ', error);
        }
    }

    function shortenString(inputString, maxLength) {
        if (inputString.length > maxLength) {
            return inputString.substring(0, maxLength - 3) + '...';
        }
        return inputString;
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/guides/index.blade.php ENDPATH**/ ?>