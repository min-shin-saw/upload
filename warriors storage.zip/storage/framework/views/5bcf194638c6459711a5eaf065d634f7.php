<?php
    $timetable = App\Models\School\Timetable::find($id);
    $overAll   = $timetable->overallTimetableFormat;
    $format    = $overAll->timetableFormat;
    $course    = $format->batch->course;
?>

<select
  id="timetable-select-<?php echo e($id); ?>"
  class="form-select"
  data-url="<?php echo e(route('timetables.subject.change',$id)); ?>"
>
    <?php $__currentLoopData = $course->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option
          <?php if($subject_id === $subject->id): echo 'selected'; endif; ?>
          value="<?php echo e($subject->id); ?>"
        >
            <?php echo e($subject->name); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<script>
    const selector = "#timetable-select-<?php echo e($id); ?>";

    $(selector).change(function (e) {
        e.preventDefault();

        const url = $(this).data('url');

        $.ajax({
            type: "GET",
            url: url,
            data: {
                subject_id: $(this).val()
            },
            dataType: "JSON",
            success: function (response) {
                Swal.fire({
                    icon: 'success',
                    title: 'Success!',
                    text: response.message,
                    customClass: {
                        confirmButton: 'btn btn-success waves-effect'
                    }
                });
            }
        });
    });
</script>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/timetables/subject-select.blade.php ENDPATH**/ ?>