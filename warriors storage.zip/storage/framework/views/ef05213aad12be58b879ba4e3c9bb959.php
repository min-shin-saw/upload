<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.dashboard')); ?> / <a
                        href="<?php echo e(route('tasks.index')); ?>">
                        <?php echo e(__('Homeworks')); ?>

                    </a> / </span><?php echo e($course->name); ?> / Homeworks</h4>

        <div class="card mt-3">
            <div
                class="d-flex justify-content-between card-body"
            >
                <div class="d-flex align-items-center gap-2">

                    <h5
                      style="margin:0%;padding:0%;"
                      class="text-primary"
                    >
                        <?php echo e($course->name); ?> -
                    </h5>

                    <select
                      data-url="<?php echo e(route('timetable-formats.show')); ?>"
                      style="font-size: 17px; width: fit-content !important;"
                      class="form-select"
                      id="batch-select"
                      name="batch_id"
                      form="filter-form"
                    >
                        <option value="">Select Batch</option>
                        <?php $__currentLoopData = $course->batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                            <?php if($batch->id == $single_batch->id): echo 'selected'; endif; ?>
                            value="<?php echo e($single_batch->id); ?>"
                            >
                                <?php echo e($single_batch->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                </div>
            </div>
        </div>

        <div class="card mt-3">
            <div class="table-responsive card-body text-nowrap">

                <form id="filter-form" action="" method="get" class="mb-3 d-flex gap-3">
                    <select
                      style="font-size: 15px !important; width: fit-content !important;"
                      class="form-select"
                      name="subject_id"
                      id="subject-select"
                    >
                        <option value="">Select Subject</option>
                        <?php $__currentLoopData = $course->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                            <?php if($subject->id == request('subject_id')): echo 'selected'; endif; ?>
                            value="<?php echo e($subject->id); ?>"
                            >
                                <?php echo e($subject->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <select
                      style="font-size: 15px !important; width: fit-content !important;"
                      class="form-select"
                      name="teacher_id"
                      id="teacher-select"
                    >
                        <option value="">Select Teacher</option>
                        <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                            <?php if($teacher->id == request('teacher_id')): echo 'selected'; endif; ?>
                            value="<?php echo e($teacher->id); ?>"
                            >
                                <?php echo e($teacher->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <div class="d-flex gap-2 align-items-center">
                        <button type="submit" class="btn btn-primary btn-sm" id="filter-btn">
                            <small style="text-transform:capitalize">
                                <span class="mdi mdi-filter-variant"></span> Filter
                            </small>
                        </button>

                        <?php if(request('subject_id') || request('teacher_id')): ?>
                        <a href="javascript:void(0)" id="clear-btn">
                            <small>
                                <b>Clear Filters</b>
                            </small>
                        </a>
                        <?php endif; ?>
                    </div>
                </form>
                <?php echo $dataTable->table(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <?php echo e($dataTable->scripts(attributes: ['type' => 'module'])); ?>

    <script type="module">
        $(function () {
            $('.dt-buttons').parent().parent().remove();
        });

        $('#clear-btn').on('click', function () {
            $('#subject-select').val('');
            $('#teacher-select').val('');
            $('#filter-form').submit();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/task/task-list-index.blade.php ENDPATH**/ ?>