<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.dashboard')); ?> / <a
                    href="<?php echo e(route('teachers.index')); ?>"><?php echo e(__('admin/breadcrumb/teacher.teachers')); ?></a> /
            </span><?php echo e(__('admin/breadcrumb/teacher.assign_course_subject')); ?></h4>
        <div class="card">
            <div class="d-flex align-items-center justify-content-between">
                <h5 class="card-header"><?php echo e(__('admin/admin-teacher.assign_course_subject_to_teacher')); ?> <?php echo e($teacher->name); ?>

                </h5>
                <button style="border-bottom-right-radius: 0 !important;border-top-right-radius: 0 !important"
                    class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal"><span
                        class="mdi mdi-plus"></span></button>
            </div>
            <div class="card-body">

                <div class="accordion accordion-flush" id="accordionFlushExample">
                    <?php $__currentLoopData = $data['courses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#course-<?php echo e($course->id); ?>" aria-expanded="false"
                                    aria-controls="course-<?php echo e($course->id); ?>">
                                    <b>Course :</b> <?php echo e($course->name); ?>

                                </button>
                            </h2>

                            <div id="course-<?php echo e($course->id); ?>" class="accordion-collapse collapse"
                                data-bs-parent="#accordionFlushExample">
                                <div class="accordion-body">
                                    <?php
                                        $tbatches = $data['batches']->filter(
                                            fn($batch) => $batch->course_id === $course->id,
                                        );
                                    ?>

                                    <?php $__currentLoopData = $tbatches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div>
                                            <div class="d-flex gap-3">
                                                <h6 class="mt-2">
                                                    <b>Batch :</b> <?php echo e($batch->name); ?>

                                                </h6>

                                                <div>
                                                    <a href="<?php echo e(route('teacher.timetables', [
                                                        'teacher' => $teacher->id,
                                                        'batch' => $batch->id,
                                                    ])); ?>"
                                                        title="Timetables"
                                                        class="
                                                      btn btn-sm btn-label-primary waves-effect
                                                    ">
                                                        Timetables
                                                    </a>
                                                </div>
                                            </div>

                                            <?php
                                                $items = $teacherAssignedSubjects->filter(
                                                    fn($record) => $record->batch_id === $batch->id &&
                                                        $record->course_id === $course->id,
                                                );
                                            ?>

                                            <div class="row mt-2">
                                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignedSubject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-sm-6 col-md-4 mb-4">
                                                        <div class="card">
                                                            <div class="row g-0">
                                                                <div style="height: 115px" class="col-md-6">
                                                                    <img style="object-fit: cover;"
                                                                        src="<?php echo e(get_file($assignedSubject->subject->image)); ?>"
                                                                        class="img-fluid rounded-start w-100 h-100"
                                                                        alt="<?php echo e($assignedSubject->subject->name); ?>">
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <div class="card-body d-flex flex-column ">
                                                                        <h6 class="card-title">
                                                                            <?php echo e($assignedSubject->subject->name); ?>

                                                                        </h6>

                                                                        <div>
                                                                            <a href="javascript:void(0)" title="Remove"
                                                                            class="
                                                                btn btn-sm btn-label-danger waves-effect delete-btn
                                                              "
                                                                            data-url="<?php echo e(route('teachers.course-subjects.destroy', $assignedSubject->id)); ?>">
                                                                            <span class="mdi mdi-delete-circle"></span>
                                                                        </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('teleport'); ?>
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Assign Course and Subjects</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('teachers.course-subjects.store', $teacher)); ?>" method="POST"
                        id="assign-course-and-subjects">
                        <?php echo csrf_field(); ?>
                        <div class="form-floating form-floating-outline mb-4">
                            <select id="select2Basic" class="select2 form-select form-select-lg" name="course_id">
                                <option value=""><?php echo e(__('admin/admin-teacher-assign-course.select_course')); ?></option>
                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($course->id); ?>">
                                        <?php echo e($course->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="select2Basic"><?php echo e(__('admin/admin-teacher-assign-course.select_course')); ?></label>
                        </div>

                        <div class="form-floating form-floating-outline mb-4">
                            <select name="batch_id" class="select2 form-select batch-select">
                                <option value=""><?php echo e(__('admin/admin-teacher-assign-course.select_batch')); ?></option>
                            </select>
                            <label for=""><?php echo e(__('admin/admin-teacher-assign-course.select_batch')); ?></label>
                        </div>

                        <div class="form-floating form-floating-outline">
                            <select id="select2Multiple" name="subjects[]" class="select2 form-select subject-select"
                                multiple>

                            </select>
                            <label
                                for="select2Multiple"><?php echo e(__('admin/admin-teacher-assign-course.select_subjects')); ?></label>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary waves-effect"
                        data-bs-dismiss="modal"><?php echo e(__('admin/admin-teacher-assign-course.close')); ?></button>
                    <button type="button" id="submit-btn" class="btn btn-primary"><?php echo e(__('common.submit')); ?></button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(function() {
            const batches = <?php echo json_encode($batches, 15, 512) ?>;
            const course_subjects = <?php echo json_encode($courseSubjects, 15, 512) ?>;
            const teacher_assigns = <?php echo json_encode($teacherAssignedSubjects, 15, 512) ?>;

            $('[name="course_id"]').change(function(e) {
                e.preventDefault();
                $('.batch-select').html('');
                $('.subject-select').html('');
                $('.batch-select').html(renderBatchSelect($(this).val()));
            });

            $('.batch-select').change(function(e) {
                e.preventDefault();
                $('.subject-select').html('');
                let course_id = $('[name="course_id"]').val();
                let batch_id = $(this).val();
                $('.subject-select').html(subjectSelectRender(course_id, batch_id));
            })

            const subjectSelectRender = (course_id, batch_id) => {
                let html = '';
                filterSubjects(course_id, batch_id).forEach(element => {
                    html += `
                        <option value="${element.subject_id}">${element.subject.name}</option>
                    `
                });
                return html;
            }

            const filterSubjects = (course_id, batch_id) => {
                let subjectIds = filterTeacherAssigns(course_id, batch_id).map(item => item.subject_id);
                let subjectsWithCourse = course_subjects.filter(course_subject => course_subject.course_id ==
                    course_id);
                return subjectsWithCourse.filter(item => !subjectIds.includes(item.subject_id));
                return subjectsWithCourse;
            }


            const renderBatchSelect = (course_id) => {
                html = '<option value="">Select Batch</option>';
                filterBatches(course_id).forEach(element => {
                    html += `
                    <option value="${element.id}">${element.name}</option>
                    `;
                });
                return html;
            }

            const filterBatches = (course_id) => {
                return batches.filter(batch => course_id == batch.course_id);
            }

            const filterTeacherAssigns = (course_id, batch_id) => {
                return teacher_assigns.filter(
                    el => (course_id == el.course_id && batch_id == el.batch_id)
                );
            }
        });
    </script>

    <?php echo MssValidation::script([
        'request' => new App\Http\Requests\TeacherForm\CreateTeacherAssignRequest(),
        'keys' => ['course_id', 'batch_id', 'subjects'],
        'select2' => true,
    ]); ?>


    <script>
        $(function() {
            $('.delete-btn').click(function(e) {
                e.preventDefault();
                const url = $(this).data('url');
                const parentNode = $(this).parent().parent().parent().parent().parent();
                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete it!',
                    customClass: {
                        confirmButton: 'btn btn-danger me-3 waves-effect waves-light',
                        cancelButton: 'btn btn-label-secondary waves-effect'
                    },
                    buttonsStyling: false
                }).then(function(result) {
                    if (result.value) {
                        $.ajax({
                            type: "GET",
                            url: url,
                            success: function(res) {
                                if (res.deleted) {
                                    Swal.fire({
                                        icon: 'success',
                                        title: 'Deleted!',
                                        text: res.message,
                                        customClass: {
                                            confirmButton: 'btn btn-success waves-effect'
                                        }
                                    });
                                    parentNode.hide();
                                }
                            },
                            error: function(e) {

                                Swal.fire({
                                        title: 'Error!',
                                        text: e.responseJSON.message,
                                        icon: 'error',
                                        showCancelButton: true,
                                        confirmButtonText: 'Force Delete!',
                                        customClass: {
                                            confirmButton: 'btn btn-danger me-3 waves-effect waves-light',
                                            cancelButton: 'btn btn-label-secondary waves-effect'
                                        },
                                        buttonsStyling: false
                                    })
                                    .then((result) => {
                                        if (result.value) {
                                            $.ajax({
                                                type: "GET",
                                                url: url + "?type=force",
                                                success: function(res) {
                                                    if (res.deleted) {
                                                        Swal.fire({
                                                            icon: 'success',
                                                            title: 'Deleted!',
                                                            text: res
                                                                .message,
                                                            customClass: {
                                                                confirmButton: 'btn btn-success waves-effect'
                                                            }
                                                        });
                                                        parentNode
                                                            .hide();
                                                    }
                                                },
                                                error: function(e) {
                                                    Swal.fire({
                                                        icon: 'error',
                                                        title: "error",
                                                        text: e
                                                            .responseJSON
                                                            .message,
                                                        confirmButtonText: 'OK',
                                                        customClass: {
                                                            confirmButton: 'btn btn-label-secondary waves-effect'
                                                        }
                                                    });
                                                }
                                            })

                                        }
                                    });

                            }
                        });

                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/teachers/course-subject.blade.php ENDPATH**/ ?>