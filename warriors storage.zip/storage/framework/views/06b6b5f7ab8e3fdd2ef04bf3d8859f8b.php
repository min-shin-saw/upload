<h1 hidden id="are_you_sure"><?php echo e(__('admin/swal-message/delete.are_you_sure')); ?></h1>
<h1 hidden id="yes_delete_it"><?php echo e(__('admin/swal-message/delete.yes_delete_it')); ?></h1>
<h1 hidden id="cancel"><?php echo e(__('admin/swal-message/delete.cancel')); ?></h1>
<h1 hidden id="you_wont_be_able_to_revert_this"><?php echo e(__('admin/swal-message/delete.you_wont_be_able_to_revert_this!')); ?></h1><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/langHelper/Swal-delete.blade.php ENDPATH**/ ?>