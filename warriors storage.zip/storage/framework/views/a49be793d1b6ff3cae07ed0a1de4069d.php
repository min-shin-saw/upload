<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?> / <a
                    href="<?php echo e(route('subjects.index')); ?>"><?php echo e(__("admin/breadcrumb/subject.subjects")); ?></a> / </span><?php echo e(__('common-breadcrumb.detail')); ?></h4>
        <div class="card">
        <div class="d-flex align-items-center justify-content-between">
            <h5 class="card-header mb-3 text-primary"><?php echo e(__('admin/admin-subject.subject_detail')); ?></h5>
            <div>
                <a style="border-bottom-right-radius: 0 !important;border-top-right-radius: 0 !important" class="btn mb-1 d-block btn-primary btn-sm" href="<?php echo e(route('section.index',$subject)); ?>"><?php echo e(__('Section')); ?></a>

                <a style="border-bottom-right-radius: 0 !important;border-top-right-radius: 0 !important"  class="btn btn-primary btn-sm" href="<?php echo e(route('lessons.index',$subject)); ?>"><?php echo e(__('admin/admin-subject.lessons')); ?></a>


            </div>
        </div>

            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-4">
                        <img class="img-fluid rounded" src="<?php echo e(get_file($subject->image)); ?>"
                            height="120" alt="User avatar" />
                    </div>

                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-body">
                                <div class="info-container">
                                    <li class="mb-3">
                                        <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-subject.name')); ?>:</span>
                                        <span><?php echo e($subject?->name); ?></span>
                                    </li>
                                    <li class="mb-3">
                                        <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-subject.price')); ?>:</span>
                                        <span><?php echo e($subject->formattedPrice()); ?> MMK</span>
                                    </li>
                                    <hr>
                                    <h5 class="text-primary"><?php echo e(__('admin/admin-subject.courses')); ?></h5>
                                    <div class="info-container">
                                        <?php $__currentLoopData = $subject->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="badge bg-danger"><?php echo e($course->name); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="col-12">
                        <div class="card mt-4">
                            <div class="card-body">
                                <h5 class="text-primary"><?php echo e(__('admin/admin-subject.description')); ?></h5>
                                <div class="info-container">
                                    <?php echo $subject->description; ?>

                                </div>
                            </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/subjects/show.blade.php ENDPATH**/ ?>