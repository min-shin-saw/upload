<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y ">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?> / </span><?php echo e(__('admin/breadcrumb/attendance-report.attendance-report')); ?></h4>
        <div class="table-responsive text-nowrap">
            <?php echo $dataTable->table(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <?php echo e($dataTable->scripts(attributes: ['type' => 'module'])); ?>

    <script type="text/javascript" src="<?php echo e(asset('assets/js/plugin/moment.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/plugin/daterange-picker.min.js')); ?>"></script>


    <script type="module">
        $(document).ready(function() {

            let courses = <?php echo json_encode($courses, 15, 512) ?>;
            let onMounted = (fn) => fn(); 
            let firstRow = $('.dt-buttons').parent().addClass('d-flex');
            let urlParams = new URLSearchParams(window.location.search);
            localStorage.setItem('queryParams', window.location.search);
            let start = '';
            let end =  '';

            function setBatchOptions(courseId){
                let html;
                html += '<option value="">Select Batch</option>'
                courses.map(course=>{
                    if(course.id == courseId){
                        course.batches.map(batch=>{
                            html += `<option selected value="${batch.id}" data-date="${batch.start_date}">${batch.name}</option>`
                        })
                    }
                    if(courseId == ''){
                        $('#batch-select').val('<option value="">Select Batch</option>');
                    }
                })
                $('#batch-select').html(html);
            }

            function setDatePicker(startDate , endDate) {
                $('input[name="dates"]').addClass('form-control col-4').daterangepicker({
                    startDate: startDate,
                    endDate: endDate,
                    minDate :  moment($('#batch-select option:selected').data('date')),
                    maxDate : moment(),
                });
            }

            firstRow.append(`
                <form class="col-8 d-flex" action="<?php echo e(route('attendance-reports.index')); ?>" method="get" >
                    <?php echo csrf_field(); ?>
            
                    <div class="col-3  ms-2 form-floating form-floating-outline">
                        <select name="course" id="course-select" class="form-select select2 subject-select" style="height:43px ;font-size: 0.75rem" >
                            <option value="">Select Course</option>
                            ${courses.map(course => `<option value="${course.id}">${course.name}</option>`)}
                        </select>
                    </div>
                    <div class="col-3  ms-2 form-floating form-floating-outline">
                        <select name="batch" id="batch-select" class="form-select subject-select" style="height:43px ;font-size: 0.75rem" >
                            <option value="">Select Batch</option>
                        </select>
                    </div>
                    <div class="col-4 ms-2 ">
                        <input type="text" name="dates" style="height:43px;" >
                    </div>
                    <div class="col-3  ms-1 form-floating form-floating-outline">
                        <select name="class" id="class-select" class="form-select class-select" style="height:43px ;font-size: 0.84rem" >
                            <option value="allClasses" id="allClasses">All Classes</option>
                            <option value="timeTable" id="timeTable">Classes</option>
                            <option value="liveSession" id="liveSession">Live Sessions</option>
                        </select>
                    </div>
                    <button id="filter" class="btn btn-primary btn-sm  ms-3">
                        filter
                    </button>
                    
                </form>
            `)

            // $('#select2basic').select2();
            // $('#course-select').select2({
            //     theme: 'bootstrap4',
            // });
           
            if (urlParams.size != 0) {
                const datesParam = urlParams.get('dates');
                const courseParam = urlParams.get('course');
                const batchParam = urlParams.get('batch');
                const datePart = datesParam.split(' - ');
                const classParam = urlParams.get('class');
                start = datePart[0];
                end =  datePart[1];
                $('#course-select').val(courseParam);
                setBatchOptions(courseParam);
                $('#batch-select').val(batchParam);
                $('#class-select').val(classParam);
            }else{
                start = moment();
                end = moment();
            }

            $('#course-select').on('change', function() {
               setBatchOptions($(this).val());
            })

            $('#batch-select').on('change', function() {
                let startDate = moment($('#batch-select option:selected').data('date'))
                setDatePicker(startDate, moment());
            })

            onMounted(()=>{
                setDatePicker(start,end);
            })
            

        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/attendance-reports/index.blade.php ENDPATH**/ ?>