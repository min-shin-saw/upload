<div class="col-12 mt-3">
    <div class="card">
        <div class="card-body table-responsive text-nowrap">
            <button
            style="
                border-bottom-right-radius: 0 !important;
                border-top-right-radius: 0 !important;
                position: absolute;
                right: 0;
                z-index: 1;
            "
            class="btn btn-primary btn-sm"
            id="add-transaction"
            data-url="<?php echo e(route('additional-transaction.add',$enrollment)); ?>"
            >
                <span class="mdi mdi-cash-plus"></span>
            </button>
            <?php echo $dataTable->table(); ?>

        </div>
    </div>
</div>

<?php $__env->startSection('teleport'); ?>
    <!-- Modal -->
  <div class="modal mx-auto" id="additional-transaction-modal"  aria-labelledby="additional-transactionLabel">
    <div style="width: 900px;" class="modal-dialog-centered mx-auto">
      <div  class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="additional-transactionLabel">
            Add Additional Transaction
          </h1>
          <button type="button" class="btn-close additional-transaction-modal-close"></button>
        </div>
        <div class="modal-body text-center">
        </div>
      </div>
    </div>
  </div>

  <div class="modal-mask"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .modal-mask{
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.6);
            height: 100vh;
            z-index: 1080;
            display: none;
        }

        #additional-transaction-modal {
            z-index: 1081;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/enrollments/transactions.blade.php ENDPATH**/ ?>