<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Admin / <a href="<?php echo e(route('admins.index')); ?>">Admins</a> / </span>Edit</h4>

        <div class="card mb-4">
            <h5 class="card-header">Admin Edit</h5>
            <div class="card-body">

                <form method="POST" action="<?php echo e(route('admins.update', $admin)); ?>">

                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>

                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <div class="form-floating form-floating-outline">
                                <input name="name" type="text" class="form-control" id="floatingInput1" placeholder="Enter Username" aria-describedby="floatingInputHelp1" value="<?php echo e(isset($admin) ? $admin->name : ''); ?>">
                                <label for="floatingInput1">Username</label>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="form-floating form-floating-outline">
                                <input name="email" type="email" class="form-control" id="floatingInput2" placeholder="Enter Email" aria-describedby="floatingInputHelp2" value="<?php echo e(isset($admin) ? $admin->email : ''); ?>">
                                <label for="floatingInput2">Email</label>
                            </div>
                        </div>
                    </div>

                    <div class="row">

                        <div class="col-md-6 mb-4">
                            <div class="form-floating form-floating-outline">
                                <select id="select2Multiple" name="schools[]" class="select2 form-select subject-select" multiple>
                                    <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php
                                            $status = in_array(
                                                $school->id,
                                                $admin
                                                    ->schools
                                                    ->pluck('id')
                                                    ->toArray()
                                            ) || $admin->school_id === $school->id;
                                        ?>

                                        <option
                                          value="<?php echo e($school->id); ?>"
                                          <?php if($status): echo 'selected'; endif; ?>
                                        >
                                            <?php echo e($school->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label for="select2Multiple"><?php echo e(__('School')); ?></label>
                            </div>
                        </div>

                        <div class="col-md-6 mb-4">
                            <div class="form-floating form-floating-outline">
                                <select
                                  id="select2Basic"
                                  class="select2 form-select form-select-lg"
                                  name="role_id"
                                  >
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                          value="<?php echo e($role->id); ?>"
                                          <?php if($role->id === $admin->role_id): echo 'selected'; endif; ?>
                                        >
                                          <?php echo e($role->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label for="select2Basic"><?php echo e(__('Role')); ?></label>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="mb-4 col-md-6 form-password-toggle fv-plugins-icon-container">
                            <div class="input-group input-group-merge">
                                <div class="form-floating form-floating-outline position-relative">
                                    <i
                                    class="mdi mdi-eye-off-outline position-absolute"
                                    style="
                                    cursor: pointer;
                                    right:4%;
                                    top: 15px;
                                    "
                                    ></i>
                                    <input
                                    name="password"
                                    class="form-control"
                                    type="password"
                                    id="password"
                                    placeholder="············"
                                    required
                                    >
                                    <label for="currentPassword">Password</label>
                                </div>
                            </div>
                        </div>

                        <div class="mb-4 col-md-6 form-password-toggle fv-plugins-icon-container">
                            <div class="input-group input-group-merge">
                                <div class="form-floating form-floating-outline position-relative">
                                    <i
                                    class="mdi mdi-eye-off-outline position-absolute"
                                    style="
                                    cursor: pointer;
                                    right:4%;
                                    top: 15px;
                                    "
                                    ></i>
                                    <input name="confirm_password" class="form-control" type="password" id="confirm_password" placeholder="············" required>
                                    <label for="currentPassword">Confirm Password</label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="mt-3 d-flex justify-content-between">
                        <a href="<?php echo e(route('admins.index')); ?>" class="btn btn-outline-secondary">
                            <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
                            <span class="align-middle d-sm-inline-block d-none">Previous</span>
                        </a>

                        <button class="btn btn-primary ms-2" id="submit-btn" type="button">
                            Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo MssValidation::script([
        'request'   => new App\Http\Requests\AdminForm\UpdateAdminRequest($admin),
        'select2'   => true
    ]); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/admins/edit.blade.php ENDPATH**/ ?>