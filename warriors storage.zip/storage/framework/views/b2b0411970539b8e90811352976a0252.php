<div class="row">
    <div class="col-md-3 mb-2">
        <div class="card shadow-none border-2">
            <div class="card-body text-center">
                <h4>Total Class</h4>
                <h5><?php echo e($timetableCount); ?></h5>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-2">
        <div class="card shadow-none border-2">
            <div class="card-body text-center">
                <h4>
                    Total Times
                </h4>
                <h5><?php echo e($formattedTime); ?></h5>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-2">
        <div class="card shadow-none border-2">
            <div class="card-body text-center">
                <h4>
                    Total Students
                </h4>
                <h5><?php echo e($studentCount); ?></h5>
            </div>
        </div>
    </div>

    <div class="col-md-3 mb-2">
        <div class="card shadow-none border-2">
            <div class="card-body text-center">
                <h4>
                    Total Subjects
                </h4>
                <h5><?php echo e($subjectCount); ?></h5>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/teachers/teacher-status.blade.php ENDPATH**/ ?>