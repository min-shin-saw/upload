<style>
.notification-wrapper {
    position: relative;
    display: inline-block;
}

.notification-dot {
    position: absolute;
    top: -2px;
    right: -3px;
    width: 8px;
    height: 8px;
    background-color: red;
    border-radius: 50%;
    box-shadow: 0 0 2px rgba(0, 0, 0, 0.5);
    z-index: 1;
    display: none; /* Hide by default */
}

.notification-wrapper.has-notification .notification-dot {
    display: block;
}

</style>

<div>
    <?php if($hasPending): ?>
        <div class="notification-wrapper has-notification">
    <?php else: ?>
        <div class="notification-wrapper">
    <?php endif; ?>
    
        <a href="<?php echo e(route('student-payments.show',$id)); ?>" class="btn btn-sm btn-icon btn-warning">
            <span class="mdi mdi-currency-usd" data-bs-toggle="tooltip" data-bs-placement="top" title="Show"></span>
            <span class="notification-dot"></span>
        </a>
    </div>
    
    <button
    type="button"
    class="btn btn-sm btn-icon btn-danger waves-effect waves-light delete-btn"
    data-url="<?php echo e(route('student-payments.destroy',$id)); ?>"
    >
            <span class="mdi mdi-delete-circle" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"></span>
    </button>


    
    <script src="<?php echo e(asset('assets/js/delete-sweet-alert.js')); ?>"></script>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/student-payment/action.blade.php ENDPATH**/ ?>