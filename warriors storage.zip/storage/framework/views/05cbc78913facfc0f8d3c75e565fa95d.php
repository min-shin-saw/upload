<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__("common-breadcrumb.dashboard")); ?> / <a
                    href="<?php echo e(route('teachers.index')); ?>"><?php echo e(__('admin/breadcrumb/teacher.teachers')); ?></a> / </span><?php echo e(__('common-breadcrumb.create')); ?></h4>
        <h5 class="card-header"><?php echo e(__('admin/admin-teacher.teacher_registration')); ?></h5>
        <div class="col-12 mb-4">
            <div class="bs-stepper wizard-numbered mt-2">
                <div class="bs-stepper-header">
                    <div class="step" data-target="#account-details">
                        <button type="button" class="step-trigger">
                            <span class="bs-stepper-circle"><i class="mdi mdi-check"></i></span>
                            <span class="bs-stepper-label">
                                <span class="bs-stepper-number">01</span>
                                <span class="d-flex flex-column gap-1 ms-2">
                                    <span class="bs-stepper-title"><?php echo e(__('admin/admin-teacher.teacher_info')); ?></span>
                                    <span class="bs-stepper-subtitle">Basic Teacher Details</span>
                                </span>
                            </span>
                        </button>
                    </div>
                    <div class="line"></div>
                    <div class="step" data-target="#personal-info">
                        <button type="button" class="step-trigger">
                            <span class="bs-stepper-circle"><i class="mdi mdi-check"></i></span>
                            <span class="bs-stepper-label">
                                <span class="bs-stepper-number">02</span>
                                <span class="d-flex flex-column gap-1 ms-2">
                                    <span class="bs-stepper-title"><?php echo e(__('admin/admin-teacher.guardian_info')); ?></span>
                                    <span class="bs-stepper-subtitle">Add Parents info</span>
                                </span>
                            </span>
                        </button>
                    </div>
                    <div class="line"></div>
                    <div class="step" data-target="#social-links">
                        <button type="button" class="step-trigger">
                            <span class="bs-stepper-circle"><i class="mdi mdi-check"></i></span>
                            <span class="bs-stepper-label">
                                <span class="bs-stepper-number">03</span>
                                <span class="d-flex flex-column gap-1 ms-2">
                                    <span class="bs-stepper-title"><?php echo e(__('admin/admin-teacher.education_info')); ?></span>
                                    <span class="bs-stepper-subtitle">Add Education info</span>
                                </span>
                            </span>
                        </button>
                    </div>
                </div>
                <div class="bs-stepper-content">
                    <form action="<?php echo e(route('teachers.store')); ?>" method="POST" enctype="multipart/form-data" id="teacher-form">
                        <?php echo csrf_field(); ?>
                        <!-- Teacher Info -->
                        <input type="hidden" value="<?php echo e(route('teacher-form.first-step')); ?>" id="first-step-validation">
                        <?php echo $__env->make('admin.teachers.form-partials.first-step-teacher-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <!-- Parents Info -->
                        <input type="hidden" value="<?php echo e(route('teacher-form.second-step')); ?>" id="second-step-validation">
                        <?php echo $__env->make('admin.teachers.form-partials.second-step-guardian-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <!-- Guardian Info -->
                        <input type="hidden" value="<?php echo e(route('teacher-form.third-step')); ?>" id="third-step-validation">
                        <?php echo $__env->make('admin.teachers.form-partials.third-step-edu-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset(
        'assets/js/form-handling/teacher-data-preparation/create-teacher-first-step.js'
    )); ?>"></script>

    <script src="<?php echo e(asset(
        'assets/js/form-handling/teacher-data-preparation/create-teacher-second-step.js'
    )); ?>"></script>

    <script src="<?php echo e(asset(
            'assets/js/form-handling/teacher-data-preparation/create-teacher-third-step.js'
    )); ?>"></script>

    <script src="<?php echo e(asset('assets/dropify/dropify.min.js')); ?>"></script>
    <script>
        $(function () {
            $('.marital_status').click(function() {
                if($(this).val() == "single"){
                    $(".husband_wife").hide();
                }else{
                    $(".husband_wife").show();
                }
            });

            //plugin
            $('.dropify').dropify({
                error : {
                    'fileExtension' : "<?php echo e(__('validation.image_type')); ?>",
                }
            });
            $('.date-input').flatpickr({
                monthSelectorType: 'static'
            });
        });
    </script>

    <script src="<?php echo e(asset(
        'assets/js/form-handling/teacher-form-validation.js'
    )); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dropify/dropify.min.css')); ?>">

    <style>
        .input-group .select2-selection.select2-selection--single {
            border-radius: 0;
        }
        .input-group .select2.select2-container.select2-container--default {
            padding: 0;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js-import'); ?>
<script src="<?php echo e(asset('assets/js/forms-extras.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/teachers/create.blade.php ENDPATH**/ ?>