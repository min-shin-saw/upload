<?php
    $currentModel = isset($subject) ? $subject : $course;
?>

<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4">
            <span class="text-muted fw-light">
                Dashboard /
                <?php if(isset($subject)): ?>
                <a href="<?php echo e(route('subjects.index')); ?>"><?php echo e($subject->name); ?></a>
                <?php else: ?>
                    <a href="<?php echo e(route('courses.index')); ?>"><?php echo e($course->name); ?></a>
                <?php endif; ?> /
            </span>

            Certificate
        </h4>

        <div x-data="state" class="col-12 mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <button
                            id="template-btn"
                            class="btn btn-icon btn-sm btn-primary"
                            data-bs-toggle="modal" data-bs-target="#exampleModal"
                            title="Add Certificate Template"
                            >
                               <span class="mdi mdi-certificate-outline"></span>
                            </button>

                            <?php if($currentModel->template): ?>
                                <span class="badge bg-primary mb-3 py-2">
                                    <?php echo e($currentModel->template->name); ?>

                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="d-flex gap-2">
                            <input type="text" x-model="search" class="form-control" placeholder="Search">
                            <select class="form-select" x-model="batch">
                                <?php $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($batch->id); ?>">
                                        <?php echo e($batch->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="row">
                        <template
                        x-for="student in studentsArr()"
                        :key="student.id"
                        >
                            <div class="col-md-4 col-12 mb-4 ">
                                <div class="card">
                                    <div class="card-body d-flex align-items-center gap-3">
                                        <img
                                        class="w-25"
                                        :src="student.image"
                                        :alt="student.name">

                                        <div>
                                            <b>
                                                <p
                                                class="mb-0"
                                                x-text="student.name"
                                                ></p>
                                            </b>

                                            <b>
                                                <small class="mb-0" x-text="student.code"></small>
                                            </b>

                                            <div class="d-flex gap-2 align-items-center">
                                                <a href="javascript:void(0)" class="d-block text-decoration-underline"
                                                @click="giveCertificate(student.id, student.batch_id)"
                                                >
                                                    Give Certificate
                                                </a>
                                                <span
                                                x-show="student.has_certificate"
                                                class="mdi mdi-check-decagram-outline text-success"></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </template>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('teleport'); ?>
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel">
            Assign Certificate Template
          </h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form action="<?php echo e(route('certificates.templates.assign')); ?>" method="POST" id="template-form">
            <?php echo csrf_field(); ?>
                <?php if(isset($subject)): ?>
                    <input
                    type="hidden"
                    name="subject_id"
                    value="<?php echo e($subject->id); ?>">
                <?php endif; ?>

                <input
                type="hidden"
                name="course_id"
                value="<?php echo e($course->id); ?>">

                <div class="form-floating form-floating-outline mb-4">
                    <div class="form-floating form-floating-outline mb-4">
                        <select name="certificate_template_id" class="select2 form-select form-select-lg">
                            <?php if(!isset($currentModel->template)): ?>
                                <option value="">Select Certificate</option>
                            <?php endif; ?>
                            <?php $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option
                                    <?php if(isset($currentModel->template) && $currentModel->certificate_template_id == $template->id): ?>
                                        selected
                                    <?php endif; ?>
                                    value="<?php echo e($template->id); ?>"
                                >
                                    <?php echo e($template->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <label ><?php echo e(__('Certificate Template')); ?></label>
                    </div>
                </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary waves-effect" data-bs-dismiss="modal"><?php echo e(__('admin/admin-teacher-assign-course.close')); ?></button>

          <button type="button" id="submit-template-btn" class="btn btn-primary"><?php echo e(__('common.submit')); ?></button>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-script'); ?>
    <script
    defer
    src="<?php echo e(asset('assets/js/plugin/alpinejs.min.js')); ?>">
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script defer>
        const state = {
            batch       : "<?php echo e($batches->first()->id); ?>",
            search      : '',
            students    : <?php echo json_encode($students, 15, 512) ?>,
            course      : <?php echo json_encode($course, 15, 512) ?>,
            subject     : <?php echo json_encode($subject, 15, 512) ?>,
            school_id   : "<?php echo e(auth()->user()->school_id); ?>",
            studentsArr() {
                const key = this.search ? this.search.toLowerCase() : null;

                return this.students.filter(student => {
                    if (this.batch && student.batch_id != this.batch) {
                        return false;
                    }

                    if (key
                        && !student.name.toLowerCase().includes(key)
                        && !student.code.toLowerCase().includes(key)) {
                        return false;
                    }

                    return true;
                });
            },
            async giveCertificate(studentId, batchId) {
                const apiUrl = '/api/give-certificate';

                const response = await fetch(apiUrl, {
                        method: 'POST',
                        body: JSON.stringify({
                            student_id: studentId,
                            batch_id: batchId,
                            course_id: this.course.id,
                            subject_id: this.subject?.id,
                            school_id: this.school_id
                        }),
                        headers: {
                            'Content-type': 'application/json; charset=UTF-8',
                        },
                });

                const data = await response.json();

                if (data.success) {
                    const studentsMap = this.students.reduce((map, student) => {
                        map[student.id] = student;
                        return map;
                    }, {});

                    const student = studentsMap[studentId];
                    if (student) {
                        student.has_certificate = true;
                    }
                } else {
                    document.querySelector('#template-btn').click();
                }
            }
        }
    </script>

    <script>
        $(function () {
            $('#submit-template-btn').click(function (e) {
                e.preventDefault();

                keys  = ['certificate_template_id'];
                rules = {certificate_template_id: 'required'};

                validateNew({
                    keys: keys,
                    rules: rules,
                    fileValidate: false,
                    select2: true
                }).then(() => {
                    $('form#template-form').submit();
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/certificates/give-certificate.blade.php ENDPATH**/ ?>