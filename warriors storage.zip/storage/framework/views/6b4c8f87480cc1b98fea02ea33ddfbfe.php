<div class="row">
    <div class="col-md-8 mb-4">
        <div class="card">
            <div class="card-body">
                <div class="col">
                    <div class="form-floating form-floating-outline mb-4">
                        <input type="text" id="name" class="form-control" placeholder="Enter Batch Name"
                            name="name"
                            value="<?php echo e(isset($batch)?$batch->name:''); ?>"
                            />
                        <label for="name"><?php echo e(__('admin/admin-batch.batch_name')); ?></label>
                    </div>
                </div>

                <div class="col">
                    <div class="form-floating form-floating-outline mb-4">
                        <select
                          id="select2Basic"
                          class="select2 form-select form-select-lg"
                          name="course_id"
                          >
                            <?php if(!isset($batch)): ?>
                                <option value=""><?php echo e(__('admin/admin-batch.select_course')); ?></option>
                            <?php endif; ?>
                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($course->id); ?>"
                                <?php if(isset($batch)): ?>
                                    <?php echo e($batch->course_id == $course->id?'selected':''); ?>

                                <?php endif; ?>
                                >
                                <?php echo e($course->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label for="select2Basic"><?php echo e(__('admin/admin-batch.select_course')); ?></label>
                    </div>
                </div>

                <div class="col">
                    <div class="form-floating form-floating-outline mb-4">
                        <input
                        type="date"
                        class="form-control"
                        placeholder="YYYY-MM-DD"
                        id="start_date"
                        name="start_date"
                        value="<?php echo e(isset($batch)?$batch->start_date:''); ?>"
                        />
                        <label for="start_date"><?php echo e(__('admin/admin-batch.start_date_of_batch')); ?></label>
                    </div>
                </div>

                <div class="col">
                    <div class="form-floating form-floating-outline mb-4">
                        <input
                        type="date"
                        class="form-control"
                        placeholder="YYYY-MM-DD"
                        id="end_date"
                        name="end_date"
                        value="<?php echo e(isset($batch)?$batch->end_date:''); ?>"
                        />
                        <label for="end_date"><?php echo e(__('admin/admin-batch.end_date_of_batch')); ?></label>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card mb-4">
            <div class="card-body">
                <div class="info-container">
                    <h5 class="text-primary"><?php echo e(__('admin/admin-batch.batch_status')); ?></h5>
                    <ul class="list-unstyled mb-4">
                        <?php $__currentLoopData = App\Models\Learning\Batch::STATUS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="mb-3">
                                <label class="form-check-label custom-option-content"
                                    for="<?php echo e($key); ?>">
                                    <input
                                    type="radio"
                                    class="form-check-input me-2"
                                    name="status"
                                    value="<?php echo e($key); ?>"
                                    id="<?php echo e($key); ?>"
                                    <?php if(isset($batch)): ?>
                                        <?php if($batch->status == $key): echo 'checked'; endif; ?>
                                    <?php else: ?>
                                        <?php if($key == 'not_start'): echo 'checked'; endif; ?>
                                    <?php endif; ?>
                                    >
                                    <span class="fw-semibold text-heading"><?php echo e(__('admin/admin-batch.'.$key)); ?></span>
                                </label>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="mt-3 d-flex justify-content-between">
    <a href="<?php echo e(route('batches.index')); ?>" class="btn btn-outline-secondary">
        <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
        <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('common.back')); ?></span>
    </a>
    <button
    class="btn btn-primary ms-2 d-none"
    id="load-btn"
    type="button"
    >
        <span class="spinner-border me-1" role="status" aria-hidden="true"></span>
        Processing...
    </button>
    <button class="btn btn-primary ms-2" id="submit-btn" type="button">
        <?php echo e(__('common.submit')); ?>

    </button>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/batches/form-partials/form.blade.php ENDPATH**/ ?>