<?php
    use Carbon\Carbon;
    use App\Helpers\CustomHelpers;
?>
<!-- Menu -->
<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
    <div class="app-brand demo">
        <span class="app-brand-logo demo">
            <img
            style="width:50px"
            src="<?php echo e(asset(config('settings.admin-logo'))); ?>" alt="">
          </span>
          <span class="app-brand-text demo menu-text fw-bold ms-2">
            <img style="width:120px" src="<?php echo e(asset(config('settings.admin-logo-text'))); ?>" alt="">
          </span>

          <a href="javascript:void(0);" id="lmt-click" class="layout-menu-toggle menu-link text-large ms-auto">
            <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M11.4854 4.88844C11.0081 4.41121 10.2344 4.41121 9.75715 4.88844L4.51028 10.1353C4.03297 10.6126 4.03297 11.3865 4.51028 11.8638L9.75715 17.1107C10.2344 17.5879 11.0081 17.5879 11.4854 17.1107C11.9626 16.6334 11.9626 15.8597 11.4854 15.3824L7.96672 11.8638C7.48942 11.3865 7.48942 10.6126 7.96672 10.1353L11.4854 6.61667C11.9626 6.13943 11.9626 5.36568 11.4854 4.88844Z"
                fill="currentColor"
                fill-opacity="0.6" />
              <path
                d="M15.8683 4.88844L10.6214 10.1353C10.1441 10.6126 10.1441 11.3865 10.6214 11.8638L15.8683 17.1107C16.3455 17.5879 17.1192 17.5879 17.5965 17.1107C18.0737 16.6334 18.0737 15.8597 17.5965 15.3824L14.0778 11.8638C13.6005 11.3865 13.6005 10.6126 14.0778 10.1353L17.5965 6.61667C18.0737 6.13943 18.0737 5.36568 17.5965 4.88844C17.1192 4.41121 16.3455 4.41121 15.8683 4.88844Z"
                fill="currentColor"
                fill-opacity="0.38" />
            </svg>
        </a>
    </div>

    <div class="menu-inner-shadow"></div>

    <ul class="menu-inner py-1">

        <!-- Dashboards -->
        <?php if(!CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Admin")): ?>
            <div
                style="padding: 0 13px"
                class="w-100 mb-2"
            >
                <select
                style="font-size: 17px"
                name="tenant_id"
                class="form-select w-100"
                id="tenant-select"
                >
                    <?php $__currentLoopData = auth()->user()->schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option
                            value="<?php echo e($school->id); ?>"
                            <?php if(auth()->user()->school_id == $school->id): echo 'selected'; endif; ?>
                        ><?php echo e($school->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>
        <?php endif; ?>


        <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Dashboard") ): ?>

        <li class="menu-item <?php echo e(active_path()); ?>">
            <a href="<?php echo e(route('dashboard')); ?>" class="menu-link">
                <span class="mdi mdi-home me-3"></span>
                <div data-i18n="<?php echo e(__('admin/admin-side-bar.dashboard')); ?>">Dashboard</div>
            </a>
        </li>

        <?php endif; ?>

        <!-- Admin Panel -->

        <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Admin") || CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Role")): ?>

        <li class="menu-item <?php echo e((request()->is('admin/admins*')) || (request()->is('admin/roles*')) ? 'open' : ''); ?>">
            <a href="javascript:void(0);" class="menu-link d-flex menu-toggle">
                <span class="mdi mdi-shield-crown-outline me-3"></span>
                <div data-i18n="Admin">Admin</div>
            </a>

            <ul class="menu-sub">

                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Admin") ): ?>

                <li class="menu-item <?php echo e(active_path('admins*')); ?>">
                    <a href="<?php echo e(route('admins.index')); ?>" class="menu-link">
                        <div data-i18n="Admins">Admins</div>
                    </a>
                </li>

                <?php endif; ?>

                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Role") ): ?>

                <li class="menu-item <?php echo e(active_path('roles*')); ?>">
                    <a href="<?php echo e(route('roles.index')); ?>" class="menu-link">
                        <div data-i18n="Roles">Roles</div>
                    </a>
                </li>

                <?php endif; ?>

            </ul>
        </li>


        <?php endif; ?>

        <!-- Users -->

        <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "User") || CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Employee") || CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Teacher") || CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Guardian") || CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Student")): ?>

        <li class="menu-item <?php echo e((request()->is('admin/users*')) || (request()->is('admin/users*'))|| (request()->is('admin/employees*'))|| (request()->is('admin/teachers*'))|| (request()->is('admin/guardians*'))|| (request()->is('admin/students*')) ? 'open' : ''); ?>">
            <a href="javascript:void(0);" class="menu-link d-flex menu-toggle">
                <span class="mdi mdi-account-group-outline me-3"></span>
                <div data-i18n="<?php echo e(__('admin/admin-side-bar.users')); ?>">Users</div>
            </a>

            <ul class="menu-sub">

                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Employee") ): ?>

                <li class="menu-item <?php echo e(active_path('employees*')); ?>">
                    <a href="<?php echo e(route('employees.index')); ?>" class="menu-link">
                        <div data-i18n="<?php echo e(__('admin/admin-side-bar.employee')); ?>">Employees</div>
                    </a>
                </li>

                <?php endif; ?>

                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Teacher") ): ?>

                <li class="menu-item <?php echo e(active_path('teachers*')); ?>">
                    <a href="<?php echo e(route('teachers.index')); ?>" class="menu-link">
                        <div data-i18n="<?php echo e(__('admin/admin-side-bar.teacher')); ?>">Teachers</div>
                    </a>
                </li>

                <?php endif; ?>

                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Guardian") ): ?>

                <li class="menu-item <?php echo e(active_path('guardians*')); ?>">
                    <a href="<?php echo e(route('guardians.index')); ?>" class="menu-link">
                        <div data-i18n="<?php echo e(__('admin/admin-side-bar.guardian')); ?>">Guardians</div>
                    </a>
                </li>

                <?php endif; ?>

                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Student") ): ?>

                <li class="menu-item <?php echo e(active_path('students*')); ?>">
                    <a href="<?php echo e(route('students.index')); ?>" class="menu-link">
                        <div data-i18n="<?php echo e(__('admin/admin-side-bar.student')); ?>">students</div>
                    </a>
                </li>

                <?php endif; ?>
            </ul>
        </li>

        <?php endif; ?>

        <!-- Manage School -->

        <?php if(
                CustomHelpers::get_permission_group_list(Auth::user()->role->id, "School") ||
                CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Enrollment") ||
                CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Live Session")||
                CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Timetable")||
                CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Attendance Report") ||
                CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Exam Result") ||
                CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Vaccine") ||
                CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Ferry") ||
                CustomHelpers::get_permission_group_list(Auth::user()->role->id, "General Reminder") ||
                CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Achievement") ||
                CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Achievement Rank") ||
                CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Health Examination")
            ): ?>

        <li class="menu-item <?php echo e((request()->is('admin/schools*')) || (request()->is('admin/achievement-ranks*')) || (request()->is('admin/achievements*')) || (request()->is('admin/general-reminders*')) ||(Request()->is('admin/health-examinations*'))  || (request()->is('admin/ferries*'))   || (request()->is('admin/classrooms*'))|| (request()->is('admin/enrollments*')) || (request()->is('admin/live-sessions*'))||(request()->is('admin/overall-gradings*'))||(request()->is('admin/timetables*'))||(request()->is('admin/exam-results*'))||(request()->is('admin/attendance-reports*'))||(request()->is('admin/vaccines*'))||(request()->is('admin/exams*')) ? 'open' : ''); ?>">
            <a href="javascript:void(0);" class="menu-link d-flex menu-toggle">
                <span class="mdi mdi-school-outline me-3"></span>
                <div data-i18n="<?php echo e(__('admin/admin-side-bar.manage_school')); ?>">Manage School</div>
            </a>
            <ul class="menu-sub">

                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "School") ): ?>
                <li class="menu-item <?php echo e(active_path('schools*')); ?>">
                    <a
                    <?php if(auth()->user()->school_id): ?>
                        href="<?php echo e(route('schools.show',auth()->user()->school_id)); ?>"
                    <?php else: ?>
                        href="<?php echo e(route('schools.index')); ?>"
                    <?php endif; ?>
                    class="menu-link">
                        <div data-i18n="<?php echo e(__('admin/admin-side-bar.school')); ?>">School</div>
                    </a>
                </li>

                <?php endif; ?>

                
                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Exam Result") ): ?>
                    <li class="menu-item <?php echo e(active_path('exam-result*')); ?>">
                        <a href="<?php echo e(route('exam-results.index')); ?>" class="menu-link">
                            <div data-i18n="<?php echo e(__('admin/admin-side-bar.exam_result')); ?>">Result</div>
                        </a>
                    </li>
                <?php endif; ?>



                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Grading") ): ?>
                    <li class="menu-item <?php echo e(active_path('overall-gradings*')); ?>">
                        <a href="<?php echo e(route('overall-gradings.index')); ?>" class="menu-link">
                            <div data-i18n="<?php echo e(__('admin/admin-side-bar.grading')); ?>">Grading</div>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if(CustomHelpers::has_permission(Auth::user()->role->id, "Exam Visible")): ?>
                    <li class="menu-item <?php echo e(active_path('exams*')); ?>">
                        <a href="<?php echo e(route('exams.index')); ?>" class="menu-link">
                            <div data-i18n="<?php echo e(__('admin/admin-side-bar.exam')); ?>">Exam</div>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if(CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Live Session")): ?>
                    <li class="menu-item <?php echo e(active_path('live-sessions*')); ?>">
                        <a href="<?php echo e(route('live-sessions.index')); ?>" class="menu-link">
                            <div data-i18n="<?php echo e(__('admin/admin-side-bar.live_session')); ?>">Live Session</div>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if(CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Timetable")): ?>
                <li class="menu-item <?php echo e(active_path('timetables*')); ?>">
                    <a href="<?php echo e(route('timetables.index')); ?>" class="menu-link">
                        <div data-i18n="<?php echo e(__('admin/admin-side-bar.timetable')); ?>">Timetable</div>
                    </a>
                </li>
                <?php endif; ?>

                <?php if(CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Timetable")): ?>
                <li class="menu-item <?php echo e(active_path('lesson-plans*')); ?>">
                    <a href="<?php echo e(route('lesson-plans.index')); ?>" class="menu-link">
                        <div>Lesson Plan</div>
                    </a>
                </li>
                <?php endif; ?>

                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Attendance Report")  ): ?>
                    <li class="menu-item <?php echo e(active_path('attendance-reports*')); ?>">
                        <a href="<?php echo e(route('attendance-reports.index')); ?>" class="menu-link">
                            <div data-i18n="<?php echo e(__('admin/admin-side-bar.attendance')); ?>">Attendance</div>
                        </a>
                    </li>
                <?php endif; ?>


                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Enrollment") ): ?>

                <li class="menu-item <?php echo e(active_path('enrollments*')); ?>">
                    <a href="<?php echo e(route('enrollments.index')); ?>" class="menu-link">
                        <div data-i18n="<?php echo e(__('admin/admin-side-bar.enrollment')); ?>">Enrollment</div>
                    </a>
                </li>

                <?php endif; ?>

                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Vaccine") ): ?>

                    <li class="menu-item <?php echo e(active_path('vaccines*')); ?>">
                        <a href="<?php echo e(route('vaccines.index')); ?>" class="menu-link">
                            <div data-i18n="<?php echo e(__('admin/admin-side-bar.vaccine')); ?>">Vaccine</div>
                        </a>
                    </li>

                <?php endif; ?>

                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Ferry") ): ?>
                <li class="menu-item <?php echo e(active_path('ferries*')); ?>">
                    <a
                        href="<?php echo e(route('ferries.index')); ?>"
                        class="menu-link"
                    >
                        <div data-i18n="<?php echo e(__('admin/admin-side-bar.ferry')); ?>">Ferry</div>
                    </a>
                </li>
                <?php endif; ?>

                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "General Reminder") ): ?>
                    <li class="menu-item <?php echo e(active_path('general-reminders*')); ?>">
                        <a href="<?php echo e(route('general-reminders.index')); ?>" class="menu-link">
                            <div data-i18n="<?php echo e(__('admin/admin-general-reminder.general_reminder')); ?>">General Reminder</div>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Health Examination") ): ?>
                <li class="menu-item <?php echo e(active_path('health-examinations*')); ?>">
                    <a
                        href="<?php echo e(route('health-examinations.index')); ?>"
                        class="menu-link"
                    >
                        <div data-i18n="<?php echo e(__('admin/admin-side-bar.health_examination')); ?>"><?php echo e(__('admin/admin-side-bar.health_examination')); ?></div>
                    </a>
                </li>
                <?php endif; ?>

                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Achievement Rank") ): ?>
                <li class="menu-item <?php echo e(active_path('achievement-ranks*')); ?>">
                    <a
                        href="<?php echo e(route('achievement-ranks.index')); ?>"
                        class="menu-link"
                    >
                        <div data-i18n="<?php echo e(__('admin/admin-side-bar.achievement_rank')); ?>"><?php echo e(__('admin/admin-side-bar.achievement_rank')); ?></div>
                    </a>
                </li>
                <?php endif; ?>

                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Achievement") ): ?>
                <li class="menu-item <?php echo e(active_path('achievements*')); ?>">
                    <a
                        href="<?php echo e(route('achievements.index')); ?>"
                        class="menu-link"
                    >
                        <div data-i18n="<?php echo e(__('admin/admin-side-bar.achievement')); ?>"><?php echo e(__('admin/admin-side-bar.achievement')); ?></div>
                    </a>
                </li>
                <?php endif; ?>


            </ul>

        </li>

        <?php endif; ?>

        
        <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Course") || CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Subject") ||  CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Batch")  ): ?>

        <li class="menu-item <?php echo e((request()->is('admin/courses*'))|| (request()->is('admin/subjects*'))|| (request()->is('admin/batches*'))|| (request()->is('admin/assignments*')) || (request()->is('admin/tasks*')) ? 'open' : ''); ?>">
            <a href="javascript:void(0);" class="menu-link d-flex menu-toggle">
                <span class="mdi mdi-book-multiple me-3"></span>
                <div data-i18n="<?php echo e(__('admin/admin-side-bar.manage_course')); ?>">Manage Course</div>
            </a>
            <ul class="menu-sub">
                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Subject") ): ?>

                <li class="menu-item <?php echo e(active_path('subjects*')); ?>">
                    <a href="<?php echo e(route('subjects.index')); ?>" class="menu-link">
                        <div data-i18n="<?php echo e(__('admin/admin-side-bar.subject')); ?>">Subject</div>
                    </a>
                </li>

                <?php endif; ?>

                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Course") ): ?>

                <li class="menu-item <?php echo e(active_path('courses*')); ?>">
                    <a href="<?php echo e(route('courses.index')); ?>" class="menu-link">
                        <div data-i18n="<?php echo e(__('admin/admin-side-bar.course')); ?>">Course</div>
                    </a>
                </li>

                <?php endif; ?>


                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Batch") ): ?>

                <li class="menu-item <?php echo e(active_path('batches*')); ?>">
                    <a href="<?php echo e(route('batches.index')); ?>" class="menu-link">
                        <div data-i18n="<?php echo e(__('admin/admin-side-bar.batch')); ?>">Batch</div>
                    </a>
                </li>

                <?php endif; ?>

                
                    <li class="menu-item <?php echo e(active_path('assignments*')); ?>">
                        <a href="<?php echo e(route('assignments.index')); ?>" class="menu-link">
                            <div
                            data-i18n="<?php echo e(__('admin/admin-side-bar.assignment')); ?>">
                            Assignment
                            </div>
                        </a>
                    </li>
                

                
                    <li class="menu-item <?php echo e(active_path('tasks*')); ?>">
                        <a href="<?php echo e(route('tasks.index')); ?>" class="menu-link">
                            <div
                            data-i18n="<?php echo e(__('admin/admin-side-bar.task')); ?>">
                            Homework
                            </div>
                        </a>
                    </li>
                
            </ul>

        </li>

        <?php endif; ?>



         
         <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Grade") || CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Transaction Name") ||  CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Certificate") || CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Student Setting")): ?>

         <li class="menu-item <?php echo e((request()->is('admin/grades*')) ? 'open' : ''); ?> <?php echo e((request()->is('admin/student-settings*')) ? 'open' : ''); ?>  <?php echo e((request()->is('admin/certificate*')) ? 'open' : ''); ?>  <?php echo e((request()->is('admin/transaction-names*')) ? 'open' : ''); ?>">
             <a href="javascript:void(0);" class="menu-link d-flex menu-toggle">
                <span class="mdi mdi-cog me-3"></span>
                 <div data-i18n="<?php echo e(__('admin/admin-side-bar.app_setting')); ?>">App Setting</div>
             </a>
             <ul class="menu-sub">
                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Grade") ): ?>

                    <li class="menu-item <?php echo e(active_path('grades*')); ?>">
                        <a href="<?php echo e(route('grades.index')); ?>" class="menu-link">
                            <div data-i18n="<?php echo e(__('admin/admin-side-bar.grade')); ?>">Grade</div>
                        </a>
                    </li>

                <?php endif; ?>

                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Transaction Name") ): ?>

                    <li class="menu-item <?php echo e(active_path('transaction-names*')); ?>">
                        <a href="<?php echo e(route('transaction-names.index')); ?>" class="menu-link">
                            <div data-i18n="<?php echo e(__('admin/admin-side-bar.transaction_name')); ?>">Transaction Name</div>
                        </a>
                    </li>

                <?php endif; ?>

                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Student Setting") ): ?>
                    <li class="menu-item <?php echo e(active_path('student-settings*')); ?>">
                        <a href="<?php echo e(route('student-settings.index')); ?>" class="menu-link">
                            <div data-i18n="Student Setting">Student Setting</div>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Admin") ): ?>
                    <li class="menu-item <?php echo e(active_path('control-settings*')); ?>">
                        <a href="<?php echo e(route('control-settings.index')); ?>" class="menu-link">
                            <div data-i18n="Control Setting">Control Setting</div>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Certificate") ): ?>
                <li class="menu-item <?php echo e(active_path('certificates*')); ?>">
                    <a href="<?php echo e(route('certificates.templates.index')); ?>" class="menu-link">
                        <div data-i18n="<?php echo e(__('admin/admin-side-bar.certificate')); ?>">Certificate</div>
                    </a>
                </li>
                <?php endif; ?>

             </ul>
         </li>

         <?php endif; ?>


        
        <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "School" &&  CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Student Payment")) ||   CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Transaction Report") ||   CustomHelpers::get_permission_group_list(Auth::user()->role->id, "User Report") || CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Chat Log")): ?>

        <li class="menu-item <?php echo e((request()->is('admin/student-payments*'))||(request()->is('admin/transaction-reports*'))||(request()->is('admin/user-reports*')) || (request()->is('admin/chat-logs*')) ? 'open' : ''); ?>">
            <a href="javascript:void(0);" class="menu-link d-flex menu-toggle">
                <span class="mdi mdi-chart-bar me-3"></span>
                <div data-i18n="<?php echo e(__('admin/admin-side-bar.reports')); ?>">Reports</div>
            </a>

            <ul class="menu-sub">

                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Student Payment")  ): ?>
                    <li class="menu-item <?php echo e(active_path('student-payments*')); ?>">
                        <a href="<?php echo e(route('student-payments.index')); ?>" class="menu-link">
                            <div data-i18n="<?php echo e(__('admin/admin-side-bar.payment')); ?>">Payment</div>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Transaction Report") ): ?>
                        <?php
                            $start = Carbon::now()->subMonth(1)->startOfMonth();
                            $end = Carbon::now()->addMonth(1)->endOfMonth();
                            $formattedDate =  $start->format('m/d/Y') . ' - ' . $end->format('m/d/Y');
                        ?>
                    <li class="menu-item <?php echo e(active_path('transaction-reports*')); ?>">
                        <a href="<?php echo e(route('transaction-reports.index',['filter_option' => 'due_in_10_day', 'dates' => $formattedDate])); ?>" class="menu-link">
                            <div data-i18n="<?php echo e(__('admin/admin-side-bar.transaction')); ?>"> Transaction</div>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "User Report")  ): ?>
                    <li class="menu-item <?php echo e(active_path('user-reports*')); ?>">
                        <a href="<?php echo e(route('user-reports.index')); ?>" class="menu-link">
                            <div data-i18n="<?php echo e(__('admin/admin-side-bar.user_report')); ?>">User Report</div>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Chat Log")  ): ?>
                    <li class="menu-item <?php echo e(active_path('chat-logs*')); ?>">
                        <a href="<?php echo e(route('chat-logs.index')); ?>" class="menu-link">
                            <div data-i18n="<?php echo e(__('admin/admin-side-bar.chat_log')); ?>">Chat Log</div>
                        </a>
                    </li>
                <?php endif; ?>


            </ul>

        </li>

        <?php endif; ?>

        

        <?php if(
              CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Admin")
            ): ?>

        <li class="menu-item <?php echo e((request()->is('admin/region/countries*'))|| (request()->is('admin/region/cities*'))|| (request()->is('admin/region/townships*')) ? 'open' : ''); ?>">
            <a href="javascript:void(0);" class="menu-link d-flex menu-toggle">
                <span class="mdi mdi-home-map-marker me-3"></span>
                <div data-i18n="<?php echo e(__('admin/admin-side-bar.manage_region')); ?>">Manage Region</div>
            </a>
            <ul class="menu-sub">

                


                <li class="menu-item <?php echo e(active_path('region/countries*')); ?>">
                    <a href="<?php echo e(route('countries.index')); ?>" class="menu-link">
                        <div data-i18n="<?php echo e(__('admin/admin-side-bar.country')); ?>">Country</div>
                    </a>
                </li>



                

                <li class="menu-item <?php echo e(active_path('region/cities*')); ?>">
                    <a href="<?php echo e(route('cities.index')); ?>" class="menu-link">
                        <div data-i18n="<?php echo e(__('admin/admin-side-bar.city')); ?>">City</div>
                    </a>
                </li>



                


                <li class="menu-item <?php echo e(active_path('region/townships*')); ?>">
                    <a href="<?php echo e(route('townships.index')); ?>" class="menu-link">
                        <div data-i18n="<?php echo e(__('admin/admin-side-bar.township')); ?>">Township</div>
                    </a>
                </li>


            </ul>

        </li>

        <?php endif; ?>

        <?php if(CustomHelpers::has_permission(Auth::user()->role->id, "Exam Visible")): ?>
            <li class="menu-item">
                <a href="https://exam.admin.eduplusmyanmar.com/admin" target="_blank" class="menu-link d-flex gap-3">
                    <span class="mdi mdi-alpha-e-box-outline"></span>
                    <div>EDUplus Exam</div>
                </a>
            </li>
        <?php endif; ?>


        <!-- Manage Announcements -->
        <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "School Announcement") || CustomHelpers::get_permission_group_list(Auth::user()->role->id, "School Event") || CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Custom Notification")): ?>

        <li class="menu-item <?php echo e((request()->is('admin/announcements*')) || (request()->is('admin/school-events*')) || (request()->is('admin/live-sessions*')) || (request()->is('admin/custom-notifications*')) ? 'open' : ''); ?>">
            <a href="javascript:void(0);" class="menu-link d-flex menu-toggle">
                <span class="mdi mdi-bullhorn-outline me-3"></span>
                <div data-i18n="Announcements">Announcements</div>
            </a>
            <ul class="menu-sub">

                <?php if(CustomHelpers::get_permission_group_list(Auth::user()->role->id, "School Announcement") ): ?>
                    <li class="menu-item <?php echo e(active_path('announcements*')); ?>">
                        <a href="<?php echo e(route('announcements.index')); ?>" class="menu-link">
                            <div data-i18n="School Announcements">School Announcement</div>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "School Event") ): ?>

                <li class="menu-item <?php echo e(active_path('school-events*')); ?>">
                    <a href="<?php echo e(route('school-events.index')); ?>" class="menu-link">
                        <div data-i18n="School Event">School Event</div>
                    </a>
                </li>

                <?php endif; ?>


                <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Custom Notification") ): ?>

                <li class="menu-item <?php echo e(active_path('custom-notifications*')); ?>">
                    <a href="<?php echo e(route('custom-notifications.index')); ?>" class="menu-link">
                        <div data-i18n="Custom Notification">Custom Notification</div>
                    </a>
                </li>

                <?php endif; ?>
            </ul>
        </li>

        <?php endif; ?>

        <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Admin") ): ?>

            <li class="menu-item <?php echo e((request()->is('admin/settings*')) ? 'open' : ''); ?>">
                <a href="javascript:void(0);" class="menu-link d-flex menu-toggle gap-3">
                    <span class="mdi mdi-content-save-cog-outline"></span>
                    <div data-i18n="CMS">CMS</div>
                </a>

                <ul class="menu-sub">
                    <li class="menu-item <?php echo e(route('settings.landing.index') === url()->current()?'active':''); ?>">
                        <a href="<?php echo e(route('settings.landing.index')); ?>" class="menu-link">
                            <div data-i18n="Landing Page">Landing Page</div>
                        </a>
                    </li>

                    <li class="menu-item <?php echo e(route('settings.themes.index') === url()->current()?'active':''); ?>">
                        <a href="<?php echo e(route('settings.themes.index')); ?>" class="menu-link">
                            <div data-i18n="Themes">Themes</div>
                        </a>
                    </li>

                    <li class="menu-item <?php echo e(route('settings.admin-panels.index') === url()->current()?'active':''); ?>">
                        <a href="<?php echo e(route('settings.admin-panels.index')); ?>" class="menu-link">
                            <div data-i18n="Admin Panel">Admin Panel</div>
                        </a>
                    </li>

                </ul>
            </li>

            <li class="menu-item ">
                <a href="javascript:void(0);" class="menu-link d-flex menu-toggle gap-3">
                    <span class="mdi mdi-cogs"></span>
                    <div data-i18n="Control Panel">Control Panel</div>
                </a>

            </li>
        <?php endif; ?>

        

            <li class="menu-item <?php echo e(route('profile') === url()->current()?'active':''); ?>">
                <a href="<?php echo e(route('profile')); ?>" class="menu-link d-flex gap-3">
                    <span class="mdi mdi-account-circle-outline"></span>
                    <div ><?php echo e(__('admin/admin-side-bar.my_profile')); ?></div>
                </a>
            </li>

        

        <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Admin") ): ?>

            <li class="menu-item <?php echo e(route('application') === url()->current()?'active':''); ?>">
                <a href="<?php echo e(route('application')); ?>" class="menu-link d-flex gap-3">
                    <span class="mdi mdi-qrcode"></span>
                    <div >Application</div>
                </a>
            </li>

        <?php endif; ?>

        <?php if( CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Admin") ): ?>

            <li class="menu-item <?php echo e((request()->is('admin/users-guides*')) ? 'open' : ''); ?>">
                <a href="javascript:void(0);" class="menu-link d-flex menu-toggle gap-3">
                    <span class="mdi mdi-book-cog-outline"></span>
                    <div data-i18n="<?php echo e(__('admin/admin-side-bar.user_guide')); ?>"><?php echo e(__('admin/admin-side-bar.user_guide')); ?></div>
                </a>

                <ul class="menu-sub">
                    <li class="menu-item <?php echo e(route('users-guides.admin-guides.index') === url()->current()?'active':''); ?>">
                        <a href="<?php echo e(route('users-guides.admin-guides.index')); ?>" class="menu-link">
                            <div data-i18n="<?php echo e(__('admin/admin-side-bar.admin_guide')); ?>"><?php echo e(__('admin/admin-side-bar.admin_guide')); ?></div>
                        </a>
                    </li>

                    <li class="menu-item <?php echo e(route('users-guides.guardian-guides.index') === url()->current()?'active':''); ?>">
                        <a href="<?php echo e(route('users-guides.guardian-guides.index')); ?>" class="menu-link">
                            <div data-i18n="<?php echo e(__('admin/admin-side-bar.guardian_guide')); ?>"><?php echo e(__('admin/admin-side-bar.guardian_guide')); ?></div>
                        </a>
                    </li>

                    <li class="menu-item <?php echo e(route('users-guides.student-guides.index') === url()->current()?'active':''); ?>">
                        <a href="<?php echo e(route('users-guides.student-guides.index')); ?>" class="menu-link">
                            <div data-i18n="<?php echo e(__('admin/admin-side-bar.student_guide')); ?>"><?php echo e(__('admin/admin-side-bar.student_guide')); ?></div>
                        </a>
                    </li>

                    <li class="menu-item <?php echo e(route('users-guides.teacher-guides.index') === url()->current()?'active':''); ?>">
                        <a href="<?php echo e(route('users-guides.teacher-guides.index')); ?>" class="menu-link">
                            <div data-i18n="<?php echo e(__('admin/admin-side-bar.teacher_guide')); ?>"><?php echo e(__('admin/admin-side-bar.teacher_guide')); ?></div>
                        </a>
                    </li>

                </ul>
            </li>

        <?php endif; ?>

        <?php if( !CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Admin") ): ?>
            <li class="menu-item <?php echo e(route('guides.index') === url()->current()?'active':''); ?>">
                <a href="<?php echo e(route('guides.index')); ?>" class="menu-link d-flex gap-3">
                    <span class="mdi mdi-book-account"></span>
                    <div ><?php echo e(__('admin/admin-side-bar.admin_guide_video')); ?></div>
                </a>
            </li>
        <?php endif; ?>

        
            <li class="menu-item <?php echo e(route('documentations.index') === url()->current()?'active':''); ?>">
                <a href="<?php echo e(route('documentations.index')); ?>" class="menu-link d-flex gap-3">
                    <span class="mdi mdi-file-document-outline"></span>
                    <div ><?php echo e(__('admin/admin-side-bar.admin_guide_doc')); ?></div>
                </a>
            </li>
        

    </ul>
</aside>
<!-- / Menu -->
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/layout/shared/aside-menu.blade.php ENDPATH**/ ?>