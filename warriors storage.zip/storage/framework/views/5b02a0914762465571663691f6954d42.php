<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.dashboard')); ?> / <a
                        href="<?php echo e(route('timetables.index')); ?>"><?php echo e(__('admin/breadcrumb/timetable.timetable')); ?></a> / </span><?php echo e($course->name); ?> / Timetables</h4>

        <div class="card mt-3">
            <div
                class="d-flex justify-content-between card-body"
            >
                <div class="d-flex align-items-center gap-2">

                    <h5
                      style="margin:0%;padding:0%;"
                      class="text-primary"
                    >
                        <?php echo e($course->name); ?> -
                    </h5>

                    <select
                      data-url="<?php echo e(route('timetable-formats.show')); ?>"
                      style="font-size: 17px; width: fit-content !important;"
                      class="form-select"
                      id="batch-select"
                    >
                        <option value="">Select Batch</option>
                        <?php $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($batch->id); ?>">
                                <?php echo e($batch->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                </div>
                <div>
                    <button
                    type="button"
                    class="btn btn-sm btn-success"
                    id="format-create-btn"
                    >
                        <span class="mdi mdi-plus"></span>
                        Add Format
                    </button>
                </div>
            </div>
        </div>

        <div id="ajax-container" class="card mt-3">

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(function () {
            let tagBtn          = $('.tag-btn');
            let createBtn       = $('#format-create-btn');
            let batchSelect     = $('#batch-select');
            let urlNext         = '<?php echo e(route('timetable-formats.create',['course' => $course->id,'batch' => ':id'])); ?>';
            let urlParams       = new URLSearchParams(window.location.search);
            let urlBatchParam   = urlParams.get('batch');
            let urlFormatParam  = urlParams.get('format');
            const url           = batchSelect.data('url');

            const ajaxRequest = (batchId, url, format = null) => {
                if(batchId){
                    $.ajax({
                        type: "GET",
                        url: url,
                        data: {
                            batch_id: batchId,
                            format: format
                        },
                        dataType: "html",
                        success: function (response) {
                            $('#ajax-container').html(response);
                        },
                        error: function (xhr, status, error) {
                            console.error(error);
                        }
                    });
                } else {
                    $('#ajax-container').html('');
                }
            }

            if(urlBatchParam){
                batchSelect.val(urlBatchParam);
                ajaxRequest(urlBatchParam, url, urlFormatParam);
            }

            $('#batch-select').change(function (e) {
                e.preventDefault();
                const batchId = $(this).val();

                ajaxRequest(batchId, url);
            });

            createBtn.click(function(){
                let selectedBatch   = batchSelect.val();
                let route           = urlNext.replace(':id',selectedBatch);
                if(selectedBatch){
                    window.location     = route;
                }else{
                    batchNotSelectedAlert();
                }
            })

            let batchNotSelectedAlert = () => {
                Swal.fire({
                    title: "Notice !",
                    text: "Batch is not selected !",
                    icon: 'info',
                    showCancelButton: true,
                    confirmButtonText:"confirm",
                    customClass: {
                        confirmButton: 'btn btn-success me-3 waves-effect waves-light',
                        cancelButton: 'btn btn-label-secondary waves-effect'
                    },
                    buttonsStyling: false
                })
            }


        });
    </script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/timetables/format-index.blade.php ENDPATH**/ ?>