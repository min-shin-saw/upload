<?php $__env->startSection('container'); ?>

<h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?>/ ferries / <a href="<?php echo e(route('ferry-students.index',$ferryId)); ?>">students</a> /create</span> </h4>

<div>
    <h4><?php echo e(__('admin/admin-ferry.ferry_student_title')); ?></h4>
    <div class="card col-7">
        <div class="card-body">
            <form
                action="<?php echo e(route('ferry-students.store',$ferryId)); ?>"
                method="post"
            >
                <?php echo csrf_field(); ?>
                <div id="ferry-students">
                    <div class="repeater-item mb-2">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-floating form-floating-outline">
                                    <select name="students[]"   class="form-select select2 student-select">
                                        <option value=""><?php echo e(__("admin/admin-ferry.select_student_placeholder")); ?></option>
                                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($student->id); ?>">
                                            <?php echo e($student->name); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <label for="attended_class"><?php echo e(__('admin/admin-ferry.select_student_label')); ?></label>
                                </div>
                            </div>
                            <div class="col-md-3 d-flex justify-content-center">
                                <img src="<?php echo e(asset('assets/img/placeholders/course-subject-placeholder.png')); ?>" height="45">
                            </div>
                            <div class="col-md-3 d-flex align-items-center justify-content-start">
                                <button type="button" class="btn btn-label-danger waves-effect me-1 remove-btn">
                                    <i class="mdi mdi-close me-1"></i>
                                </button>
                                <button type="button" class="btn btn-label-success waves-effect repeater-add-btn">
                                    <i class="mdi mdi-plus me-1"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mt-3 d-flex justify-content-between">
                    <a href="<?php echo e(route('ferry-students.index',$ferryId)); ?>" class="btn btn-outline-secondary">
                        <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
                        <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('common.back')); ?></span>
                    </a>

                    <button class="btn btn-primary ms-2" id="submit-btn" type="button">
                        <?php echo e(__('common.submit')); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/js/mss-repeater/mss-repeater.js')); ?>"></script>
<script>
    let students = <?php echo json_encode($students, 15, 512) ?>;
    let selectedStudents = [];
    let defaultImage = "<?php echo e(asset('assets/img/placeholders/course-subject-placeholder.png')); ?>";
    
    $(document).ready(function() {
        setMssRepeater({
            id:'#ferry-students',
            image: defaultImage,
            removing:(el) => {
                let parent = $(el).parent().parent();
                let indexToRemove = selectedStudents.indexOf(parent.find('.student-select').val());
                if (indexToRemove !== -1) {
                    selectedStudents.splice(indexToRemove, 1);
                }
            }
        });

        let fireAlert = (message) => {
            Swal.fire({
                title: 'Error!',
                text: message,
                icon: 'error',
                customClass: {
                    confirmButton: 'btn btn-primary waves-effect waves-light'
                },
                buttonsStyling: false
            });
        }

        $('.repeater-add-btn').click(function(){
        $('.student-select').last().data('oldValue','')
        })

        $('.student-select').change(function(){
            let selectedValue = $(this).val();
            let parent = $(this).parent().parent().parent().parent().parent().parent();
            let image = selectedValue != '' ?  students.find((student) => student.id == $(this).val()).image : defaultImage ;

            let removeIdFromSelectStudent = (value) =>{
                let indexToRemove = selectedStudents.indexOf(value);
                if (indexToRemove !== -1) {
                    selectedStudents.splice(indexToRemove, 1);
                }
            }

            if(selectedValue == '' || selectedValue == undefined){
                if($(this).data('oldValue')){
                    removeIdFromSelectStudent($(this).data('oldValue'))
                    $(this).data('oldValue','');
                }
                parent.find('img').attr('src',defaultImage);
            }else{
                if(selectedStudents.includes(selectedValue)){
                    parent.find('img').attr('src',defaultImage);
                    $(this).val('');
                    removeIdFromSelectStudent($(this).data('oldValue'))
                    fireAlert("Already selected the student");
                }else{
                    if($(this).data('oldValue')){
                        removeIdFromSelectStudent($(this).data('oldValue'))
                    }
                    $(this).data('oldValue',selectedValue);
                    selectedStudents.push(selectedValue);
                    parent.find('img').attr('src',image);
                }
            }

        })


        $('#submit-btn').click(function(e){
            if($('.student-select').first().val() == ''){
                fireAlert("First row must be filled ! ");
            }else{
            $('form').submit();
            }

        })

    })

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/ferry-students/create.blade.php ENDPATH**/ ?>