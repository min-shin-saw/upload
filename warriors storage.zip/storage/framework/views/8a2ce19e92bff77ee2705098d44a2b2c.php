<?php
    $teacher = App\Models\Teacher\Teacher::find($id);
?>
<div class="d-flex justify-content-start gap-1">

    <button
        title="Activate User Account"
        type="button"
        data-bs-toggle="modal"
        data-bs-target="#activate-account-modal"
        class="btn btn-sm btn-icon btn-secondary waves-effect  waves-light account-activate-btn"
        <?php echo isUserCanActivateAccount($teacher,'teacher'); ?>

    >
        <span class="mdi mdi-key-variant"></span>
    </button>

    <a href="<?php echo e(route('teachers.show',$id)); ?>" title="Show" class="btn btn-sm btn-icon btn-success waves-effect waves-light">
        <span class="mdi mdi-information-outline" ></span>
    </a>
    <a href="<?php echo e(route('teachers.edit',$id)); ?>" title="Edit" class="btn btn-sm btn-icon btn-primary waves-effect waves-light">
        <span class="mdi mdi-playlist-edit" ></span>
    </a>

    <a href="<?php echo e(route('teachers.courses-subjects',$id)); ?>" title="Assign Courses and Subjects" class="btn btn-sm btn-icon btn-info waves-effect waves-light">
        <span class="mdi mdi-book-cog-outline" ></span>
    </a>

    <button
    title="Delete"
    type="button"
    class="btn btn-sm btn-icon btn-danger waves-effect waves-light delete-btn"
    data-url="<?php echo e(route('teachers.destroy',$id)); ?>"
    >
        <span class="mdi mdi-delete-circle" ></span>
    </button>

    <?php if($teacher->subjects->count()>0): ?>
        <a href="<?php echo e(route('teacher-payment.index',$id)); ?>" title="Teacher Payment" class="btn btn-sm btn-icon btn-warning waves-effect waves-light">
            <span class="mdi mdi-currency-usd" ></span>
        </a>
    <?php endif; ?>

    <script src="<?php echo e(asset('assets/js/delete-sweet-alert.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/activate-account/activate-user-account.js')); ?>"></script>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/teachers/action.blade.php ENDPATH**/ ?>