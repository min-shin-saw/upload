<?php
    function getTop($overallTimetableFormat) {

        $timeRange = [
            $overallTimetableFormat->start_time,
            $overallTimetableFormat->end_time
        ];

        $count = App\Models\School\OverallTimetableFormat::where([
            'timetable_format_id'=>$overallTimetableFormat->timetable_format_id,
            'day'                =>$overallTimetableFormat->day
        ])
        ->where(function($query) use ($timeRange) {
            $query->whereRaw('TIME(ADDTIME(start_time,"00:01:00")) BETWEEN ? AND ?', $timeRange)
                ->orWhereRaw('TIME(SUBTIME(end_time,"00:01:00")) BETWEEN ? AND ?', $timeRange);
        })
        ->where('id','>',$overallTimetableFormat->id)
        ->where('id','!=',$overallTimetableFormat->id)
        ->count();

        $h = ($count * 35);

        return $h? $h+$count :0;
    }

    function getHeightParent($format_id,$day) {

        $overalls = App\Models\School\OverallTimetableFormat::where([
                        'timetable_format_id' => $format_id,
                        'day'                 => $day
                    ])
                    ->orderBy('start_time')
                    ->with('subject')
                    ->get();

        $counts = [];

        $overalls
            ->map(function($overall) use(&$counts,$format_id,$day) {

                $timeRange = [
                    $overall->start_time,
                    \Carbon\Carbon::parse($overall->end_time)->subMinute()->format('H:i:s')
                ];

                $count = App\Models\School\OverallTimetableFormat::where([
                            'timetable_format_id' => $format_id,
                            'day'                 => $day
                        ])
                        ->orderBy('start_time')
                        ->where('start_time','>=',$overall->start_time)
                        ->whereBetween('start_time', $timeRange)
                        ->get()
                        ->count();

                if($count) {
                    array_push($counts, $count);
                }
            });

        rsort($counts);

        return count($counts) ? $counts[0] * 36 : 36;
    }
?>

<link rel="stylesheet" href="<?php echo e(asset('assets/css/custom-content.css')); ?>">

<div class="accordion accordion-flush" id="accordionFlushExample">
    <?php $__currentLoopData = $formats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $format): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="accordion-item">
            <h2 class="accordion-header">
                <button
                type="button"
                class="
                  accordion-button collapsed text-primary
                "
                data-bs-toggle="collapse"
                data-bs-target="#acc-<?php echo e($format->id); ?>"
                aria-expanded="false"
                aria-controls="acc-<?php echo e($format->id); ?>"
                >
                    <?php echo e($format->name); ?>

                </button>
            </h2>

            <?php
                $startDate = Carbon\Carbon::createFromFormat('Y-m-d', $format->start_date);
                $endDate   = Carbon\Carbon::createFromFormat('Y-m-d', $format->end_date);
                $today     = Carbon\Carbon::today();

                if($activeFormat) {
                    $activeStatus = $format->id == $activeFormat;
                } else {
                    $activeStatus = $today->between($startDate, $endDate);
                }
            ?>

            <div
              id="acc-<?php echo e($format->id); ?>"
              class="
                accordion-collapse collapse <?php echo e($activeStatus?'show':''); ?>

              "
              data-bs-parent="#accordionFlushExample"
            >
                <div class="accordion-body">
                    <div style="padding: 0 0 3px 20px" class="">
                        <button
                        class="btn btn-sm btn-info custom-time-btn"
                        data-format-id  ="<?php echo e($format->id); ?>"
                        data-start-time ="<?php echo e($format->start_time); ?>"
                        data-end-time   ="<?php echo e($format->end_time); ?>"
                        data-days       = "<?php echo e(json_encode(unserialize($format->days))); ?>"
                        >
                            Custom Times
                        </button>
                    </div>

                    <div class="d-flex py-2 border-bottom overflow-auto">
                        <div
                        style="
                          margin-right: 5px;
                          display: flex;
                          flex-direction: column;
                        "
                        >
                            <a
                            href="<?php echo e(route('timetable-formats.edit', $format->id)); ?>"
                            class="btn text-primary"
                            title="Template Edit"
                            >
                                <span class="mdi mdi-playlist-edit"></span>
                            </a>

                            <button
                              class="btn text-danger template-delete-btn"
                              title="Template Delete"
                              data-url="<?php echo e(route('timetable-formats.destroy', $format)); ?>"
                            >
                                <i class="mdi mdi-delete"></i>
                            </button>
                        </div>
                        <div style="min-width:50px"></div>
                        <?php
                            $intervals = generateTimeIntervals(
                                $format->start_time,
                                $format->end_time,
                                $format->time_interval
                            );

                            $width     = 100/count($intervals);

                            $totalMins = getTimeDifferenceInMinutes(
                                $intervals[0]['start'],
                                $intervals[count($intervals)-1]['end']
                            );
                        ?>

                        <div class="d-flex w-100">
                        <?php if($format->timetable_header): ?>
                            <?php $__currentLoopData = json_decode($format->timetable_header); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $widthWithMinutes = getTimeDifferenceInMinutes(
                                        $interval->start,
                                        $interval->end
                                    );

                                    $percentageWithMinutes = ($widthWithMinutes / $totalMins)*100;
                                ?>
                                <div
                                class="d-flex align-items-center flex-column gap-2"
                                style="
                                  border-right: 1px solid gray;
                                  min-width:<?php echo e($percentageWithMinutes); ?>%
                                "
                                >
                                    <small>
                                        <?php echo e($interval->start); ?> ~
                                    </small>
                                    <small>
                                        <?php echo e($interval->end); ?>

                                    </small>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <?php $__currentLoopData = $intervals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div
                                class="d-flex align-items-center flex-column gap-2"
                                style="
                                  border-right: 1px solid gray;
                                  min-width:<?php echo e($width); ?>%
                                "
                                >
                                    <small>
                                        <?php echo e($interval['start']); ?> ~
                                    </small>
                                    <small>
                                        <?php echo e($interval['end']); ?>

                                    </small>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </div>
                    </div>

                    <?php $__currentLoopData = unserialize($format->days); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div
                        class="d-flex py-2 border-bottom">
                            <button
                              data-day="<?php echo e($day); ?>"
                              data-start-date="<?php echo e($format->start_date); ?>"
                              data-end-date  ="<?php echo e($format->end_date); ?>"
                              data-format_id ="<?php echo e($format->id); ?>"
                              data-start-time="<?php echo e($format->start_time); ?>"
                              data-end-time  ="<?php echo e($format->end_time); ?>"
                              style="margin-right: 5px"
                              class="btn text-success add-day-btn"
                            >
                                <i class="mdi mdi-plus"></i>
                            </button>

                            <div
                            style="
                              width:50px;
                              height: <?php echo e(getHeightParent($format->id,$day)); ?>px
                            "
                            class="d-flex align-items-center"
                            >
                                <b><?php echo e($day); ?></b>
                            </div>

                            <div
                              style="
                                position: relative;
                                width: 100%;
                                height: <?php echo e(getHeightParent($format->id,$day)); ?>px
                              "
                            >
                                <?php $__currentLoopData = $format->overallTimetableFormats()->where('day', $day)->orderBy('start_time')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $innerFormat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $disFromStartMin = getTimeIntervalInMinutes(
                                            $innerFormat->start_time,
                                            $format->start_time
                                        );

                                        $percentage = ($disFromStartMin / $totalMins)*100;

                                        $widthWithMinutes = getTimeDifferenceInMinutes(
                                            $innerFormat->start_time,
                                            $innerFormat->end_time
                                        );

                                        $percentageWithMinutes = ($widthWithMinutes / $totalMins)*100;
                                    ?>

                                    <?php if($innerFormat->timetables->count()): ?>
                                        <div
                                        data-url="<?php echo e(route('overall-timetables.show', $innerFormat->id)); ?>"
                                        class="d-flex align-items-center justify-content-center overall-item cursor-pointer"
                                        style="
                                            overflow: hidden;
                                            position: absolute;
                                            top: <?php echo e(getTop($innerFormat)); ?>px;
                                            left: <?php echo e($percentage+0.4); ?>%;
                                            width: <?php echo e($percentageWithMinutes-0.4); ?>%;
                                            height: 35px;
                                            color: white;
                                            background: <?php echo e($innerFormat->subject->color); ?>;
                                        "
                                        >
                                            <?php echo e($innerFormat->subject->short_name??$innerFormat->subject->name); ?>

                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php $__currentLoopData = $format->customTimes->sortBy('start_time'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customTime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($customTime->day == $day): ?>
                                        <?php
                                            $disFromStartMin = getTimeIntervalInMinutes(
                                                $customTime->start_time,
                                                $format->start_time
                                            );

                                            $percentage = ($disFromStartMin / $totalMins)*100;

                                            $widthWithMinutes = getTimeDifferenceInMinutes(
                                                $customTime->start_time,
                                                $customTime->end_time
                                            );

                                            $percentageWithMinutes = ($widthWithMinutes / $totalMins)*100;
                                        ?>

                                        <div
                                        class="d-flex custom-time-item align-items-center justify-content-center cursor-pointer"
                                        style="
                                          overflow: hidden;
                                          position: absolute;
                                          top: 0px;
                                          left: <?php echo e($percentage+0.4); ?>%;
                                          width: <?php echo e($percentageWithMinutes-0.4); ?>%;
                                          height: 35px;
                                          color: white;
                                          background: <?php echo e($customTime->color); ?>;
                                        "
                                        data-url="<?php echo e(route('timetables.custom-time.show', $customTime->id)); ?>"
                                        >
                                            <?php echo e($customTime->title); ?>

                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if(isset($format)): ?>
        <div id="form-modal" class="p-3">
            <form
            action="<?php echo e(route('timetables.submit')); ?>"
            method="POST"
            >
                <?php echo csrf_field(); ?>

                <input type="hidden" name="format_id" id="format_id" value="">
                <input type="hidden" name="start_date" id="start_date" value="">
                <input type="hidden" name="end_date" id="end_date" value="">
                <input type="hidden" name="day" id="day" value="">

                <div id="repeater">
                    <div class="repeater-item">
                        <div class="row">
                            <div class="mb-3 mt-3 col-md-3 mb-0">
                                <div class="form-floating form-floating-outline">
                                    <select name="subjects[]" class="form-select subject-select" required>
                                        <option value=""><?php echo e(__('admin/admin-course.select_subject')); ?></option>
                                        <?php $__currentLoopData = $format->batch->course->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($subject->id); ?>">
                                                <?php echo e($subject->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <label for="attended_class"><?php echo e(__('admin/admin-course.select_subject')); ?></label>
                                </div>
                            </div>

                            <div class="mb-3 mt-3 col-md-3 mb-0">
                                <div class="form-floating form-floating-outline">
                                    <select name="teachers[]" class="form-select teacher-select" required>
                                        <option value="">
                                            <?php echo e(__('admin/admin-live-session.select_teacher')); ?>

                                        </option>

                                    </select>
                                    <label for="attended_class">
                                        <?php echo e(__('admin/admin-live-session.select_teacher')); ?>

                                    </label>
                                </div>
                            </div>

                            <div class="mb-3 mt-3 col-md-2 mb-0">
                                <div class="form-floating form-floating-outline " >
                                    <input
                                    type="time"
                                    class="form-control start-time"
                                    name="start_times[]"
                                    required
                                    />
                                    <label for=""><?php echo e(__('admin/admin-timetable.start_time')); ?></label>
                                </div>
                            </div>

                            <div class="mb-3 mt-3 col-md-2 mb-0">
                                <div class="form-floating form-floating-outline " >
                                    <input
                                    type="time"
                                    class="form-control end-time"
                                    name="end_times[]"
                                    required
                                    />
                                    <label for=""><?php echo e(__('admin/admin-timetable.end_time')); ?></label>
                                </div>
                            </div>

                            <div class="mb-3 mt-3 col-md-2 d-flex align-items-center mb-0">
                                <button type="button" class="btn btn-label-danger waves-effect me-1 remove-btn">
                                    <i class="mdi mdi-close me-1"></i>
                                </button>
                                <button type="button" class="btn btn-label-success waves-effect repeater-add-btn">
                                    <i class="mdi mdi-plus me-1"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div>
                    <a href="javascript:void(0)" class="btn btn-outline-secondary close-btn">
                        <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('close')); ?></span>
                    </a>

                    <button class="btn btn-primary ms-2" id="submit-btn" type="submit">
                        <?php echo e(__('common.submit')); ?>

                    </button>
                </div>
            </form>
        </div>
    <?php endif; ?>

    <div id="detail-modal">
        <button class="float-end btn close-btn">
            <i class="mdi mdi-close"></i>
        </button>
        <div id="detail-content" class="p-3">

        </div>
    </div>

    <div id="detail-modal-1">
        <button class="float-end btn close-btn">
            <i class="mdi mdi-close"></i>
        </button>
        <div id="detail-content-1" class="p-3">

        </div>
    </div>

    <div id="custom-time-model">
        <form method="POST" action="<?php echo e(route('timetables.custom-time.create')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="custom_fromat_id">

            <h4 class="mb-4">
                Add Custom Time
            </h4>

            <div class="form-floating form-floating-outline mb-4">
                <input
                type="text"
                id="title"
                class="form-control"
                placeholder="Enter Title"
                name="title"
                />
                <label for="title">
                    Title
                </label>
            </div>

            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="form-floating form-floating-outline " >
                        <input
                        type="time"
                        id="start-time"
                        class="form-control start-time"
                        name="start_time"
                        />
                        <label for=""><?php echo e(__('admin/admin-timetable.start_time')); ?></label>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-floating form-floating-outline " >
                        <input
                        type="time"
                        id="end-time"
                        class="form-control end-time"
                        name="end_time"
                        />
                        <label for=""><?php echo e(__('admin/admin-timetable.end_time')); ?></label>
                    </div>
                </div>
            </div>

            <div class="form-floating form-floating-outline mb-4">
                <input
                  class="form-control"
                  type ="color"
                  id   ="html5-color-input"
                  name ="color"
                  value="#3569c0"
                />
                <label for="html5-color-input">
                    Color
                </label>
            </div>

            <div id="custom-days" class="d-flex gap-3 flex-wrap mb-4">

            </div>

            <div>
                <a href="javascript:void(0)" class="btn btn-outline-secondary close-btn">
                    <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('close')); ?></span>
                </a>

                <button class="btn btn-primary ms-2" id="submit-btn" type="submit">
                    <?php echo e(__('common.submit')); ?>

                </button>
            </div>
        </form>
    </div>

    <div class="modal-mask"></div>

    <div class="card-header">
        <div class="d-flex align-items-center justify-content-between">
            <h5 class="m-0 p-0">
                Notice Board
            </h5>

            <div>
                <?php if($batch->noticeBoard): ?>
                    <a
                    href="<?php echo e(route('notice-board.edit', $batch->noticeBoard)); ?>"
                    class="btn btn-primary btn-sm"
                    >
                        <span class="mdi mdi-pencil"></span>
                    </a>
                <?php else: ?>
                    <a
                    href="<?php echo e(route('notice-board.create',[
                        'course' => $batch->course->id,
                        'batch' => $batch->id
                    ])); ?>"
                    class="btn btn-success btn-sm"
                    >
                        <span class="mdi mdi-plus"></span>
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <?php if($batch->noticeBoard): ?>
            <div class="custom-content">
                <?php echo $batch->noticeBoard->content; ?>

            </div>
        <?php endif; ?>
    </div>
</div>

<script src="<?php echo e(asset('assets/js/mss-repeater/mss-repeater.js')); ?>"></script>
<script>
    $(function () {
        const teacherAssigns = <?php echo json_encode($teacherAssigns, 15, 512) ?>;
        const batch          = <?php echo json_encode($batch, 15, 512) ?>;

        let startTime;
        let endTime;
        let startDate;
        let endDate;
        let day;

        $('.modal-mask').hide();
        $('#detail-modal').hide();
        $('#detail-modal-1').hide();
        $('#form-modal').hide();
        $('#custom-time-model').hide();


        setMssRepeater(
            { id:'#repeater'}
        );

        $('.add-day-btn').click(function (e) {
            e.preventDefault();

            day       = $(this).data('day');
            startDate = $(this).data('start-date');
            endDate   = $(this).data('end-date');
            startTime = $(this).data('start-time');
            endTime   = $(this).data('end-time');

            $('#format_id').val($(this).data('format_id'));
            $('#start_date').val(startDate);
            $('#end_date').val(endDate);
            $('#day').val(day);

            $('.modal-mask').show();
            $('#form-modal').show();
        });

        $('.close-btn').click(function (e) {
            e.preventDefault();

            $('.modal-mask').hide();
            $('#form-modal').hide();
            $('#detail-modal').hide();
            $('#detail-modal-1').hide();
            $('#custom-time-model').hide();
        });

        $('.start-time').change(function (e) {
            e.preventDefault();
            if (e.target.value+':00' < startTime) {
                Swal.fire({
                    title: "Notice !",
                    text: `Start time cannot be less than ${startTime}!`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText:"confirm",
                    customClass: {
                        confirmButton: 'btn btn-success me-3 waves-effect waves-light',
                        cancelButton: 'btn btn-label-secondary waves-effect'
                    },
                    buttonsStyling: false
                });

                $(this).val('');
            } else if (e.target.value+':00' > endTime) {
                Swal.fire({
                    title: "Notice !",
                    text: `End time cannot be greater than ${endTime}!`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText:"confirm",
                    customClass: {
                        confirmButton: 'btn btn-success me-3 waves-effect waves-light',
                        cancelButton: 'btn btn-label-secondary waves-effect'
                    },
                    buttonsStyling: false
                });

                $(this).val('');
            }
        });

        $('.end-time').change(function (e) {
            e.preventDefault();
            if (e.target.value+':00' > endTime) {
                Swal.fire({
                    title: "Notice !",
                    text: `End time cannot be greater than ${endTime}!`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText:"confirm",
                    customClass: {
                        confirmButton: 'btn btn-success me-3 waves-effect waves-light',
                        cancelButton: 'btn btn-label-secondary waves-effect'
                    },
                    buttonsStyling: false
                });

                $(this).val('');
            } else if (e.target.value+':00' < startTime) {
                Swal.fire({
                    title: "Notice !",
                    text: `Start time cannot be less than ${startTime}!`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText:"confirm",
                    customClass: {
                        confirmButton: 'btn btn-success me-3 waves-effect waves-light',
                        cancelButton: 'btn btn-label-secondary waves-effect'
                    },
                    buttonsStyling: false
                });

                $(this).val('');
            }
        });

        $('.subject-select').change(function (e) {
            e.preventDefault();

            const parentNode    = $(this).parent().parent().parent();
            const teacherSelect = parentNode.find('.teacher-select')

            const subjectId = $(this).val();

            html = `
                <option value="">
                    <?php echo e(__('admin/admin-live-session.select_teacher')); ?>

                </option>
            `;

            teacherAssigns
                .filter(
                    item => item.batch_id == batch.id && item.subject_id == subjectId
                )
                .forEach(item => {
                    html += `
                        <option value="${item.teacher?.id}">${item.teacher?.name}</option>
                    `;
                });

            teacherSelect.html(html);
        });

        $('.custom-time-btn').click(function (e) {
            e.preventDefault();

            startTime = $(this).data('start-time');
            endTime   = $(this).data('end-time');
            formatId  = $(this).data('format-id');
            days      = $(this).data('days');

            let html      = '';
            days.forEach(day => {
                html += `
                <div class="d-flex gap-2">
                    <input
                        name="days[]"
                        id="${day}"
                        value="${day}"
                        type="checkbox"
                        checked
                    />
                    <label for="${day}">
                        ${day}
                    </label>
                </div>
                `;
            });

            $('#custom-days').html(html);

            $('input[name="custom_fromat_id"]').val(formatId);

            $('.modal-mask').show();
            $('#custom-time-model').show();
        });
    });
</script>

<script>
    $(function () {
        $('.overall-item').click(function (e) {
            e.preventDefault();

            const url = $(this).data('url');

            $.ajax({
                type: "GET",
                url: url,
                success: function (response) {
                    $('#detail-content').html(response);
                    $('#detail-modal').show();
                    $('.modal-mask').show();
                }
            });
        });

        $('.custom-time-item').click(function (e) {
            e.preventDefault();

            const url = $(this).data('url');

            $.ajax({
                type: "GET",
                url: url,
                success: function (response) {
                    $('#detail-content-1').html(response);
                    $('#detail-modal-1').show();
                    $('.modal-mask').show();
                }
            });
        });

        $('.template-delete-btn').click(function (e) {
            e.preventDefault();

            const url = $(this).data('url');

            Swal.fire({
                title: "Are you sure?",
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: "Yes, delete it!",
                customClass: {
                    confirmButton: 'btn btn-success me-3 waves-effect waves-light',
                    cancelButton: 'btn btn-label-secondary waves-effect'
                },
                buttonsStyling: false
            }).then(function (result) {
                if (result.value) {
                    $.ajax({
                        type: "GET",
                        url: url,
                        success: function (response) {
                            window.location.reload();
                        }
                    });
                }
            });
        });
    });
</script>

<style>
    .modal-mask{
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,0.6);
        height: 100vh;
        z-index: 1080;
        /* display: none; */
    }

    #form-modal, #detail-modal, #custom-time-model, #detail-modal-1 {
        padding: 10px;
        background: #fff;
        z-index: 1081;
        max-width: 900px;
        max-height: 500px;
        overflow-y: auto;
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        border-radius: 10px;
    }

    #custom-time-model {
        max-width: 500px;
        width: 100%;
    }

    #detail-modal-1 {
        max-width: 600px;
        width: 100%;
    }

    #form-modal {
        width: 100%;
    }
</style>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/timetables/get-formats.blade.php ENDPATH**/ ?>