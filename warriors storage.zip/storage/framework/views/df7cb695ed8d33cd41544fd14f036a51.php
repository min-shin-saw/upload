<style>
    .parent {
        border-right: 1px solid gray;
        position : relative;
    }

    .child {
        display:none;
        transition: all 0.4s;
        z-index: 3;
    }

    .parent:hover .child { display:flex; }

    .modal {
        position: absolute;
        top: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.4);
        z-index: 1;
    }

    .modal-mask {
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,0.6);
        height: 100vh;
        z-index: 1080;
    }

    #form-modal {
        padding: 0 10px 10px 10px;
        background: #fff;
        z-index: 1081;
        max-width: 500px;
        width: 100%;
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        border-radius: 10px;
        max-height: 500px;
        overflow: auto;
    }

    #form-nav {
        position: sticky;
        top: 0%;
        z-index: 200;
        background: #fff;
        padding: 10px 0 6px 0;
    }
</style>

<input type="hidden" name="timetable_headers" id="hidden-headers">
<div id="main-head-time" class="d-flex w-100"></div>

<div id="form-modal">
    <div id="form-nav">
        <button type="button" class="float-end btn close-btn">
            <i class="mdi mdi-close"></i>
        </button>

        <h4>
            Devide time <span id="detail"></span>
        </h4>

        <h5>
            Devide to
            <input
            style="width: 50px"
            type="number"
            id="devider-count"
            >
            times
        </h5>
    </div>

    <div id="form-content" class="p-3"></div>

    <button type="button" id="devider-submit" class="btn float-end btn-sm btn-primary" id="form-submit">Submit</button>
</div>

<div class="modal-mask"></div>

<script>
    $(function () {
        const intervals  = <?php echo json_encode($intervals, 15, 512) ?>;

        let deviderIndex = 0;

        $('.modal-mask').hide();
        $('#form-modal').hide();

        function convertToAmPm(timeStr) {
            // Split the input time string into hours and minutes
            let [hours, minutes] = timeStr.split(':').map(Number);

            // Determine if it is AM or PM
            let period = hours >= 12 ? 'pm' : 'am';

            // Convert hours from 24-hour to 12-hour format
            hours = hours % 12 || 12; // Convert '0' to '12' for midnight and adjust other hours

            // Return the formatted string
            return `${hours < 10 ? '0' : ''}${hours}:${minutes < 10 ? '0' : ''}${minutes} ${period}`;
        }

        function compareTime(inputTime, referenceTime = '09:00 am') {
            const today = new Date().toISOString().split('T')[0]; // Get today's date in YYYY-MM-DD format

            // Create Date objects for the reference time and input time
            const referenceDateTime = new Date(today + ' ' + referenceTime);
            const inputDateTime = new Date(today + ' ' + inputTime);

            if (isNaN(inputDateTime.getTime())) {
                throw new Error('Invalid time format');
            }

            if (inputDateTime < referenceDateTime) {
                return 'less';
            } else if (inputDateTime > referenceDateTime) {
                return 'greater';
            } else {
                return 'equal';
            }
        }


        function getTimeDifferenceInMinutes(startTime, endTime) {
            const today = new Date().toISOString().split('T')[0]; // Get today's date in YYYY-MM-DD format
            const dateTimeStart = new Date(today + ' ' + startTime);
            const dateTimeEnd = new Date(today + ' ' + endTime);

            if (isNaN(dateTimeStart.getTime()) || isNaN(dateTimeEnd.getTime())) {
                throw new Error('Invalid time format');
            }

            const differenceInMilliseconds = dateTimeEnd - dateTimeStart;
            const differenceInMinutes = differenceInMilliseconds / (1000 * 60);
            return differenceInMinutes;
        }

        const totalMins = getTimeDifferenceInMinutes(
            intervals[0]['start'],
            intervals[intervals.length-1]['end']
        );

        function renderHtml() {
            let html = ``;

            $('#hidden-headers').val(JSON.stringify(intervals));

            intervals.forEach((interval, index) => {
                const widthWithMinutes = getTimeDifferenceInMinutes(
                    interval['start'],
                    interval['end']
                );

                const percentageWithMinutes = (widthWithMinutes / totalMins)*100;

                html += `
                    <div class="d-flex align-items-center flex-column gap-2 parent"
                    style="
                    min-width: ${percentageWithMinutes}%;
                    ">
                        <div class="child modal"></div>

                        ${index==(intervals.length -1)
                            ? ''
                            : `
                                <button
                                type="button"
                                style="
                                    width: 14px;
                                    height: 14px;
                                    border-radius: 50%;
                                    justify-content: center;
                                    align-items: center;
                                    padding:0;
                                    outline: none;
                                    focus: none;
                                    border: 0;
                                    position: absolute;
                                    top: 35%;
                                    right: 5%;
                                "
                                title="Merge with next time"
                                class="bg-success text-white child merge-btn"
                                data-index="${index}"
                                >
                                    +
                                </button>
                            `
                        }

                        <button
                        type="button"
                        style="
                            width: 14px;
                            height: 14px;
                            border-radius: 50%;
                            justify-content: center;
                            align-items: center;
                            padding:0;
                            outline: none;
                            focus: none;
                            border: 0;
                            position: absolute;
                            top: 35%;
                        "
                        title="Devide time"
                        class="bg-danger text-white child devide-btn"
                        data-index="${index}"
                        >
                            -
                        </button>

                        <small>
                            ${interval['start']} ~
                        </small>
                        <small>
                            ${interval['end']}
                        </small>
                    </div>
                `;
            });

            $('#main-head-time').html(html);

            $('.merge-btn').click(function (e) {
                e.preventDefault();

                const index = $(this).data('index');

                if((intervals.length-1) !== index) {
                    intervals[index] = {
                        start: intervals[index]['start'],
                        end  : intervals[index+1]['end']
                    }

                    intervals.splice(index+1, 1);

                    renderHtml();
                }
            });

            $('.devide-btn').click(function (e) {
                e.preventDefault();

                deviderIndex = $(this).data('index');

                $('#detail').html(
                    `${intervals[deviderIndex]['start']} ~ ${intervals[deviderIndex]['end']}`
                );

                $('#form-modal').show();
                $('.modal-mask').show();
            });
        }

        renderHtml();

        $('#devider-count').keyup(function (e) {
            e.preventDefault();

            const count = $(this).val();
            let html    = ``;

            for (let i = 0; i < count; i++) {
                html += `
                    <div class="d-flex gap-2 mb-3 align-items-center">
                        <div style="width:220px" class="form-floating w-full form-floating-outline">
                            <input
                              type="time"
                              class="form-control start-time w-full"
                              id="start-time"
                            />
                            <label for="start-time" class="form-label">
                                Start Time
                            </label>
                        </div>
                        -
                        <div style="width:220px" class="form-floating w-full form-floating-outline">
                            <input
                              type="time"
                              class="form-control end-time w-full"
                              id="end-time"
                            />
                            <label for="end-time" class="form-label">
                                End Time
                            </label>
                        </div>
                    </div>
                `;
            }

            $('#form-content').html(html);

            const arr = ['.start-time', '.end-time'];

            arr.forEach((tInput) => {
                $(tInput).change(function (e) {
                    e.preventDefault();

                    if(
                        compareTime($(this).val(),intervals[deviderIndex]['start']) === 'less'
                    ) {

                        Swal.fire({
                            title: "Notice !",
                            text: `End time cannot be less than ${intervals[deviderIndex]['start']}!`,
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonText:"confirm",
                            customClass: {
                                confirmButton: 'btn btn-success me-3 waves-effect waves-light',
                                cancelButton: 'btn btn-label-secondary waves-effect'
                            },
                            buttonsStyling: false
                        });

                        $(this).val('');
                        return;
                    }

                    if(
                        compareTime($(this).val(),intervals[deviderIndex]['end']) === 'greater'
                    ) {

                        Swal.fire({
                            title: "Notice !",
                            text: `End time cannot be greater than ${intervals[deviderIndex]['end']}!`,
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonText:"confirm",
                            customClass: {
                                confirmButton: 'btn btn-success me-3 waves-effect waves-light',
                                cancelButton: 'btn btn-label-secondary waves-effect'
                            },
                            buttonsStyling: false
                        });

                        $(this).val('');
                        return;
                    }

                });
            });
        });

        $('.close-btn').click(function (e) {
            e.preventDefault();

            close();
        });

        $('#devider-submit').click(function (e) {
            e.preventDefault();

            const devidedArray   = [];
            const devidedTimeMin = getTimeDifferenceInMinutes(
                intervals[deviderIndex]['start'], intervals[deviderIndex]['end']
            );

            let status       = true;
            let inputTimeMin = 0;

            $('.start-time').each((index, startTimeInput) => {
                const startTime = $(startTimeInput).val();
                const endTime   = $($('.end-time')[index]).val();

                if (startTime && endTime) {
                    const start = convertToAmPm(startTime);
                    const end   = convertToAmPm(endTime);

                    devidedArray.push({start, end });

                    inputTimeMin += getTimeDifferenceInMinutes(start, end);
                } else {
                    status = false;
                }
            });

            if(!status) {
                Swal.fire({
                    title: "Notice !",
                    text: `Please fill all inputs!`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText:"confirm",
                    customClass: {
                        confirmButton: 'btn btn-success me-3 waves-effect waves-light',
                        cancelButton: 'btn btn-label-secondary waves-effect'
                    },
                    buttonsStyling: false
                });

                return;
            }

            if(devidedTimeMin !== inputTimeMin) {

                Swal.fire({
                    title: "Notice !",
                    text: `Please exactly devide ${intervals[deviderIndex]['start']} and ${intervals[deviderIndex]['end']}!`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText:"confirm",
                    customClass: {
                        confirmButton: 'btn btn-success me-3 waves-effect waves-light',
                        cancelButton: 'btn btn-label-secondary waves-effect'
                    },
                    buttonsStyling: false
                });

                return;
            }

            intervals.splice(deviderIndex, 1, ...devidedArray);

            renderHtml();

            close();
        });

        function close() {
            deviderIndex = 0;
            $('#devider-count').val('');
            $('#form-content').html('');

            $('.modal-mask').hide();
            $('#form-modal').hide();
        }
    });
</script>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/timetables/timetable-header.blade.php ENDPATH**/ ?>