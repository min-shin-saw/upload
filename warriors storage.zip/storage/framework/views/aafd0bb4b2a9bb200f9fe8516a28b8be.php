<div id="social-links" class="content">
    <div class="row g-4">
        <h3><?php echo e(__('admin/admin-teacher.teacher_education_information')); ?></h3>
        <div class="col-md-4 mb-4">
            <div class="form-floating form-floating-outline">
                <input
                type="text"
                id="job_position"
                class="form-control"
                placeholder="Enter Job Position"
                name="job_position"
                value="<?php echo e(isset($teacher)?$teacher->job_position:''); ?>"
                />
                <label for="job_position"><?php echo e(__('admin/admin-teacher.job_position')); ?></label>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="form-floating form-floating-outline">
                <input
                type="text"
                id="education"
                class="form-control"
                placeholder="Enter Education"
                name="education"
                value="<?php echo e(isset($teacher)?$teacher->education:''); ?>"
                />
                <label for="education"><?php echo e(__('admin/admin-teacher.highest_education')); ?></label>
            </div>
        </div>
        <div class="col-md-4 mb-md-3 ">
            <div class="form-floating form-floating-outline">
                <input
                type="text"
                class="form-control date-input"
                placeholder="YYYY-MM-DD"
                id="joined_date"
                name="joined_date"
                value="<?php echo e(isset($teacher)?$teacher->joined_date:''); ?>"
                />
                <label for="joined_date"><?php echo e(__('admin/admin-teacher.joined_date')); ?></label>
            </div>
        </div>
    </div>

    <div class="mb-4">
        <div class="form-floating form-floating-outline mb-2 col-md-4">
            <div class="form-floating form-floating-outline">
                <input
                type="text"
                class="form-control date-input"
                placeholder="YYYY-MM-DD"
                id="teacher_license_expiration_date"
                name="teacher_license_expiration_date"
                value="<?php echo e(isset($teacher->teacher_license_expiration_date) ?$teacher->teacher_license_expiration_date:''); ?>"
                />
                <label for="teacher_license_expiration_date"><?php echo e(__('admin/admin-teacher.teacher_license_expiration_date')); ?></label>
            </div>
        </div>
        <div class="col-md-5">
            <label class="form-label text-black">
                <?php echo e(__("admin/admin-teacher.teacher_upload")); ?>

            </label>
            <input
                type="file"
                name="upload"
                class="dropify"
                data-default-file="<?php echo e(isset($teacher->upload)?get_file($teacher->upload):''); ?>"
                data-allowed-file-extensions='[
                    "png", "PNG", "jpg", "JPG", "jpeg", "JPEG", "pdf", "docx"
                ]'
                >
        </div>
    </div>

    <div class="row">
        <div class="col-12 d-flex justify-content-between">
            <button type="button" class="btn btn-outline-secondary btn-prev">
                <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
                <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('common.previous')); ?></span>
            </button>
            <button type="button" id="pg3-submit" class="btn btn-primary"><?php echo e(__('common.submit')); ?></button>
        </div>
    </div>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/teachers/form-partials/third-step-edu-info.blade.php ENDPATH**/ ?>