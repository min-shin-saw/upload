<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?> / <a
                    href="<?php echo e(route('teachers.index')); ?>"><?php echo e(__('admin/breadcrumb/teacher.teachers')); ?></a> / </span><?php echo e(__('common-breadcrumb.detail')); ?></h4>


        <div class="d-flex justify-content-between  align-items-center mb-3" style="height: 50px">
            <h5 class="card-header  text-primary ">
                <?php echo e(__('admin/admin-teacher.teacher_detail')); ?>

            </h5>
            <?php if($teacher->upload): ?>
                <div class="d-flex align-items-center justify-content-center  h-100">
                    <h6 class="text-secondary  mt-3 me-2">Teacher Upload :</h6>
                    <div class="d-flex align-items-center ">
                        <a 
                            href="<?php echo e(is_null($teacher->upload) ? '':  get_file($teacher->upload)); ?>" 
                            target="_blank" class="btn btn-sm me-2 btn-icon btn-success waves-effect waves-light"
                        >
                            <span class="mdi mdi-file-find"></span>
                        </a>
                        <button 
                            onclick="downloadFile('<?php echo e($teacher->name); ?>.pdf','<?php echo e(is_null($teacher->upload) ? '' : get_file($teacher->upload)); ?>')"
                            class="btn btn-sm btn-icon btn-secondary waves-effect waves-light"
                        >
                            <span class="mdi mdi-download"></span>
                        </button>
                    </div>
                </div>
            <?php endif; ?>
        </div>


        <div class="row">
            <!-- User Sidebar -->
            <div class="col-md-4 border-1 border-md-0">
                <!-- User Card -->
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="user-avatar-section">
                            <div class="d-flex align-items-center flex-column">
                                <?php if($teacher->image): ?>
                                <img class="img-fluid rounded mb-3 mt-4" src="<?php echo e(get_file($teacher->image)); ?>"
                                    height="120" width="120" alt="User avatar" />
                                <?php else: ?> 
                                    <?php echo getFillerImage(140,140); ?>

                                <?php endif; ?>
                                <div class="user-info text-center">
                                    <h4 class="text-primary"><?php echo e($teacher->name); ?></h4>
                                </div>
                            </div>
                        </div>
                        <div class="info-container">
                            <ul class="list-unstyled mb-4">
                                <li class="mb-3">
                                    <span class="fw-semibold text-heading me-2"><?php echo e(__('common.email')); ?>:</span>
                                    <span><?php echo e(!isGeneratedString($teacher->email , 'user') ? $teacher->email : '-'); ?></span>
                                </li>
                                <li class="mb-3">
                                    <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-teacher.phone')); ?>:</span>
                                    <span class=""><?php echo e($teacher->phone); ?></span>
                                </li>
                                <li class="mb-3">
                                    <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-teacher.nrc_detail')); ?>:</span>
                                    <span
                                        class=""><?php echo e($teacher->nrcInfo?->nrc_code .
                                            '/' .
                                            $teacher->nrcInfo?->name_en .
                                            App\Models\School\Nrc::TYPES[$teacher->nrc_type] .
                                            $teacher->nrc); ?></span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- /User Card -->
            </div>
            <!--/ User Sidebar -->

            <!-- User Content -->
            <div class="col-md-4 border-0 border-md-1 mb-4">
                <div class="card">
                    <div class="card-body">
                        <ul class="list-unstyled mb-4">
                            <li class="mb-3">
                                <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-teacher.payment_amount')); ?>:</span>
                                <span><?php echo e($teacher->pay_rate); ?></span>
                            </li>
                            <li class="mb-3">
                                <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-teacher.date_of_birth')); ?>:</span>
                                <span><?php echo e($teacher->formattedDobDate()); ?></span>
                            </li>
                            <li class="mb-3">
                                <span class="fw-semibold text-heading me-2"><?php echo e(__('common.gender')); ?>:</span>
                                <span><?php echo e($teacher->gender); ?></span>
                            </li>
                            <li class="mb-3">
                                <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-teacher.nationality')); ?>:</span>
                                <span><?php echo e($teacher->nationality); ?></span>
                            </li>

                            <li class="mb-3">
                                <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-teacher.address')); ?>:</span>
                                <span><?php echo e($teacher->address); ?></span>
                            </li>

                            <?php if($teacher->marital_status == 'married'): ?>
                                <li class="mb-3">
                                    <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-teacher.husband_or_wife_name_detail')); ?>:</span>
                                    <span><?php echo e($teacher->husband_wife_name); ?></span>
                                </li>
                                <li class="mb-3">
                                    <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-teacher.husband_or_wife_job_detail')); ?>:</span>
                                    <span><?php echo e($teacher->husband_wife_job); ?></span>
                                </li>
                            <?php endif; ?>
                        </ul>

                    </div>
                </div>
            </div>
            <!--/ User Content -->

            <div class="col-md-4 border-0 border-md-1 mb-4">
                <!-- User Card -->
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="text-primary"><?php echo e(__('admin/admin-teacher.parent_information')); ?></h5>
                        <div class="info-container">
                            <li class="mb-3">
                                <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-teacher.name')); ?>:</span>
                                <span><?php echo e($teacher->parent_name); ?></span>
                            </li>

                            <li class="mb-3">
                                <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-teacher.nrc_detail')); ?>:</span>
                                <span
                                    class=""><?php echo e($teacher->parentNrcInfo?->nrc_code .
                                        '/' .
                                        $teacher->parentNrcInfo?->name_en .
                                        App\Models\School\Nrc::TYPES[$teacher->parent_nrc_type] .
                                        $teacher->parent_nrc); ?></span>
                            </li>

                            <li class="mb-3">
                                <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-teacher.job')); ?>:</span>
                                <span class=""><?php echo e($teacher->parent_job??'-'); ?></span>
                            </li>
                        </div>
                    </div>
                </div>
                <!-- /User Card -->
            </div>

            <!-- User Sidebar -->
            <div class="col-md-7 border-1 border-md-0 mb-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="text-primary"><?php echo e(__('admin/admin-teacher.education_information')); ?></h5>
                            <li class="mb-3">
                                <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-teacher.job_position')); ?>:</span>
                                <span><?php echo e($teacher->job_position??'-'); ?></span>
                            </li>
                            <li class="mb-3">
                                <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-teacher.education')); ?>:</span>
                                <span><?php echo e($teacher->education??'-'); ?></span>
                            </li>
                            <li class="mb-3">
                                <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-teacher.teacher_license_expiration_date')); ?>:</span>
                                <span><?php echo e($teacher->formattedTeacherLicenseExpirationDate() ??'-'); ?></span>
                            </li>
                            

                            

                            <li class="mb-3">
                                <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-teacher.joined_date')); ?>:</span>
                                <span><?php echo e($teacher->formattedJoinedDate() ??'-'); ?></span>
                            </li>

                            
                    </div>
                </div>
            </div>
            <!--/ User Sidebar -->

            <!-- User Content -->
            <div class="col-md-5 border-0 border-md-1 mb-4">
                

                
            </div>
            <!--/ User Content -->

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>

    /*
    * @param {string} filename - The filename of the file that will be downloaded
    * @param {string} url      - The file location 
    */

    async   function downloadFile(filename, url) {

                const response = await fetch(url);
                const blob = await response.blob();
                const blobUrl = window.URL.createObjectURL(blob);

                const link = document.createElement('a');
                link.href = blobUrl;
                link.setAttribute('download', filename);
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);

                window.URL.revokeObjectURL(blobUrl);
            }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/teachers/show.blade.php ENDPATH**/ ?>