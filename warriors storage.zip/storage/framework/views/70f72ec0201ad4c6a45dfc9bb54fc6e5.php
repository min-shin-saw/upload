<div class="row">
    <div class="row">
        <div class="col-md-6">
            <div class="form-floating form-floating-outline mb-4">
                <input
                name="name"
                type="text"
                class="form-control"
                id="name"
                placeholder="<?php echo e(__('admin/vaccines/common.vaccine_name_placeholder')); ?>"
                value="<?php echo e(isset($vaccine)? $vaccine->name : ''); ?>"
                required
                >
                <label for="name"><?php echo e(__('admin/vaccines/common.vaccine_name_label')); ?></label>
            </div>

            <div class="form-floating form-floating-outline mb-4">
                <textarea
                name="description"
                class="form-control h-px-150"
                id="description"
                placeholder="<?php echo e(__('admin/vaccines/common.vaccine_description_placeholder')); ?>"><?php echo isset($vaccine)? $vaccine->description : ''; ?></textarea>
                <label for="description"><?php echo e(__('admin/vaccines/common.vaccine_description_label')); ?></label>
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-floating form-floating-outline mb-4">
                <select id="for-gender" name="for_gender" class="form-select form-select-lg overflow-auto mb-4">
                    <option value="" selected disabled><?php echo e(__('admin/vaccines/common.vaccine_gender_placeholder')); ?></option>
                    <option value="both" <?php echo e(isset($vaccine) && $vaccine->for_gender == 'both' ? 'selected' : ''); ?>><?php echo e(__('admin/vaccines/common.vaccine_gender_both')); ?></option>
                    <option value="male" <?php echo e(isset($vaccine) && $vaccine->for_gender == 'male' ? 'selected' : ''); ?>><?php echo e(__('admin/vaccines/common.vaccine_gender_male')); ?></option>
                    <option value="female" <?php echo e(isset($vaccine) && $vaccine->for_gender == 'female' ? 'selected' : ''); ?>><?php echo e(__('admin/vaccines/common.vaccine_gender_female')); ?></option>
                </select>
                <label for="to-users"><?php echo e(__('admin/vaccines/common.vaccine_gender_label')); ?></label>
            </div>
        </div>
    </div>

    <div class="mt-3 d-flex justify-content-between">
        <a href="<?php echo e(route('vaccines.index')); ?>" class="btn btn-outline-secondary">
            <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
            <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('common.back')); ?></span>
        </a>
        <button class="btn btn-primary ms-2" id="submit-btn" type="button">
            Submit
        </button>
    </div>
</div><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/vaccines/form-partials/form.blade.php ENDPATH**/ ?>