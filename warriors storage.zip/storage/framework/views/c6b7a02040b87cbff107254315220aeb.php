<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?> / </span><?php echo e(__('admin/breadcrumb/transaction.transaction_reports')); ?></h4>
        <div class="table-responsive text-nowrap">
            <?php echo $dataTable->table(); ?>

        </div>
    </div>
        <!-- Modal -->
    <div class="modal fade" id="due-date-form" tabindex="-1" aria-labelledby="exampleModalLabel">
        <input type="hidden" id="student-payment-due-date-update-url" value="<?php echo e(route('student-payment-due-date-update-validtion',':id')); ?>">
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('admin/payment/admin-payment.due_date_edit')); ?></h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('student-due-date.update', 'id')); ?>" id="due-date-update-from" method="post">
            <?php echo csrf_field(); ?> 
            <?php echo method_field('PATCH'); ?> 
            <div class="modal-body">
                <input type="date" class="form-control" id="due-date-input" name="due_date" min="<?php echo e(date('Y-m-d')); ?>"> 
            </div>
            <div class="modal-footer col-12">
                <button type="button" id="due-date-submit" class="btn btn-success">Edit</button> 
            </div>
            </form>
        </div>
        </div>
    </div>
    
    
    <!-- Modal Payment Approve -->
    <div class="modal fade" id="payment-approve-form-model" tabindex="-1" aria-labelledby="exampleModalLabel" >
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('admin/payment/admin-payment.payment_approval')); ?>   </h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="student-invoice-img">
                    <img style="width: 100%" class="mb-2" id="student-payment-approval-img" alt="invoice-img">
                </div>
            </div>
            <div class="modal-footer col-12 d-flex justify-content-center">
                <form action="<?php echo e(route('student-transaction.update', ':id' )); ?>" method="post" id="payment-approve-form">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <input type="hidden" name="is_approved"  id="is_approved" value="0">
                    <button type="button" class="btn btn-success approve-btn">Approve</button>
                    <button type="submit" class="btn btn-danger reject-btn">Reject</button>
                </form>
            </div>
        </div>
        </div>
    </div>

 

    <!-- Payment Due Modal -->
    <div class="modal fade" id="payment-due-form-model" tabindex="-1" aria-labelledby="dueModalLabel" >
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="dueModalLabel">Payment Due Notify</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body col-12 d-flex justify-content-center">
                <form action="<?php echo e(route('student-transaction.update', ':id' )); ?>" method="post" id="payment-due-form">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <button type="submit" class="btn  btn-danger">Notify As Due</button>
                </form>
            </div>
        </div>
        </div>
    </div>
    
    <div id="test-table">

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-css-import'); ?>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <?php echo e($dataTable->scripts(attributes: ['type' => 'module'])); ?>

    <script src="<?php echo e(asset('assets/js/transaction-reports/transaction-report-popup.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/transaction-reports/split-payment-popup.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/plugin/moment.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/plugin/daterange-picker.min.js')); ?>"></script>
    <script type="module">
        $(document).ready(function() {
            var firstRow = $('.dt-buttons').parent().addClass('d-flex');
            firstRow.append(`
                <form class="col-8 d-flex" action="<?php echo e(route('transaction-reports.index')); ?>" method="get" >
                    <?php echo csrf_field(); ?>
                    <div class="col-4  ms-3">
                        <select name="filter_option" id="filter-select" class="form-select select2 subject-select" style="height:43px ;" >
                            <option value="all">All</option>
                            <option value="unpaid">Unpaid</option>
                            <option value="pending">Pending</option>
                            <option value="due">Over Due</option>
                            <option value="paid">Paid</option>
                            <option value="due_in_5_day">Due in 5 days</option>
                            <option value="due_in_10_day" selected>Due in 10 days</option>
                        </select>
                    </div>
                    <div class="ms-2 ">
                        <input type="text" name="dates" style="height:43px;" >
                    </div>
                    <button id="filter" class="btn btn-primary btn-sm  ms-2">
                        filter
                    </button>
                </form>
            `)
            
            
            const urlParams = new URLSearchParams(window.location.search);
            let start = '';
            let end =  '';
           
            if (urlParams.size != 0) {
                const filterOptionParam = urlParams.get('filter_option');
                const datesParam = urlParams.get('dates');
                const datePart = datesParam.split(' - ');
                start = datePart[0];
                end =  datePart[1];
                $('#filter-select').val(filterOptionParam);
            }else{
                start = moment().subtract(1, 'month').startOf('month');
                end = moment().add(1, 'month').endOf('month');
            }
         
            
            $('input[name="dates"]').addClass('form-control col-4').daterangepicker({
                startDate: start,
                endDate: end,
                ranges: {
                    'Today': [moment(), moment()],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                }
            });
        })
    </script>,
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/transaction-reports/index.blade.php ENDPATH**/ ?>