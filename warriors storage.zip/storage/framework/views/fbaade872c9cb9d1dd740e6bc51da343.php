<?php if(Session::has('update-success')): ?>
    <script>
        Swal.fire({
            icon: 'success',
            title: 'Success!',
            text: 'Successfully updated!',
            customClass: {
                confirmButton: 'btn btn-success waves-effect'
            }
        });
    </script>
<?php endif; ?>

<?php if(Session::has('student-limit')): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Sorry, you have reached the limit of students!',
            customClass: {
                confirmButton: 'btn btn-success waves-effect'
            }
        });
    </script>
<?php endif; ?>

<?php if(Session::has('school-limit')): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Sorry, you have reached the limit of schools!',
            customClass: {
                confirmButton: 'btn btn-success waves-effect'
            }
        });
    </script>
<?php endif; ?>

<?php if(Session::has('update-student-limit')): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Sorry, you cannot active this student because you have reached the limit of students!',
            customClass: {
                confirmButton: 'btn btn-success waves-effect'
            }
        });
    </script>
<?php endif; ?>

<?php if(Session::has('storage-limit')): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: "Sorry, you don't enough storage!",
            customClass: {
                confirmButton: 'btn btn-success waves-effect'
            }
        });
    </script>
<?php endif; ?>

<?php if(Session::has('guardian-storage-limit')): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: "Sorry, guardian image size is too big, you don't enough storage!",
            customClass: {
                confirmButton: 'btn btn-success waves-effect'
            }
        });
    </script>
<?php endif; ?>

<?php if(Session::has('error')): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: '<?php echo e(Session::get('error')); ?>',
            customClass: {
                confirmButton: 'btn btn-success waves-effect'
            }
        });
    </script>
<?php endif; ?>

<?php if(Session::has('teacher_assigned')): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: '<?php echo e(Session::get('teacher_assigned')); ?>',
            customClass: {
                confirmButton: 'btn btn-success waves-effect'
            }
        });
    </script>
<?php endif; ?>

<?php if(Session::has('success')): ?>
    <script>
        Swal.fire({
            icon: 'success',
            title: 'Success!',
            text: '<?php echo e(Session::get('success')); ?>',
            customClass: {
                confirmButton: 'btn btn-success waves-effect'
            }
        });
    </script>
<?php endif; ?>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/layout/shared/alert-script.blade.php ENDPATH**/ ?>