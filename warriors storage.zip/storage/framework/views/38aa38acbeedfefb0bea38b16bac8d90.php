<div id="additional-fee-repeater">
    <div class="additional-repeater-item">
        <div class="row">
            <div class="mb-3 col-md-2 mb-0">
                <div class="form-floating form-floating-outline">
                    <select name="transaction_name_id[]" class="form-select w-100 transaction-name-dropdown">
                        <option value="">Select Name</option>
                        <?php $__currentLoopData = $transactionNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transactionName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($transactionName->id); ?>"><?php echo e($transactionName->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label for="">Name</label>
                </div>
            </div>

            <div class="mb-3 col-md-2 mb-0">
                <div class="form-floating form-floating-outline ">
                    <input
                    type="number"
                    name="value[]"
                    class="form-control attended_class additional-transaction-value-input"
                    placeholder="Enter Value"
                    />
                    <label for="paymetn">Value</label>
                </div>
            </div>

            <div class="mb-3 col-md-2 mb-0">
                <div class="form-floating form-floating-outline">
                    <select name="additional_payments_status[]" class="form-select w-100 additional-payments-status" data-style="btn-default">
                      <option value="unpaid" selected><?php echo e(__('admin/admin-enrollment.unpaid')); ?></option>
                      <option value="pending"><?php echo e(__('admin/admin-enrollment.paid')); ?></option>
                    </select>
                    <label for=""><?php echo e(__('admin/admin-enrollment.payment_status')); ?></label>
                </div>
            </div>


            <div class="mb-3 col-md-2 mb-0 ">
                <div class="form-floating form-floating-outline">
                    <input name="additional_due_dates[]" type="date" class="form-control additional-due-dates" min="<?php echo e(date('Y-m-d')); ?>">
                     <label for="due_date">Due Date</label>
                </div>
            </div>



            <div class="mb-3 col-md-4 d-flex align-items-center mb-0">
                <button type="button" class="btn btn-label-danger waves-effect me-3 remove-btn addition-payment-delete-btn">
                    <i class="mdi mdi-close me-1"></i>
                    <span class="align-middle">Delete</span>
                </button>
                <button type="button" class="btn btn-label-success waves-effect  addition-add-payment-btn-ini" >
                    <i class="mdi mdi-plus me-1"></i>
                </button>
            </div>

        </div>
    </div>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/enrollments/form-partials/additionalTransaction.blade.php ENDPATH**/ ?>