<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4">
            <span class="text-muted fw-light">
                <?php echo e(__('common-breadcrumb.dashboard')); ?> /
                <a href="<?php echo e(route('timetables.index')); ?>">
                    <?php echo e(__('admin/breadcrumb/timetable.timetable')); ?>

                </a> /
            </span>
            <a href="<?php echo e(route('timetable-formats.index',[
                'course' => $overallTimetableFormat->timetableFormat->batch->course,
            ])); ?>?batch=<?php echo e($overallTimetableFormat->timetableFormat->batch->id); ?>&format=<?php echo e($overallTimetableFormat->timetableFormat->id); ?>">
                <?php echo e($overallTimetableFormat->timetableFormat->batch->course->name); ?>

            </a>
            / Timetables</h5>

        <div class="card mt-3">
            <?php
                $days = [];
                foreach (unserialize($overallTimetableFormat->timetableFormat->days) as $day) {
                    $days[$day] = App\Models\School\TimetableFormat::DAYS[$day];
                }
            ?>
            <div class="card-body">
                <form
                method="POST"
                action="<?php echo e(route('overall-timetables.update',$overallTimetableFormat)); ?>"

                >
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="row">
                        <div class="mb-3 mt-3 col-md-3 mb-0">
                            <div class="form-floating form-floating-outline">

                                <select name="day" class="form-select">
                                    <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                        <?php if($overallTimetableFormat->day == $key): echo 'selected'; endif; ?>
                                        value="<?php echo e($key); ?>">
                                            <?php echo e($value); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label for="attended_class"><?php echo e(__('Day')); ?></label>
                            </div>
                        </div>

                        <div class="mb-3 mt-3 col-md-3 mb-0">
                            <div class="form-floating form-floating-outline">
                                <select name="subject_id" class="form-select">
                                    <option value=""><?php echo e(__('admin/admin-course.select_subject')); ?></option>
                                    <?php $__currentLoopData = $overallTimetableFormat->timetableFormat->batch->course->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                        <?php if($overallTimetableFormat->subject_id == $subject->id): echo 'selected'; endif; ?>
                                        value="<?php echo e($subject->id); ?>">
                                            <?php echo e($subject->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label for="attended_class"><?php echo e(__('admin/admin-course.select_subject')); ?></label>
                            </div>
                        </div>

                        <div class="mb-3 mt-3 col-md-3 mb-0">
                            <div class="form-floating form-floating-outline " >
                                <input
                                  type="time"
                                  class="form-control start-time"
                                  value="<?php echo e($overallTimetableFormat->start_time); ?>"
                                  name="start_time"
                                />
                                <label for=""><?php echo e(__('admin/admin-timetable.start_time')); ?></label>
                            </div>
                        </div>

                        <div class="mb-3 mt-3 col-md-3 mb-0">
                            <div class="form-floating form-floating-outline " >
                                <input
                                  type="time"
                                  class="form-control end-time"
                                  value="<?php echo e($overallTimetableFormat->end_time); ?>"
                                  name="end_time"
                                />
                                <label for=""><?php echo e(__('admin/admin-timetable.end_time')); ?></label>
                            </div>
                        </div>
                    </div>

                    <div>
                        <a href="<?php echo e(route('timetable-formats.index',[
                            'course' => $overallTimetableFormat->timetableFormat->batch->course,
                        ])); ?>?batch=<?php echo e($overallTimetableFormat->timetableFormat->batch->id); ?>&format=<?php echo e($overallTimetableFormat->timetableFormat->id); ?>" class="btn btn-outline-secondary close-btn">
                            <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('back')); ?></span>
                        </a>

                        <button class="btn btn-primary ms-2" id="submit-btn" type="submit">
                            <?php echo e(__('common.submit')); ?>

                        </button>
                    </div>
                </form>
            </div>
        </div>

        <div class="table-responsive text-nowrap mt-3">
            <?php echo $dataTable->table(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <?php echo e($dataTable->scripts(attributes: ['type' => 'module'])); ?>


    <script type="text/javascript" src="<?php echo e(asset('assets/js/plugin/moment.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/plugin/daterange-picker.min.js')); ?>"></script>

    <script type="module">


        $(document).ready(function() {
            /*
            * Get the first row of the datatable
            */
            const firstRow = $('#timetables-table_wrapper .row .col-sm-12').first().addClass('d-flex');

            firstRow.append(`
                <form class="d-flex align-items-center" action="<?php echo e(route('overall-timetables.lists',$overallTimetableFormat)); ?>" method="get" >
                    <div class="ms-2 ">
                        <input type="text" name="dates" style="height:43px;" >
                    </div>
                    <div>
                        <button id="filter" class="btn btn-sm btn-primary ms-2">
                        filter
                    </button>
                        </div>
                </form>
            `);

            const urlParams = new URLSearchParams(window.location.search);

            let start = '';
            let end   =  '';

            if (urlParams.size != 0) {
                const filterOptionParam = urlParams.get('filter_option');
                const datesParam = urlParams.get('dates');

                const datePart = datesParam.split(' - ');

                start = datePart[0];
                end =  datePart[1];

                $('#filter-select').val(filterOptionParam);

            }else{
                start = moment().subtract(1, 'month').startOf('month');
                end = moment().add(1, 'month').endOf('month');
            }


            function setDatePicker(startDate,endDate){
                $('input[name="dates"]').addClass('form-control col-4').daterangepicker({
                    startDate: startDate,
                    endDate: endDate,
                    ranges: {
                        'Today': [moment(), moment()],
                        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                        'This Month': [moment().startOf('month'), moment().endOf('month')],
                        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                    }
                });
            }

            setDatePicker(start, end);


        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/timetables/timetable-lists.blade.php ENDPATH**/ ?>