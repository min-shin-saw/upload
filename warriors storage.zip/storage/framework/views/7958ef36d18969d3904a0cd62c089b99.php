<?php $__env->startSection('container'); ?>

    <input type="hidden" id="student-payment-id" value="<?php echo e($transactions); ?>">
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?> / <a
                    href="<?php echo e(route('student-payments.index')); ?>"><?php echo e(__('admin/breadcrumb/payment.student_payment')); ?></a> / </span><?php echo e(__('common-breadcrumb.detail')); ?></h4>
        <h5 class="card-header mb-3 text-primary"><?php echo e(__('admin/payment/admin-payment.student_payment_detail')); ?></h5>
        <div class="row">
            <div class="col-md-3 col-6 text-center">
                <div class="card">
                    <div class="card-body px-0">
                        <img width="100" class="mb-2" src="<?php echo e(get_file($student->image)); ?>" alt="<?php echo e($student->name); ?>">
                        <div>
                            <b><?php echo e(__('admin/payment/admin-payment.name')); ?>: <a class="text-secondary" href="<?php echo e(route('students.show',$student)); ?>"><?php echo e($student->name); ?></a></b>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-md-3 col-6 text-center">
                <div class="card">
                    <div class="card-body px-0">
                        <img width="130" class="mb-1" src="<?php echo e(get_file($course->image)); ?>" alt="<?php echo e($course->name); ?>">
                        <div class="mb-2">
                            <b><?php echo e(__('admin/payment/admin-payment.course')); ?>: <a class="text-secondary" href="<?php echo e(route('courses.show',$course)); ?>"><?php echo e($course->name); ?></a></b>
                        </div>
                        <div>
                            <b><?php echo e(__('admin/payment/admin-payment.batch')); ?>: <a class="text-secondary" href=""><?php echo e($batch->name); ?></a></b>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body py-2">
                        <div class="row">
                            <div class="col-8">
                                <ul class="list-unstyled ">
                                    <li class="mb-2">
                                        <?php echo e(__('admin/payment/admin-payment.total_amount')); ?>: <?php echo e($payment->formattedTotalAmount()); ?>

                                    </li>
                                    <li class="mb-2">
                                        <?php echo e(__('admin/payment/admin-payment.discount')); ?>:
                                        <?php if($payment->discount): ?>
                                            <?php echo e($payment->discount); ?> %
                                        <?php else: ?>
                                            <?php echo e($payment->formattedTotalDiscountAmount()); ?>

                                        <?php endif; ?>
                                    </li>
                                    <li class="mb-2">
                                        <?php echo e(__('admin/payment/admin-payment.total_net_amount')); ?>: <?php echo e($payment->formattedTotalNetAmount()); ?>

                                    </li>
                                    <li class="mb-2">
                                        <?php echo e(__('admin/payment/admin-payment.total_additional_fee_net_amount')); ?>: <?php echo e($payment->formattedTotalAdditionalFeeNetAmount()); ?>

                                    </li>

                                    <li class="mb-2">
                                        <?php echo e(__('admin/payment/admin-payment.payment_option')); ?>: <?php echo e($payment->payment_option); ?>

                                    </li>
                                    <li class="">
                                        <?php echo e(__('admin/payment/admin-payment.is_fully_paid')); ?>: <?php echo get_is_paid_badge($payment->is_paid); ?>

                                    </li>
                                </ul>
                            </div>
                            <div class="col-4">
                                <div id="chart" class="px-2"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            


            <?php echo $__env->make('admin.enrollments.transactions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

 <!-- Modal -->
<div class="modal fade" id="due-date-form" tabindex="-1" aria-labelledby="exampleModalLabel">
    <input type="hidden" id="student-payment-due-date-update-url" value="<?php echo e(route('student-payment-due-date-update-validtion',':id')); ?>">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('admin/payment/admin-payment.due_date_edit')); ?></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form action="<?php echo e(route('student-due-date.update', 'id')); ?>" id="due-date-update-from" method="post">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PATCH'); ?>
          <div class="modal-body">
            <input type="date" class="form-control" id="due-date-input" name="due_date" min="<?php echo e(date('Y-m-d')); ?>">
          </div>
          <div class="modal-footer col-12">
            <button type="button" id="due-date-submit" class="btn btn-success">Edit</button>
          </div>
        </form>
      </div>
    </div>
  </div>


  <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" >
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('admin/payment/admin-payment.payment_approval')); ?></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div id="student-invoice-img">
                <img style="width: 100%" class="mb-2" id="student-payment-approval-img" alt="invoice-img">
            </div>
            <form action="<?php echo e(route('student-transaction.update', ':id' )); ?>" method="post" id="payment-approve-form" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <div class="container" id="group-transaction-container">
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="">
                            <h5 class="cursor-pointer" onclick="showSelectInput()">Select</h5>
                        </div>
                        <div>
                            <h5 class="cursor-pointer" onclick="showUploadInput()">Upload</h5>
                        </div>
                    </div>

                    <!-- Select Input (Shown by Default) -->
                    <div id="selectInput" class="" >
                        <img src="https://www.google.com/url?sa=i&url=https%3A%2F%2Fen.wikipedia.org%2Fwiki%2FGoogle_Images&psig=AOvVaw315FhqlXqcllCB46bOjWxv&ust=1738048944363000&source=images&cd=vfe&opi=89978449&ved=0CBQQjRxqFwoTCJia1IGvlYsDFQAAAAAdAAAAABAE" 
                        id="transaction-image" alt="" class="text-center" style="width: 100%">
                        <select name="transactionCode" id="group-transaction" class="form-control group-transactions-select2 mt-3" >
                            <?php $__currentLoopData = $verifiedTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $verifiedTransaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($verifiedTransaction->transaction_code); ?>" data-img="<?php echo e($verifiedTransaction->content); ?>">
                                (<?php echo e($verifiedTransaction->date); ?>) <?php echo e($verifiedTransaction->transaction_code); ?>-<?php echo e($verifiedTransaction->transactionName->name ?? 'N/A'); ?> 
                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Upload Input (Hidden by Default) -->
                    <div id="uploadInput" class="mt-3" style="display: none;">
                        <input type="file" name="content" id="content" class="form-control" accept="image/*" disabled=>
                    </div>

                </div>
                <div class="modal-footer col-12 d-flex justify-content-center">
                    <input type="hidden" name="is_approved" value="0">
                    <button type="button" class="btn btn-success approve-btn">Approve</button>
                    <button type="submit" class="btn btn-danger reject-btn">Reject</button>
                </div>
            </form>
      </div>
    </div>
</div>


 
 <div 
 class="modal fade " 
 id="split-payment-model" 
 tabindex="-1" 
 aria-labelledby="exampleModalLabel" 
>
<input type="hidden" id="enrollment-total-text" value="<?php echo e(__('admin/admin-enrollment.total')); ?>">
 <div class="modal-dialog">
     <div class="modal-content" style="width: 800px !important;">
         <div class="modal-header">
            <h5 class="modal-title" id="split-payment-model-title"><?php echo e(__('admin/admin-enrollment.split_payment')); ?></h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
         </div>
         <form 
             method="POST"
             id="split-transaction-form"
             action="<?php echo e(route('split-transaction',':id')); ?>"
         >
             <?php echo csrf_field(); ?>
             <div class="modal-body">
                 <div
                     class="d-flex justify-content-end"
                 >
                     <h6 id='split-payment-total-amount'></h6>
                 </div>
                 <div
                     class="mt-2"
                 >
                     <div  class="col-12  pt-4" id="split-payment-div"  >
                         
                             <div id="split-payment-repeater">
                                 <div class="repeater-item">
                                     <div class="row">
                                         <div class="mb-3 col-3 mb-0">
                                             <div class="form-floating form-floating-outline">
                                                 <input
                                                     type="number"
                                                     name="payments[]"
                                                     class="form-control attended_class"
                                                     placeholder="Enter Payment"
                                                 />
                                                 <label for="paymetn"><?php echo e(__('admin/admin-enrollment.payment_amount')); ?></label>
                                             </div>
                                         </div>
             
                                         <div class="mb-3 col-3  mb-0">
                                             <div class="form-floating form-floating-outline">
                                                 <select name="payments_status[]" class="form-select w-100 payments-status" data-style="btn-default">
                                                 <option value="unpaid" selected><?php echo e(__('admin/admin-enrollment.unpaid')); ?></option>
                                                 <option value="pending"><?php echo e(__('admin/admin-enrollment.paid')); ?></option>
                                                 </select>
                                                 <label for=""><?php echo e(__('admin/admin-enrollment.payment_status')); ?></label>
                                             </div>
                                         </div>
             
             
                                         <div class="mb-3 col-3 mb-0 due_date_div">
                                             <div class="form-floating form-floating-outline">
                                                 <input name="due_dates[]" type="date" class="form-control due-dates" min="<?php echo e(date('Y-m-d')); ?>">
                                                 <label for="due_date">Due Date</label>
                                             </div>
                                         </div>
             
             
             
                                         <div class="mb-3 col-3 d-flex align-items-center mb-0">
                                             <button type="button" class="btn btn-label-danger waves-effect me-3 remove-btn payment-delete-btn">
                                                 <i class="mdi mdi-close me-1"></i>
                                                 <span class="align-middle">Delete</span>
                                             </button>
                                             <button type="button" class="btn btn-label-success waves-effect repeater-add-btn add-payment-btn-ini" >
                                                 <i class="mdi mdi-plus me-1"></i>
                                             </button>
                                         </div>
                                     </div>
                                 </div>
                             </div>
                     </div>
                 </div>
             </div>
             <div class="modal-footer col-12 d-flex justify-content-end">
                 <button class="btn btn-success " id="split-payment-submit-btn">
                     Submit
                 </button>
             </div>
         </form>
     </div>
 </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('teleport'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/js/mss-repeater/mss-repeater.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/student-payment/transaction-student-edit-popup.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/form-handling/data-preparation/student-payment-update-validaton.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/transaction-reports/split-payment-popup.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugin/apexcharts.min.js')); ?>"></script>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <?php echo e($dataTable->scripts(attributes: ['type' => 'module'])); ?>


    <script>
        var options = {
          series: ["<?php echo e($paidPercent); ?>"],
          chart: {
          height: 180,
          type: 'radialBar',
        },
        plotOptions: {
          radialBar: {
            hollow: {
              size: '70%',
            }
          },
        },
        labels: ["<?php echo e(__('admin/payment/admin-payment-status.paid')); ?>"],
        };

        var chart = new ApexCharts(document.querySelector("#chart"), options);
        chart.render();
    </script>
    <script>
        function showUploadInput() {
            document.getElementById('uploadInput').style.display = 'block';
            document.getElementById('selectInput').style.display = 'none';
            document.getElementById('group-transaction').disabled = true;
            document.getElementById('content').disabled = false;
        }

        function showSelectInput() {
            document.getElementById('selectInput').style.display = 'block';
            document.getElementById('uploadInput').style.display = 'none';
            document.getElementById('group-transaction').disabled = false;
            document.getElementById('content').disabled = true;
        }

        document.getElementById('group-transaction').addEventListener('change', function() {
            // Get the selected option
            const selectedOption = this.options[this.selectedIndex];

            // Get the image URL from the "data-image" attribute
            const imgContent = selectedOption.getAttribute('data-img');
            // Update the image src
            document.getElementById('transaction-image').src = imgContent;
        });
    </script>

<script>
    $(function () {
        $('#add-transaction').click(function (e) {
            e.preventDefault();
            const url = $(this).data('url');
            $.ajax({
                type: "GET",
                url: url,
                success: function (response) {
                    $('#additional-transaction-modal .modal-body').html(response);
                    $('#additional-transaction-modal').show();
                    $('.modal-mask').show();
                },
            });
        });

        $('.additional-transaction-modal-close').click(function (e) {
            e.preventDefault();
            $('#additional-transaction-modal .modal-body').html('');
            $('#additional-transaction-modal').hide();
            $('.modal-mask').hide();
        });

        
    });
</script>

<script>
    $(function () {
        $('.approve-btn').click(function (e) {
            e.preventDefault();
            $('[name="is_approved"]').val(1);
            $('#payment-approve-form').submit();
        });
    });

    setMssRepeater({
                id:'#split-payment-repeater',
                unselect: true,
                clicked: () => {
                    let time = parseInt($('#time').val(), 10);
                    $('#time').val(time + 1);
                },
                removing:()=>{
                    let time = parseInt($('#time').val(), 10);
                    $('#time').val(time - 1);
                }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/student-payment/show.blade.php ENDPATH**/ ?>