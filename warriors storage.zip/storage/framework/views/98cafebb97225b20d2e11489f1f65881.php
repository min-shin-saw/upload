<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?> / <a
                    href="<?php echo e(route('subjects.show',$subject)); ?>"><?php echo e($subject->name); ?></a> / </span><?php echo e(__('admin/breadcrumb/lesson.lessons')); ?></h4>
        <div class="card">
        <div class="d-flex align-items-center justify-content-between">
            <h5 class="card-header mb-3 text-primary"><?php echo e($subject->name); ?> <?php echo e(__('admin/breadcrumb/lesson.lessons')); ?></h5>
            <a style="border-bottom-right-radius: 0 !important;border-top-right-radius: 0 !important" class="btn btn-primary btn-sm" href="<?php echo e(route('lessons.create',$subject)); ?>"><span class="mdi mdi-plus"></span></a>
        </div>
            <div class="container-xxl flex-grow-1 py-0 pb-4">
                <div class="table-responsive text-nowrap">
                    <?php echo $dataTable->table(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <?php echo e($dataTable->scripts(attributes: ['type' => 'module'])); ?>

    <script type="module">
        $(function () {
            $('.dt-buttons').parent().parent().remove()
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/lessons/index.blade.php ENDPATH**/ ?>