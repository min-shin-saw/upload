script<?php
    $nrc_datum = App\Models\School\Nrc::all();
?>
<input type="hidden" id="nrc-datum" value="<?php echo e($nrc_datum); ?>">
<!-- jQuery Setup -->
<script src="<?php echo e(asset('assets/vendor/libs/jquery/jquery.js')); ?>"></script>
<!-- jQuery Setup -->

<script src="<?php echo e(asset('assets/vendor/libs/popper/popper.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/node-waves/node-waves.js')); ?>"></script>

<script src="<?php echo e(asset('assets/vendor/libs/hammer/hammer.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/i18n/i18n.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/typeahead-js/typeahead.js')); ?>"></script>


<!-- endbuild -->

<!-- Vendors JS -->
<script src="<?php echo e(asset('assets/vendor/libs/select2/select2.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/bootstrap-select/bootstrap-select.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/typeahead-js/typeahead.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/bloodhound/bloodhound.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/moment/moment.js')); ?>"></script>

<script src="<?php echo e(asset('assets/vendor/libs/bs-stepper/bs-stepper.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/apex-charts/apexcharts.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/swiper/swiper.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/sweetalert2/sweetalert2.js')); ?>"></script>

<script src="<?php echo e(asset('assets/vendor/libs/moment/moment.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/flatpickr/flatpickr.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/jquery-timepicker/jquery-timepicker.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/pickr/pickr.js')); ?>"></script>

<script src="<?php echo e(asset('assets/vendor/js/menu.js')); ?>"></script>

<!-- Main JS -->
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

<!-- Vendor JS -->
<?php echo $__env->yieldContent('custom-vendor-js-import'); ?>

<!-- Page JS -->
<script src="<?php echo e(asset('assets/js/dashboards-analytics.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/extended-ui-sweetalert2.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/forms-selects.js')); ?>"></script>
<!-- <script src="<?php echo e(asset('assets/js/forms-tagify.js')); ?>"></script> -->
<script src="<?php echo e(asset('assets/js/forms-typeahead.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/form-wizard-numbered.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/form-wizard-validation.js')); ?>"></script>

<?php echo $__env->yieldContent('custom-js-import'); ?>

<script src='<?php echo e(asset('assets/js/app.js')); ?>'></script>

<script src="<?php echo e(asset('vendor/mss-js-validation/js/mss-js-validation.min.js')); ?>"></script>

<?php echo $__env->make('layout.shared.alert-script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
    $(function () {
        $(document).on('click', '#drop-down-open', function (e) {
            e.preventDefault();
            $('#drop-down-menu-manual').toggle();
        });
        $(document).on('click', '#language-dropdown', function (e) {
            e.preventDefault();
            $('#language-menu').toggle();
        });
        $(document).on('click', '#getNotificationsButton', function (e) {
            e.preventDefault();
            $('#notificationDropdown').toggle();
        });
    });

</script>

<script src="<?php echo e(asset('assets/js/plugin/simplemde.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugin/html2canvas.min.js')); ?>"></script>

<script>

    const createUserDataFormModule = (config) => {
        const {
            switchId,
            formId,
            userNameId,
            passwordId,
            confirmPasswordId,
            forcePasswordResetId,
            emailId,
            modelId
        } = config;

        const takeLoginAccountSwitch = $(`#${switchId}`);
        const userForm = $(`#${formId}`);
        const userName = $(`#${userNameId}`);
        const password = $(`#${passwordId}`);
        const confirmPassword = $(`#${confirmPasswordId}`);
        const forcePasswordReset = $(`#${forcePasswordResetId}`);
        const email = $(`#${emailId}`);
        const model = $(`#${modelId}`).val();

        const setDefaultValueToUserDataForm = () => {
            userName.val('User-' + Date.now());
            email.val('user' + Date.now() + '@gmail.com');
            password.val('password');
            confirmPassword.val('password');
            forcePasswordReset.prop('checked', true);
        };

        const resetUserDataForm = () => {
            userName.val('');
            email.val('');
            password.val('');
            confirmPassword.val('');
            forcePasswordReset.prop('checked', false);
        };

        const toggleUserFormVisibility = (isVisible) => {
            if (isVisible) {
                userForm.removeClass('complete-hide');
            } else {
                userForm.addClass('complete-hide');
            }
        };

        const updateUserDataForm = (isVisible) => {
            if (isVisible) {
                resetUserDataForm();
            } else {
                setDefaultValueToUserDataForm();
            }
        };

        const init = () => {

            if (!takeLoginAccountSwitch.is(':checked')) {
                userForm.addClass('complete-hide');
            }

            takeLoginAccountSwitch.on('change', function () {
                const isVisible = $(this).is(':checked');
                toggleUserFormVisibility(isVisible);
                if(!model) {  
                    updateUserDataForm(isVisible);
                }
            });

        };

        return {
            init,
            setDefaultValueToUserDataForm,
        };

        
    };


</script>

<?php echo $__env->yieldContent('script'); ?>

<script>
    $(function () {
        if($('.dropify-wrapper').length>0) {
            $('.dropify-wrapper').addClass('border border-1 rounded');
        }
    });
</script>

<script>
    $(function () {
        const adminId = <?php echo json_encode(auth()->id(), 15, 512) ?>;
        $('#tenant-select').change(function (e) {
            e.preventDefault();

            fetch(`/api/${adminId}/tenant-update`, {
                method: "POST",
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                },
                body: JSON.stringify({
                    tenant_id: $('#tenant-select').val()
                })
            })
            .then(response => response.json())
            .then(data => {

                window.location.replace(data.redirect+'?success=1');
            });
        });
    });
</script>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/layout/shared/footer-script.blade.php ENDPATH**/ ?>