<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?> / <a href="<?php echo e(route('batches.index')); ?>"><?php echo e(__('admin/breadcrumb/batch.batches')); ?></a> /
            </span><?php echo e(__('common-breadcrumb.create')); ?></h4>
        <h5 class="card-header mb-3 text-primary"><?php echo e(__('admin/admin-batch.batches_create')); ?></h5>

        <form action="<?php echo e(route('batches.store')); ?>" enctype="multipart/form-data" method="post">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('admin.batches.form-partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo MssValidation::script([
        'request'   => new App\Http\Requests\BatchForm\CreateBatchRequest(),
        'select2'   => true
    ]); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/batches/create.blade.php ENDPATH**/ ?>