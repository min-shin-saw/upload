<?php if(isset($student)): ?>
<div id="social-links" class="content">
    <div class="row g-4">
        <h3><?php echo e(__('admin/admin-student.guardian_title')); ?></h3>

        <div class="col-6 col-md-4 col-lg-3 ">
            <select class="form-control" id="call-guardian-from">
                <option value="exist"><?php echo e(__('admin/admin-student.existed_guardian')); ?></option>
                <option value="new"><?php echo e(__('admin/admin-student.new_guardian')); ?></option>
            </select>
        </div>

        <div class="col-12 exist-guardian">
            <select name="guardian_id" id="student-guardian-select" class="form-control select2" style="width: 100%">
                <?php if(isset($studentGuardian)): ?>
                    <option value="<?php echo e($studentGuardian->id); ?>"  id="studentGuardian">
                        <?php echo e(__('admin/admin-student.name')); ?>: <?php echo e($studentGuardian->name); ?>, <?php echo e(__('admin/admin-student.nrc')); ?>: <?php echo e($studentGuardian->nrc); ?>, <?php echo e(__('admin/admin-student.phone')); ?>: <?php echo e($studentGuardian->phone); ?>,  <?php echo e(__('admin/admin-student.email')); ?>:
                        <?php echo e($studentGuardian->email); ?>

                    </option>
                <?php else: ?>
                    <option value="">Select Existed Guardian Account</option>
                <?php endif; ?>
                <?php $__currentLoopData = $guardians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guardian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($guardian->id); ?>">
                        <?php echo e(__('admin/admin-student.name')); ?>: <?php echo e($guardian->name); ?>, <?php echo e(__('admin/admin-student.nrc')); ?>: <?php echo e($guardian->nrc); ?>, <?php echo e(__('admin/admin-student.phone')); ?>: <?php echo e($guardian->phone); ?>, <?php echo e(__('admin/admin-student.email')); ?>:
                        <?php echo e($guardian->email); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="col-12 new-guardian">
            
            <div class="d-flex gap-3">
                <h5>
                    Take Login Account
                </h5>
                <div class="form-check form-switch">
                    <input class="form-check-input" <?php echo e(isset($studentGuardian) && $studentGuardian->user->take_login_account ? 'checked' : ''); ?> name="guardian_take_login_account" type="checkbox" role="switch" id="take-guardian-login-user-account-switch" aria-checked="true">
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">

                    
                    <div class="form-floating form-floating-outline">
                        <input type="text" id="guardian-name-create" class="form-control" placeholder="Enter Guardian Name"
                            name="guardian_name" />
                        <label for="guardian-name"><?php echo e(__('admin/admin-student.guardian_name')); ?></label>
                    </div>

                    
                    <div class="form-floating form-floating-outline mt-3">
                        <input type="text" id="guardian-phone-create" class="form-control"
                            placeholder="Enter Guardian Phone" name="guardian_phone" />
                        <label for="guardian-phone"><?php echo e(__('admin/admin-student.guardian_phone')); ?></label>
                    </div>

                    
                    <div class="mt-4">
                        <div class="form-floating form-floating-outline input-group">
                            <select class="form-control select2 nrc-code" id="guardian-nrc-code-create" >
                                <option value="0">--</option>
                                <?php $__currentLoopData = $nrc_codes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nrc_code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($nrc_code); ?>"><?php echo e($nrc_code); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <select class="form-control select2 nrc-name" name="guardian_nrc_id" id="guardian-nrc-id-create"></select>
                            <select class="form-control select2" name="guardian_nrc_type" id="guardian-type-create">
                                <?php $__currentLoopData = App\Models\School\Nrc::TYPES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <input type="text" class="form-control" placeholder="Enter Code" name="guardian_nrc" id="guardian-nrc-create" />
                        </div>
                    </div>


                    <div id="guardin-user-from" class="mt-4">

                        
                        <div class="form-floating form-floating-outline">
                            <input type="text" id="guardian-user-name-create" class="form-control" placeholder="Enter Guardian Name"
                                name="guardian_user_name" />
                            <label for="guardian-name"><?php echo e(__('common.user_name')); ?></label>
                        </div>

                        
                        <div class="form-floating form-floating-outline mt-3 ">
                            <input type="email" id="guardian-email-create" class="form-control"
                                placeholder="Enter Guardian Email" name="guardian_email" />
                            <label for="guardian-email"><?php echo e(__('common.email')); ?></label>
                        </div>

                        
                        <div class="mt-3 form-password-toggle fv-plugins-icon-container">
                            <div class="input-group input-group-merge">
                                <div class="form-floating form-floating-outline position-relative">
                                    <i class="mdi mdi-eye-off-outline position-absolute"
                                        style="
                                        cursor: pointer;
                                        right:4%;
                                        top: 15px;
                                        "></i>
                                    <input name="guardian_password" class="form-control" type="password" id="guardian-password-create"
                                        placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;"
                                        required>
                                    <label for="password"><?php echo e(__('common.password')); ?></label>
                                </div>
                            </div>
                        </div>
    
                        
                        <div class="mt-3 form-password-toggle fv-plugins-icon-container">
                            <div class="input-group input-group-merge">
                                <div class="form-floating form-floating-outline position-relative">
                                    <i class="mdi mdi-eye-off-outline position-absolute"
                                        style="
                                        cursor: pointer;
                                        right:4%;
                                        top: 15px;
                                        "></i>
                                    <input name="guardian_confirm_password" class="form-control" type="password"
                                        id="guardian-confirm-password-create"
                                        placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;"
                                        required>
                                    <label for="confirm_password"><?php echo e(__('common.confirm_password')); ?></label>
                                </div>
                            </div>
                        </div>


                        
                        <div class="mt-4 form-password-toggle fv-plugins-icon-container">
                            <div class="input-group input-group-merge">
                                    <div class="form-check">
                                    <input class="form-check-input" name="firsttime_login" type="checkbox"  id="guardian-firsttime-login-create"  >
                                    <label class="form-check-label" for="firsttime_login">
                                        <?php echo e(__('admin/admin-guardian.force_password_reset')); ?>

                                    </label>
                                    </div>
                            </div>
                        </div>

                    </div>

                </div>

                <!-- Custom Icon Radios -->
                <div class="col-md-6">
                    
                    <div class="card shadow-sm py-0">
                        <h5 class="card-header py-3"><?php echo e(__('common.gender')); ?></h5>
                        <div class="card-body py-2">
                            <div class="row">
                                <div class="col-md mb-md-0 mb-2">
                                    <div class="form-check custom-option custom-option-icon">
                                        <label class="form-check-label custom-option-content" for="customRadioIcon1">
                                            <span class="custom-option-body">
                                                <span class="mdi mdi-face-man"></span>
                                                <span class="custom-option-title"><?php echo e(__('common.male')); ?></span>
                                            </span>
                                            <input name="guardian_gender" class="form-check-input" type="radio"
                                                value="male" id="customRadioIcon1" checked />
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md mb-md-0 mb-2">
                                    <div class="form-check custom-option custom-option-icon">
                                        <label class="form-check-label custom-option-content" for="customRadioIcon2">
                                            <span class="custom-option-body">
                                                <span class="mdi mdi-face-woman"></span>
                                                <span class="custom-option-title"><?php echo e(__('common.female')); ?></span>
                                            </span>
                                            <input name="guardian_gender" class="form-check-input" type="radio"
                                                value="female" id="customRadioIcon2" />
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div  class="mt-4">
                        <label class="form-label text-black">
                            <?php echo e(__('admin/admin-student.profile_image')); ?>

                        </label>
                        <input
                        type="file"
                        name="guardian_image"
                        class="dropify"
                        data-allowed-file-extensions='[
                            "png", "PNG", "jpg", "JPG", "jpeg", "JPEG"
                        ]'
                        >
                    </div>
    
                </div>
                
            </div>
        </div>


        <div class="col-12 d-flex justify-content-between">
            <button type="button" class="btn btn-outline-secondary btn-prev">
                <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
                <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('common.previous')); ?></span>
            </button>
            <button type="button" id="pg3-submit" class="btn btn-primary"><?php echo e(__('common.submit')); ?></button>
        </div>

    </div>
</div>
<?php else: ?>
<div id="social-links" class="content">
    <div class="row g-4">
        <h3><?php echo e(__('admin/admin-student.guardian_title')); ?></h3>

        <div class="col-6 col-md-4 col-lg-3">
            <select class="form-control" id="call-guardian-from">
                <option value="exist"><?php echo e(__('admin/admin-student.existed_guardian')); ?></option>
                <option value="new"><?php echo e(__('admin/admin-student.new_guardian')); ?></option>
            </select>
        </div>

        <div class="col-12 exist-guardian">
            <select name="guardian_id"  id="guardian-select-create" class="form-control select2" style="width: 100%">
                <option value=""><?php echo e(__('admin/admin-student.select_existed_guardian_account')); ?></option>
                <?php $__currentLoopData = $guardians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guardian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($guardian->id); ?>">
                        <?php echo e(__('admin/admin-student.name')); ?>: <?php echo e($guardian->name); ?>, <?php echo e(__('admin/admin-student.nrc')); ?>: <?php echo e($guardian->nrc); ?>, <?php echo e(__('admin/admin-student.phone')); ?>: <?php echo e($guardian->phone); ?>, <?php echo e(__('common.email')); ?>:
                        <?php echo e(isGeneratedString($guardian->email,'user') ? '-' : $guardian->email); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="col-12 new-guardian">
             
            <div class="d-flex gap-3">
                <h5>
                    Take Login Account
                </h5>
                <div class="form-check form-switch">
                    <input class="form-check-input" <?php echo e(isset($student) && $student->user->take_login_account ? 'checked' : ''); ?> name="guardian_take_login_account" type="checkbox" role="switch" id="take-guardian-login-user-account-switch" aria-checked="true">
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">

                    
                    <div class="form-floating form-floating-outline">
                        <input type="text" id="guardian-name-create" class="form-control" placeholder="Enter Guardian Name"
                            name="guardian_name" />
                        <label for="guardian-name"><?php echo e(__('admin/admin-student.guardian_name')); ?></label>
                    </div>

                    
                    <div class="form-floating form-floating-outline mt-3">
                        <input type="text" id="guardian-phone-create" class="form-control"
                            placeholder="Enter Guardian Phone" name="guardian_phone" />
                        <label for="guardian-phone"><?php echo e(__('admin/admin-student.guardian_phone')); ?></label>
                    </div>

                    
                    <div class="mt-4">
                        <div class="form-floating form-floating-outline input-group">
                            <select class="form-control select2 nrc-code" id="guardian-nrc-code-create" >
                                <option value="0">--</option>
                                <?php $__currentLoopData = $nrc_codes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nrc_code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($nrc_code); ?>"><?php echo e($nrc_code); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <select class="form-control select2 nrc-name" name="guardian_nrc_id" id="guardian-nrc-id-create"></select>
                            <select class="form-control select2" name="guardian_nrc_type" id="guardian-type-create">
                                <?php $__currentLoopData = App\Models\School\Nrc::TYPES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <input type="text" class="form-control" placeholder="Enter Code" name="guardian_nrc" id="guardian-nrc-create" />
                        </div>
                    </div>


                    <div id="guardin-user-from" class="mt-4">

                        
                        <div class="form-floating form-floating-outline">
                            <input type="text" id="guardian-user-name-create" class="form-control" placeholder="Enter Guardian Name"
                                name="guardian_user_name" />
                            <label for="guardian-name"><?php echo e(__('common.user_name')); ?></label>
                        </div>

                        
                        <div class="form-floating form-floating-outline mt-3 ">
                            <input type="email" id="guardian-email-create" class="form-control"
                                placeholder="Enter Guardian Email" name="guardian_email" />
                            <label for="guardian-email"><?php echo e(__('common.email')); ?></label>
                        </div>

                        
                        <div class="mt-3 form-password-toggle fv-plugins-icon-container">
                            <div class="input-group input-group-merge">
                                <div class="form-floating form-floating-outline position-relative">
                                    <i class="mdi mdi-eye-off-outline position-absolute"
                                        style="
                                        cursor: pointer;
                                        right:4%;
                                        top: 15px;
                                        "></i>
                                    <input name="guardian_password" class="form-control" type="password" id="guardian-password-create"
                                        placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;"
                                        required>
                                    <label for="password"><?php echo e(__('common.password')); ?></label>
                                </div>
                            </div>
                        </div>
    
                        
                        <div class="mt-3 form-password-toggle fv-plugins-icon-container">
                            <div class="input-group input-group-merge">
                                <div class="form-floating form-floating-outline position-relative">
                                    <i class="mdi mdi-eye-off-outline position-absolute"
                                        style="
                                        cursor: pointer;
                                        right:4%;
                                        top: 15px;
                                        "></i>
                                    <input name="guardian_confirm_password" class="form-control" type="password"
                                        id="guardian-confirm-password-create"
                                        placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;"
                                        required>
                                    <label for="confirm_password"><?php echo e(__('common.confirm_password')); ?></label>
                                </div>
                            </div>
                        </div>


                        
                        <div class="mt-4 form-password-toggle fv-plugins-icon-container">
                            <div class="input-group input-group-merge">
                                  <div class="form-check">
                                    <input class="form-check-input" name="firsttime_login" type="checkbox"  id="guardian-firsttime-login-create"  >
                                    <label class="form-check-label" for="firsttime_login">
                                        <?php echo e(__('admin/admin-guardian.force_password_reset')); ?>

                                    </label>
                                  </div>
                            </div>
                        </div>

                    </div>

                </div>

                <!-- Custom Icon Radios -->
                <div class="col-md-6">
                    
                    <div class="card shadow-sm py-0">
                        <h5 class="card-header py-3"><?php echo e(__('common.gender')); ?></h5>
                        <div class="card-body py-2">
                            <div class="row">
                                <div class="col-md mb-md-0 mb-2">
                                    <div class="form-check custom-option custom-option-icon">
                                        <label class="form-check-label custom-option-content" for="customRadioIcon1">
                                            <span class="custom-option-body">
                                                <span class="mdi mdi-face-man"></span>
                                                <span class="custom-option-title"><?php echo e(__('common.male')); ?></span>
                                            </span>
                                            <input name="guardian_gender" class="form-check-input" type="radio"
                                                value="male" id="customRadioIcon1" checked />
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md mb-md-0 mb-2">
                                    <div class="form-check custom-option custom-option-icon">
                                        <label class="form-check-label custom-option-content" for="customRadioIcon2">
                                            <span class="custom-option-body">
                                                <span class="mdi mdi-face-woman"></span>
                                                <span class="custom-option-title"><?php echo e(__('common.female')); ?></span>
                                            </span>
                                            <input name="guardian_gender" class="form-check-input" type="radio"
                                                value="female" id="customRadioIcon2" />
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div  class="mt-4">
                        <label class="form-label text-black">
                            <?php echo e(__('admin/admin-student.profile_image')); ?>

                        </label>
                        <input
                        type="file"
                        name="guardian_image"
                        class="dropify"
                        data-allowed-file-extensions='[
                            "png", "PNG", "jpg", "JPG", "jpeg", "JPEG"
                        ]'
                        >
                    </div>
    
                </div>
                
            </div>
        </div>

        <div class="col-12 d-flex justify-content-between">
            <button type="button" class="btn btn-outline-secondary btn-prev">
                <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
                <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('common.previous')); ?></span>
            </button>
            <button type="button" id="pg3-submit" class="btn btn-primary"><?php echo e(__('common.submit')); ?></button>
        </div>
    </div>
</div>
<?php endif; ?>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/students/form-partials/third-step-guardian-info.blade.php ENDPATH**/ ?>