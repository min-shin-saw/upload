<?php
 use App\Helpers\CustomHelpers;
?>
<div class="d-flex justify-content-end gap-1">
    <button
        title="Activate User Account"
        type="button"
        data-bs-toggle="modal"
        data-bs-target="#activate-account-modal"
        class="btn btn-sm btn-icon btn-secondary waves-effect  waves-light account-activate-btn"
        <?php echo isUserCanActivateAccount($student,'student'); ?>

    >
        <span class="mdi mdi-key-variant"></span>
    </button>
    <a href="<?php echo e(route('students.show',$student->id)); ?>" data-bs-toggle="tooltip" data-bs-placement="top" title="Show" class="btn btn-sm btn-icon btn-success waves-effect waves-light">
        <span class="mdi mdi-information-outline"></span>
    </a>
    <?php if(
        CustomHelpers::has_permission(Auth::user()->role->id, "Student Achievement Records List")
    ): ?>
        <a href="<?php echo e(route('student-achievement-records.index',$student->id)); ?>" class="btn btn-sm btn-icon btn-warning waves-effect waves-light">
            <span class="mdi mdi-seal-variant"></span>
        </a>
    <?php endif; ?>
    <a href="<?php echo e(route('students.edit',$student->id)); ?>" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit"  class="btn btn-sm btn-icon btn-primary waves-effect waves-light">
        <span class="mdi mdi-playlist-edit"></span>
    </a>
    <button
    data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"
    type="button"
    class="btn btn-sm btn-icon btn-danger waves-effect waves-light delete-btn"
    data-url="<?php echo e(route('students.destroy',$student->id)); ?>"
    >
            <span class="mdi mdi-delete-circle" ></span>
    </button>
    
    <script src="<?php echo e(asset('assets/js/delete-sweet-alert.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/activate-account/activate-user-account.js')); ?>"></script>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/students/action.blade.php ENDPATH**/ ?>