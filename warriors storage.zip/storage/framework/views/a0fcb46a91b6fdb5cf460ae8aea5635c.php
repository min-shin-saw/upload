<div>
    <?php if($role_id !== 1): ?>
        <a 
        data-bs-toggle="tooltip" data-bs-placement="top"
        title="Edit"
        href="<?php echo e(route('admins.edit', $id)); ?>" 
        class="btn btn-sm btn-icon btn-primary waves-effect waves-light">
            <span class="mdi mdi-playlist-edit"></span>
        </a>

        <button
        data-bs-toggle="tooltip" data-bs-placement="top"
        title="Delete"
        type="button"
        class="btn btn-sm btn-icon btn-danger waves-effect waves-light delete-btn"
        data-url="<?php echo e(route('admins.destroy',$id)); ?>"
        >
            <span class="mdi mdi-delete-circle"></span>
        </button>
    <?php endif; ?>
    <script src="<?php echo e(asset('assets/js/delete-sweet-alert.js')); ?>"></script>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/admins/action.blade.php ENDPATH**/ ?>