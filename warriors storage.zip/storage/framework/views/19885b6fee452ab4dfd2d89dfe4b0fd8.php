<div id="social-links" class="content">
    <div class="row g-4">
        <h3><?php echo e(__('admin/admin-employee.teacher_education_information')); ?></h3>
        <div class="col-md-6 mb-4">
            <div class="form-floating form-floating-outline">
                <input
                type="text"
                id="current_occupation"
                class="form-control"
                placeholder="Enter Current Occupation"
                name="current_occupation"
                value="<?php echo e(isset($employee)?$employee->current_occupation:''); ?>"
                />
                <label for="current_occupation"><?php echo e(__('admin/admin-employee.current_occupation')); ?></label>
            </div>
        </div>
        <div class="col-md-6 mb-4">
            <div class="form-floating form-floating-outline">
                <input
                type="text"
                id="previous_job"
                class="form-control"
                placeholder="Enter Pervious Job"
                name="previous_job"
                value="<?php echo e(isset($employee)?$employee->previous_job:''); ?>"
                />
                <label for="previous_job"><?php echo e(__('admin/admin-employee.previous_job')); ?></label>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-md-6 mb-4">
            <div class="form-floating form-floating-outline">
                <input
                type="text"
                id="desired_position"
                class="form-control"
                placeholder="Enter Desired Position"
                name="desired_position"
                value="<?php echo e(isset($employee)?$employee->desired_position:''); ?>"
                />
                <label for="desired_position"><?php echo e(__('admin/admin-employee.desired_position')); ?></label>
            </div>
        </div>
    </div>

    <div class="row g-4">

        <div class="col-md-6 mb-4">

            <div class="form-floating form-floating-outline">
                <textarea
                name="education"
                class="form-control h-px-120"
                id="education"
                placeholder="Enter Education"><?php echo e(isset($employee)?$employee->education:''); ?></textarea>
                <label for="education"><?php echo e(__('admin/admin-employee.education')); ?></label>
                <small class="address-error text-danger mt-3"></small>

            </div>

        </div>

        <div class="col-md-6 mb-4">

            <div class="form-floating form-floating-outline">
                <textarea
                name="qualification"
                class="form-control h-px-120"
                id="qualification"
                placeholder="Enter Other Qualification"><?php echo e(isset($employee)?$employee->qualification:''); ?></textarea>
                <label for="qualification"><?php echo e(__('admin/admin-employee.other_qualifications')); ?></label>
                <small class="address-error text-danger mt-3"></small>
            </div>

        </div>

    </div>

    <div class="row g-4">
        <div class="col-md-12 mb-4">
            <div class="form-floating form-floating-outline">
                <textarea
                name="work_experience"
                class="form-control h-px-120"
                id="work_experience"
                placeholder="Enter Work Experience"><?php echo e(isset($employee)?$employee->work_experience:''); ?></textarea>
                <label for="work_experience"><?php echo e(__('admin/admin-employee.work_experience')); ?></label>
                <small class="address-error text-danger mt-3"></small>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12 d-flex justify-content-between">
            <button type="button" class="btn btn-outline-secondary btn-prev">
                <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
                <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('admin/admin-employee.previous')); ?></span>
            </button>
            <button type="button" id="pg3-submit" class="btn btn-primary"><?php echo e(__('admin/admin-employee.next')); ?></button>
        </div>
    </div>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/employees/form-partials/third-step-edu-info.blade.php ENDPATH**/ ?>