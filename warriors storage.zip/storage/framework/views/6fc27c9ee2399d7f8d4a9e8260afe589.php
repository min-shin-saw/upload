<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.dashboard')); ?> / <a
                    href="<?php echo e(route('students.index')); ?>"><?php echo e(__('admin/breadcrumb/student.students')); ?></a> / </span><?php echo e(__("common-breadcrumb.edit")); ?></h4>
        <h5 class="card-header"><?php echo e(__('admin/admin-student.student_edit')); ?></h5>
        <div class="col-12 mb-4">
            <div class="bs-stepper wizard-numbered mt-2">
                <div class="bs-stepper-header">
                    <div class="step" data-target="#account-details">
                        <button type="button" class="step-trigger">
                            <span class="bs-stepper-circle"><i class="mdi mdi-check"></i></span>
                            <span class="bs-stepper-label">
                                <span class="bs-stepper-number">01</span>
                                <span class="d-flex flex-column gap-1 ms-2">
                                    <span class="bs-stepper-title"><?php echo e(__('admin/admin-student.student_info')); ?></span>
                                    <span class="bs-stepper-subtitle">Basic Student Details</span>
                                </span>
                            </span>
                        </button>
                    </div>
                    <div class="line"></div>
                    <div class="step" data-target="#personal-info">
                        <button type="button" class="step-trigger">
                            <span class="bs-stepper-circle"><i class="mdi mdi-check"></i></span>
                            <span class="bs-stepper-label">
                                <span class="bs-stepper-number">02</span>
                                <span class="d-flex flex-column gap-1 ms-2">
                                    <span class="bs-stepper-title"><?php echo e(__('admin/admin-student.parent_info')); ?></span>
                                    <span class="bs-stepper-subtitle">Add Parents info</span>
                                </span>
                            </span>
                        </button>
                    </div>
                    <div class="line"></div>
                    <div class="step" data-target="#social-links">
                        <button type="button" class="step-trigger">
                            <span class="bs-stepper-circle"><i class="mdi mdi-check"></i></span>
                            <span class="bs-stepper-label">
                                <span class="bs-stepper-number">03</span>
                                <span class="d-flex flex-column gap-1 ms-2">
                                    <span class="bs-stepper-title"><?php echo e(__('admin/admin-student.guardian_info')); ?></span>
                                    <span class="bs-stepper-subtitle">Add Guardian</span>
                                </span>
                            </span>
                        </button>
                    </div>
                    
                </div>
                <div class="bs-stepper-content">
                    <input type="hidden" id="unique-student-code-check-url" value="<?php echo e(route('student.unique-student-code')); ?>">
                    <input type="hidden" id="replace-student-code-url" value="<?php echo e(route('student.replace-student-code')); ?>">
                    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
                    <form action="<?php echo e(route('students.update',$student)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <!-- Student Info -->
                        <input type="hidden" value="<?php echo e(route('student-form.first-step.update',$student)); ?>" id="first-step-validation">
                        <?php echo $__env->make('admin.students.form-partials.first-step-student-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <!-- Parents Info -->
                        <input type="hidden" value="<?php echo e(route('student-form.second-step')); ?>" id="second-step-validation">
                        <?php echo $__env->make('admin.students.form-partials.second-step-parent-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <!-- Guardian Info -->
                        <input type="hidden" value="<?php echo e(route('student-form.third-step.exist-guardian')); ?>" id="third-step-exist-guardian-validation">
                        <input type="hidden" value="<?php echo e(route('student-form.third-step.new-guardian')); ?>" id="third-step-new-guardian-validation">
                        <?php echo $__env->make('admin.students.form-partials.third-step-guardian-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script src="<?php echo e(asset(
        'assets/js/form-handling/data-preparation/create-student-first-step.js'
    )); ?>"></script>

    <script src="<?php echo e(asset(
        'assets/js/form-handling/data-preparation/create-student-second-step.js'
    )); ?>"></script>

    <script src="<?php echo e(asset(
        'assets/js/form-handling/data-preparation/create-student-third-step.js'
    )); ?>"></script>

    <script src="<?php echo e(asset('assets/dropify/dropify.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/mohithg-switchery/mohithg-switchery.min.js')); ?>"></script>

    <script>
        $(function() {
            const toggleCheckbox = (selector, currentCheckbox) => {
                const disable = $(currentCheckbox).prop('checked');
                $(selector).prop('disabled', disable);
            }

            const getValues = (type) => {
                const name = $(`#${type}-name`).val();
                const email = $(`#${type}-email`).val();
                const phone = $(`#${type}-phone`).val();
                const nrcId = $(`#${type}-nrc-id-create`).val();
                localStorage.setItem('nrc_id', nrcId);
                const nrcCode = $(`#${type}-nrc-code-create`).val();
                const nrcType = $(`#${type}-nrc-type-create`).val();
                const nrcNumber = $(`#${type}-nrc-create`).val();
                if (type == 'mother') {
                    $('[name=guardian_gender]').eq(0).prop('checked', false); 
                    $('[name=guardian_gender]').eq(1).prop('checked', true);  
                } else {
                    $('[name=guardian_gender]').eq(1).prop('checked', false);
                    $('[name=guardian_gender]').eq(0).prop('checked', true); 
                }
                setValue(name, email, phone, nrcCode, nrcType, nrcNumber);
            }

            const setValue = (name,email,phone,nrc_code,nrc_type,nrc_number)=>{
                $('#guardian-name').val(name);
                $('#guardian-email').val(email);
                $('#guardian-phone').val(phone);
                $('#guardian-nrc-code-edit').select2('val',nrc_code);
                $('#guardian-type-edit').select2('val',nrc_type);
                $('#guardian-nrc-edit').val(nrc_number);
            }

            $('.call-second-step-validation').click(function () {
                let isMother =  $("#carry-mother-as-guardian").is(':checked');
                let isFather = $('#carry-father-as-guardian').is(':checked');
                if (isMother) {
                    getEmailAndheck("[name=mother_email]","mother");
                }else if(isFather){
                    getEmailAndheck("[name=father_email]","father");
                }else{
                    resetForm()
                }
            })

            $("#carry-father-as-guardian").change(function() {
                toggleCheckbox("#carry-mother-as-guardian", this);
            });

            $("#carry-mother-as-guardian").change(function() {
                toggleCheckbox("#carry-father-as-guardian", this);
            });
            let oldGuardian = '';
            let selectTheGuardianWithEmail= (email)=>{
                let selectElement = $('#student-guardian-select');
                let matchFound = false;
                selectElement.find('option').each(function() {
                    var optionEmail = $(this).text().match(/Email:\s*([^\s,]+)/);
                    if (optionEmail) {
                        if (optionEmail[1] === email) {
                            matchFound = true;
                            oldGuardian = $('#studentGuardian').val();
                            // console.log(oldGuardian);
                            selectedIdForGuardian = $(this).val()
                           $('#student-guardian-select').select2("val",selectedIdForGuardian);

                        }
                    }
                });
                return matchFound;
            }


            let getEmailAndheck = (selector,type) => {
                email = $(selector).val();
                isEmailHasGuardian = selectTheGuardianWithEmail(email);
                if (!isEmailHasGuardian ) {
                    $('#guardian-select-create').select2("val",'');
                    $('#call-guardian-from').val('new')
                    $('.exist-guardian').hide();
                    $('.new-guardian').show()
                    // resetForm()
                    getValues(type);
                }else{
                    $('#call-guardian-from').val('exist')
                    $('.exist-guardian').show();
                    $('.new-guardian').hide()
                }
             }

             let resetForm = ()=>{
                $('#guardian-name').val('');
                $('#guardian-email').val('');
                $('#guardian-phone').val('');
                $('#guardian-nrc-code-edit').select2('val',0);
                $('#guardian-type-edit').select2('val','N');
                $('#guardian-nrc-id-edit').select2('val',0)
                $('#guardian-nrc-edit').val('');
                $('#call-guardian-from').val('exist')
                $('.exist-guardian').show();
                $('.new-guardian').hide()
                if (oldGuardian) {
                    $('#student-guardian-select').select2("val",oldGuardian);
                }
             }
        });
    </script>

    <!--Region -->
    <script>
        $(document).ready(function(){

            let cities                      = <?php echo json_encode($cities, 15, 512) ?>;
            let townships                   = <?php echo json_encode($townships, 15, 512) ?>;
            let countrySelect               = $('#country-select');
            let citySelect                  = $('#city-select');
            let townshipSelect              = $('#township-select');
            let defaultTownshipOption       = '<option value="">Select Township</option>';
            let defaultCityOption           = '<option value="">Select City</option>';
            let townshipId                  = <?php echo json_encode($townshipId, 15, 512) ?>;
            let cityId                      = <?php echo json_encode($cityId, 15, 512) ?>;
            let countryId                   = <?php echo json_encode($countryId, 15, 512) ?>;
            let onMounted                   = (fn) => fn();

            let renderUi = (obj,condition,text,oldId = null) =>  {
                let els = `<option value="">${text}</option>`;
                obj.forEach(el => {
                    if(condition(el)){
                        els += `<option value="${el.id}" ${oldId ? oldId == el.id ? 'selected' : '' : ''}>${el.name}</option>`;
                    }
                });
                return els
            }


            countrySelect.change(function(){
                let selectedCountryId = $(this).val();
                citySelect.html(
                    renderUi(cities,(el)=>el.country_id == selectedCountryId,'Select City')
                );
                townshipSelect.html(defaultTownshipOption);
            });

            citySelect.change(function(){
                let selectedCityId = $(this).val();
                townshipSelect.html(
                    renderUi(townships,(el)=>el.city_id == selectedCityId,'Select Township')
                )
            });

            onMounted(()=>{
                if(townshipId){
                    countrySelect.val(countryId).change();
                    citySelect.html(
                        renderUi(cities,(el)=>el.country_id == countryId,'Select City',cityId)
                    );
                    townshipSelect.html(
                        renderUi(townships,(el)=>el.city_id == cityId,'Select Township',townshipId)
                    )
                }
            })

        })
    </script>

    <!-- Plugin -->
    <script>
        $(function () {
            $('.dropify').dropify();

            $('.date-input').flatpickr({
                monthSelectorType: 'static'
            });

            var elems = Array.prototype.slice.call(
                document.querySelectorAll('.switchery')
            );

            elems.forEach(function(html) {
                var switchery = new Switchery(html, {
                    size : 'small',
                    color: '#38D8B2'
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dropify/dropify.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/mohithg-switchery/mohithg-switchery.min.css')); ?>">
    <style>
        .input-group .select2-selection.select2-selection--single {
            border-radius: 0;
        }

        .input-group .select2.select2-container.select2-container--default {
            padding: 0;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('teleport'); ?>
  <div class="modal fade" id="confrim-auto-generated-student-code-edit-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
            <h5 class=" text-primary ">
                Note : Editing auto generated student code !
            </h5>
        </div>

        <div class="modal-body">
            If you edited the student code, this code will be a manual student code and not auto generated.
        </div>

        <div class="modal-footer d-flex justify-content-between">
            <button class="btn btn-sm btn-secondary" id="confirm-auto-generated-student-code-edit-cancel-btn"  data-bs-dismiss="modal">
                cancel
            </button>
            <button class="btn btn-sm btn-primary" id="confrim-auto-generated-student-code-edit-btn">
                Confrim
            </button>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/students/edit.blade.php ENDPATH**/ ?>