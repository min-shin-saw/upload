<div>
    <a
    data-bs-toggle="tooltip" data-bs-placement="top" title="Information"
    href="<?php echo e(route('task.show',[
        'task' => $id,
        'batch_id'   => request('batch_id'),
        'subject_id' => request('subject_id'),
        'teacher_id' => request('teacher_id'),
      ])); ?>" class="btn btn-sm btn-icon btn-success waves-effect waves-light">
        <span class="mdi mdi-information-outline"></span>
    </a>
    <button
    data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"
    type="button"
    class="btn btn-sm btn-icon btn-danger waves-effect waves-light delete-btn"
    data-url="<?php echo e(route('task.delete',$id)); ?>"
    >
            <span class="mdi mdi-delete-circle" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"></span>
    </button>
    <script src="<?php echo e(asset('assets/js/delete-sweet-alert.js')); ?>"></script>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/tasks/action.blade.php ENDPATH**/ ?>