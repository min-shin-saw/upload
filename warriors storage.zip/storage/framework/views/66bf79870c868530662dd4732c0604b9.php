<?php $__env->startSection('container'); ?>
    <div class="col-12">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Admins / <a href="<?php echo e(route('roles.index')); ?>">Roles</a> /</span> Create</h4>
        <div class="card p-4">
            <form method="POST" action="<?php echo e(route('roles.update', $role)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <div class="form-floating form-floating-outline mb-4">
                    <input type="text" class="form-control" id="floatingInput" placeholder="Admin,School..." name="name"
                        value="<?php echo e(old('name', isset($role) ? $role->name : '')); ?>" aria-describedby="floatingInputHelp" />
                    <label for="floatingInput">Role Name</label>
                </div>

                <div class="col-md mb-3 mb-md-2">
                    <div class="align-items-center ">
                        <p class="text-light fw-semibold mb-5">Select Permissions</p>
                        <div class="px-3">
                            <?php
                                $allPermissions = App\Models\Admin\Permission::whereNotIn('group_name',['Admin', 'Role', 'User','Academic Cycle', 'Student Batch', 'Student Bill','Fee Type', 'Fee', 'Discount Type', 'Discount', 'Payment Method', 'Payment Term Type','Schedule', 'Transaction'])->whereNotIn('name',['schools.index', 'schools.create', 'schools.destroy'])->get();
                            ?>

                            <input type="checkbox"
                                class="form-check-input selector ms-1 me-3"
                                id="all-permission"
                                <?php echo e(role_has_permissions_to($role,$allPermissions)?'checked':''); ?>

                                >
                            <label class=" fw-semibold">
                                All Permissions <i class="input-helper"></i>
                            <label>

                        </div>
                    </div>

                    <div class="accordion mt-3" id="accordionExample">
                        <?php $__currentLoopData = $permissionGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permissionGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!in_array($permissionGroup->group_name,App\Models\Admin\Permission::HIDDENFIELDS)): ?>
                                <?php
                                    $permissions = get_permissions_by_group_name($permissionGroup->group_name)
                                ?>
                                <div class="accordion-item ">

                                    <div class="accordion-header ps-3 d-flex align-items-center" id="headingOne">
                                        <?php
                                            $permissions = get_permissions_by_group_name($permissionGroup->group_name)
                                        ?>

                                        <input type="checkbox"
                                        class="form-check-input permission-offcanvas-body-item-body selector ms-1"
                                        data-selector="<?php echo e(Str::slug($permissionGroup->group_name, '-')); ?>"
                                        <?php echo e(role_has_permissions_to($role,$permissions)?'checked':''); ?>

                                        <?php if($permissionGroup->group_name == 'School'): ?>
                                            <?php echo e(role_has_permissions_to($role, [App\Models\Admin\Permission::find(13),App\Models\Admin\Permission::find(15)])?'checked':''); ?>

                                        <?php endif; ?>
                                        >

                                        <button type="button"
                                        class="accordion-button <?php echo e(role_has_permissions_to($role,$permissions)?'':'collapsed'); ?>"
                                        data-bs-toggle="collapse"
                                        data-bs-target="#accordion-<?php echo e(Str::slug($permissionGroup->group_name, '-')); ?>"
                                        aria-expanded="<?php echo e($key === 0?'true':'false'); ?>"
                                        aria-controls="accordion-<?php echo e(Str::slug($permissionGroup->group_name, '-')); ?>"
                                        >
                                            <?php echo e($permissionGroup->group_name); ?>

                                        </button>
                                    </div>

                                    <div id="accordion-<?php echo e(Str::slug($permissionGroup->group_name, '-')); ?>" class="accordion-collapse collapse <?php echo e(role_has_permission_to($role,$permissions)?'show':''); ?>">
                                        <div class="accordion-body">


                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!in_array($permission->name,App\Models\Admin\Permission::HIDDENSPECIFICPERMISSIONS)): ?>
                                                <div class="form-check form-check-flat d-inline-block me-2">
                                                    <label class="form-check-label">
                                                    <input type="checkbox"
                                                        class="form-check-input permission-offcanvas-body-item-body <?php echo e(Str::slug($permissionGroup->group_name, '-')); ?>"
                                                        name="permissions[]" value="<?php echo e($permission->id); ?>" <?php if($role->checkPermissionById($permission->id)): ?> <?php echo e('checked'); ?> <?php endif; ?> >
                                                        <?php echo e($permission->alter_name); ?></label>
                                                </div>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="mt-3 d-flex justify-content-between">
                        <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-outline-secondary">
                            <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
                            <span class="align-middle d-sm-inline-block d-none">Back</span>
                        </a>

                        <button class="btn btn-primary ms-2" id="submit-btn" type="submit">
                            Submit
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/js/admin/pages/role.blade.js')); ?>"></script>
    <script>
        $('#all-permission').change(function (e) {
            e.preventDefault();
            $(`input:checkbox`).prop('checked',$(this).prop('checked'));
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/roles/edit.blade.php ENDPATH**/ ?>