<div class="row">
 
    <div class="col-md-12">
        
        <div class="d-flex gap-3">
            <h5>
                Take Login Account
            </h5>
            <div class="form-check form-switch">
                <input class="form-check-input" <?php echo e(isset($guardian) && $guardian->user->take_login_account ? 'checked' : ''); ?> name="take_login_account" type="checkbox" role="switch" id="take-login-account-switch" aria-checked="true">
            </div>
        </div>
    </div>
    <div class="col-md-6">

        <div class="form-floating form-floating-outline">
            <input type="text" id="guardian-name" class="form-control" placeholder="Enter Guardian Name" name="guardian_name" value="<?php echo e(isset($guardian)?$guardian->name:''); ?>" />
            <label for="name"><?php echo e(__('admin/admin-guardian.guardian_name')); ?></label>
        </div>

        <div class="form-floating form-floating-outline mt-3">
            <input type="text" id="guardian-phone" class="form-control" placeholder="Enter Guardian Phone" name="phone" value="<?php echo e(isset($guardian)?$guardian->phone:''); ?>" />
            <label for="guardian-phone"><?php echo e(__('admin/admin-guardian.guardian_phone')); ?></label>
        </div>

          
          <div class="mt-4">
            <div class="form-floating form-floating-outline input-group">
                <select class="form-control select2 nrc-code">
                    <option value="0">--</option>
                    <?php $__currentLoopData = $nrc_codes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nrc_code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($nrc_code); ?>" <?php if(isset($guardian)): ?> <?php echo e($guardian->nrcInfo?->nrc_code ==  $nrc_code? 'selected' : ''); ?> <?php endif; ?>><?php echo e($nrc_code); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if(isset($guardian)): ?>
                <?php
                $nrcs = App\Models\School\Nrc::where('nrc_code', $guardian->nrcInfo?->nrc_code)->get();
                ?>
                <select class="form-control select2 nrc-name" name="nrc_id" id="">
                    <?php $__currentLoopData = $nrcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nrc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($nrc->id); ?>" <?php if($nrc->id == $guardian->nrc_id): echo 'selected'; endif; ?>><?php echo e($nrc->name_en); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php else: ?>
                <select class="form-control select2 nrc-name" name="nrc_id" id=""></select>
                <?php endif; ?>

                <select class="form-control select2" name="nrc_type" id="nrc_type">
                    <?php $__currentLoopData = App\Models\School\Nrc::TYPES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>" <?php if(isset($guardian)): ?> <?php echo e($key == $guardian->nrc_type?'selected':''); ?> <?php endif; ?>><?php echo e($value); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <input type="text" class="form-control" placeholder="Enter Code" name="nrc" id="nrc" value="<?php echo e(isset($guardian)?$guardian->nrc:''); ?>" />
            </div>
        </div>

        <div id="user-from" class="mt-3">

            <div class="form-floating form-floating-outline">
                <input type="text" id="user-name" class="form-control" placeholder="Enter Guardian Name" name="user_name" value="<?php echo e(isset($guardian)?shouldShowInputValue($guardian->user->name,$guardian->user->take_login_account)? $guardian->user->name : '':''); ?>" />
                <label for="name"><?php echo e(__('common.user_name')); ?></label>
            </div>

            <div class="form-floating form-floating-outline mt-3">
                <input type="email" id="email" class="form-control" placeholder="Enter Guardian Email" name="email" value="<?php echo e(isset($guardian)?shouldShowInputValue($guardian->user->email,$guardian->user->take_login_account) ? $guardian->user->email : '':''); ?>" />
                <label for="guardian-email"><?php echo e(__('common.email')); ?></label>
            </div>

             
            <div class="mt-3 form-password-toggle fv-plugins-icon-container">
                <div class="input-group input-group-merge">
                    <div class="form-floating form-floating-outline position-relative">
                        <i class="mdi mdi-eye-off-outline position-absolute" style="
                                cursor: pointer;
                                right:4%;
                                top: 15px;
                                "></i>
                        <input name="password" class="form-control" type="password" id="password" placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;">
                        <label for="password"><?php echo e(__('common.password')); ?></label>
                    </div>
                </div>
            </div>

            
            <div class="mt-3 form-password-toggle fv-plugins-icon-container">
                <div class="input-group input-group-merge">
                    <div class="form-floating form-floating-outline position-relative">
                        <i class="mdi mdi-eye-off-outline position-absolute" style="
                                cursor: pointer;
                                right:4%;
                                top: 15px;
                                "></i>
                        <input name="confirm_password" class="form-control" type="password" id="confirm-password" placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;">
                        <label for="confirm_password"><?php echo e(__('common.confirm_password')); ?></label>
                    </div>
                </div>
            </div>

            
            <div class="mt-4 form-password-toggle fv-plugins-icon-container">
                <div class="input-group input-group-merge">
                    <div class="form-check">
                        <?php
                        if (isset($guardian)) {
                            $isFirstTimeLogin = $guardian->user->firsttime_login;
                        } else {
                            $isFirstTimeLogin = false;
                        }
                        ?>
                        <input class="form-check-input" name="firsttime_login" type="checkbox" id="firsttime_login" <?php echo $isFirstTimeLogin ? 'checked' : ''; ?>>
                        <label class="form-check-label" for="firsttime_login">
                            <?php echo e(__('admin/admin-guardian.force_password_reset')); ?>

                        </label>
                    </div>
                </div>
            </div>

        </div>

        

    </div>

    <!-- Custom Icon Radios -->
    <div class="col-md-6">
        <div class="card shadow-sm py-0">
            <h5 class="card-header py-3"><?php echo e(__('common.gender')); ?></h5>
            <div class="card-body py-2">
                <div class="row">
                    <div class="col-md mb-md-0 mb-2">
                        <div class="form-check custom-option custom-option-icon">
                            <label class="form-check-label custom-option-content" for="customRadioIcon1">
                                <span class="custom-option-body">
                                    <span class="mdi mdi-face-man"></span>
                                    <span class="custom-option-title"><?php echo e(__('common.male')); ?></span>
                                </span>
                                <input name="gender" class="form-check-input" type="radio" value="male" id="customRadioIcon1" <?php if(isset($guardian)): ?> <?php echo e($guardian->gender == 'male'?'checked':''); ?> <?php else: ?> <?php echo e('checked'); ?> <?php endif; ?> />
                            </label>
                        </div>
                    </div>
                    <div class="col-md mb-md-0 mb-2">
                        <div class="form-check custom-option custom-option-icon">
                            <label class="form-check-label custom-option-content" for="customRadioIcon2">
                                <span class="custom-option-body">
                                    <span class="mdi mdi-face-woman"></span>
                                    <span class="custom-option-title"><?php echo e(__('common.female')); ?></span>
                                </span>
                                <input name="gender" class="form-check-input" type="radio" value="female" id="customRadioIcon2" <?php if(isset($guardian)): ?> <?php echo e($guardian->gender == 'female'?'checked':''); ?> <?php endif; ?> />
                            </label>
                        </div>
                    </div>
                </div>
            </div>
        </div>

          
        <div class="mt-3">
            <label class="form-label text-black">
                Profile Image
            </label>
            <input type="file" name="image" class="dropify" data-default-file="<?php echo e(isset($guardian->image)?get_file($guardian->image):''); ?>" data-allowed-file-extensions='[
                    "png", "PNG", "jpg", "JPG", "jpeg", "JPEG"
                ]'>
        </div>

    </div>


  

    <div class="col-12">
        <div class="mt-3 d-flex justify-content-between">
            <a href="<?php echo e(route('guardians.index')); ?>" class="btn btn-outline-secondary">
                <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
                <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('common.back')); ?></span>
            </a>
            <button
            class="btn btn-primary ms-2 d-none"
            id="load-btn"
            type="button"
            >
                <span class="spinner-border me-1" role="status" aria-hidden="true"></span>
                Processing...
            </button>
            <button class="btn btn-primary ms-2" id="submit-btn" type="button">
                <?php echo e(__('common.submit')); ?>

            </button>
        </div>
    </div>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/guardians/form-partial/form.blade.php ENDPATH**/ ?>