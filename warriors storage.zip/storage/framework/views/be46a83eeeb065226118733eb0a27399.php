<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">CMS / </span> Admin-Panel-Settings
        </h4>

        <form class="mt-3"
        method="post"
        enctype="multipart/form-data"
        action="<?php echo e(route('settings.update')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <input type="hidden" name="_page" value="admin">
            <div class="card mb-4">
                <div class="card-body">
                    <h5 class="card-title">Admin Panel</h5>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label text-black">
                                Login Auth Logo
                            </label>
                            <input
                            type="file"
                            class="dropify"
                            name="admin-auth-logo"
                            data-default-file="<?php echo e(asset(config('settings.admin-auth-logo'))); ?>"
                            data-allowed-file-extensions='[
                                "png", "PNG", "jpg", "JPG", "jpeg", "JPEG"
                            ]'
                            >
                        </div>

                        <div class="col-md-4 mb-3">
                            <label class="form-label text-black">
                                Logo
                            </label>
                            <input
                            type="file"
                            class="dropify"
                            name="admin-logo"
                            data-default-file="<?php echo e(asset(config('settings.admin-logo'))); ?>"
                            data-allowed-file-extensions='[
                                "png", "PNG", "jpg", "JPG", "jpeg", "JPEG"
                            ]'
                            >
                        </div>

                        <div class="col-md-4 mb-3">
                            <label class="form-label text-black">
                                Text Logo
                            </label>
                            <input
                            type="file"
                            class="dropify"
                            name="admin-logo-text"
                            data-default-file="<?php echo e(asset(config('settings.admin-logo-text'))); ?>"
                            data-allowed-file-extensions='[
                                "png", "PNG", "jpg", "JPG", "jpeg", "JPEG"
                            ]'
                            >
                        </div>
                    </div>
                    <div class="text-end">
                        <button class="btn btn-primary btn-sm">Save</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/dropify/dropify.min.js')); ?>"></script>

    <script>
        $(function () {
            $('.dropify').dropify();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dropify/dropify.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/CMS/admin-panel/index.blade.php ENDPATH**/ ?>