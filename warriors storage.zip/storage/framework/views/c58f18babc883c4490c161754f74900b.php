<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?> / <a
                    href="<?php echo e(route('ferries.index')); ?>"> <?php echo e(__('admin/breadcrumb/ferry.ferry')); ?></a> / </span><?php echo e(__('common-breadcrumb.create')); ?>

        </h4>
        <h5 class="card-header"><?php echo e(__('admin/admin-ferry.ferry_create')); ?></h5>
        <div class="card mt-3">
            <form class=" card-body" enctype="multipart/form-data" action="<?php echo e(route('ferries.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo $__env->make('admin.ferries.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/dropify/dropify.min.js')); ?>"></script>
<script>
    let townships  = <?php echo json_encode($townships, 15, 512) ?>;


    $('#city-select').change(function(){
        let html = '<option value="" selected disabled><?php echo e(__('admin/admin-ferry.select_township')); ?></option>';
        townships.map((township) => {
            if(township.city_id == $(this).val()){
                html += `<option value="${township.id}">${township.name}</option>`;
            }
        })
        $('#township-select').html(html);
        $('#township-select').select2();
    });

    $('.dropify').dropify({
        error : {
            'fileExtension' : "<?php echo e(__('validation.image_type')); ?>",
        }
    });
    $('#select2Basic').select2();

</script>

<script>
    $(function () {
        const submitBtn = $('#submit-btn');
      
        const keys = [
            'city_id',
            'township_id',
            'driver_phone_number',
            'driver_name',
            'car_platenumber',
            'car_model',
            'driver_image',
            'driver_address',
            'driver_license',
            'seat_count',
            'remark'
        ]

        submitBtn.click(function (e) {
            // console.log(validationUrl);
            e.preventDefault();

            validate({
                keys: keys,
                url: '<?php echo e(route('ferry-validation')); ?>',
                submit: true,
                select2 : true
            })
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/dropify/dropify.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/ferries/create.blade.php ENDPATH**/ ?>