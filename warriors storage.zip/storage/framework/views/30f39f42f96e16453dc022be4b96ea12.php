<?php $__env->startSection('container'); ?>

<div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold py-3 mb-4">
        <span class="text-muted fw-light">
            <?php echo e(__('common-breadcrumb.dashboard')); ?> /
            <a href="<?php echo e(route('tasks.index')); ?>">
                <?php echo e(__('admin/admin-side-bar.task')); ?>

            </a> /

            <a
            href="<?php echo e(route('tasks.list.index',[
                'course'     => $task->batch->course->id,
                'batch_id'   => request('batch_id'),
                'subject_id' => request('subject_id'),
                'teacher_id' => request('teacher_id'),
              ])); ?>"
            >
                <?php echo e($task->batch->course->name); ?>

            </a>
        </span> /

        <?php echo e($task->name); ?>

    </h4>

    <h4>
        Student List
    </h4>

    <table class="table table-bordered rounded">
        <tr>
            <th>
                Name
            </th>
            <th>
                Image
            </th>
            <th>
               Submission
            </th>
            <th>
                Action
            </th>
        </tr>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($student->name); ?></td>
                <td>
                    <img width="70" src="<?php echo e($student->image); ?>" alt="<?php echo e($student->name); ?>">
                </td>
                <td>
                    <?php if($student->submission && $student->submission->submission_url): ?>
                        <a href='<?php echo e($student->submission->submission_url); ?>' target='blank' class=''>
                            <span class='mdi mdi-download'></span>
                            view
                        </a>
                    <?php else: ?>
                       ---
                    <?php endif; ?>
                </td>

                <td>
                    <?php if($student->submission): ?>

                        <?php if($student->submission->submission_checked !== "checked"): ?>
                            <a href="<?php echo e(route('task.finish',['task'=>$task,'student'=>$student->id,'submission_id'=> $student->submission?->submission_id])); ?>" class="btn btn-sm btn-primary waves-effect waves-light">
                                Finish
                            </a>
                        <?php else: ?>
                            <button class="btn p-2 py-1 btn-sm btn-success waves-effect waves-light">
                                <small>
                                    <span style="font-size: 5px" class="mdi mdi-check"></span>Finished
                                </small>
                            </button>
                        <?php endif; ?>


                        <?php if($student->submission->submission_url): ?>
                            <a target="blank" class="btn btn-sm btn-warning waves-effect waves-light" href="<?php echo e($student->submission->submission_url); ?>">
                                <small>view</small>
                            </a>

                            <?php if($student->submission->submission_checked !== "checked"): ?>
                            <a href="<?php echo e(route('task.cancel-submission',$student->submission->submission_id)); ?>" class="btn btn-sm btn-danger waves-effect waves-light">
                                <span class="mdi mdi-delete"></span>
                            </a>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php else: ?>
                        <a href="<?php echo e(route('task.finish',['task'=>$task,'student'=>$student->id,'submission_id'=> $student->submission?->submission_id])); ?>" class="btn btn-sm btn-primary waves-effect waves-light">
                            Finish
                        </a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/task/show.blade.php ENDPATH**/ ?>