<div class="mb-4 flex justify-content-between ">
    <button class="btn btn-sm btn-secondary text-white btn shadow"  id="back-to-list">
        <span class="mdi mdi-arrow-left me-2"></span>
        Back To List
    </button>
</div>

<div class="card">
    <div class="card-header d-flex justify-content-between">
        <h4 class="text-primary fw-bold ">
            Bulk Import Validation Errors
        </h4>
        <div>
            <button
            data-bs-toggle="modal"
            data-bs-target="#exampleModal"
            id="excel-file-validation-input-btn"
            class="btn btn-sm btn-primary"
            >
                <span class="mdi mdi-file-import me-2"></span>
                import Again
            </button>
        </div>
    </div>
    <div class="card-body import-error-lists">
        
    </div>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/components/bulkimportissuelist.blade.php ENDPATH**/ ?>