<div>
    <a 
    id="student-attendance-report" 
    data-bs-toggle="tooltip" data-bs-placement="top"
    title="Check"
    class="btn btn-sm btn-icon btn-success waves-effect waves-light" 
        href="<?php echo e(route('student-attendance-report',[
            'course'     => $enrollment->course_id,
            'batch'      => $enrollment->batch_id,
            'student'    => $enrollment->student_id,
            'percent'    => $percent,
            'dates'      => $dates
        ])); ?>">
        <span class="mdi mdi-account-multiple-check"></span>
    </a>
</div><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/attendance-reports/action.blade.php ENDPATH**/ ?>