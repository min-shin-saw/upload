<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Admin / <a href="<?php echo e(route('schools.index')); ?>">Schools</a> / </span>Create</h4>

        <div class="card mb-4">
            <h5 class="card-header">School Registration</h5>
            <div class="card-body">

                <form method="POST" action="<?php echo e(route('schools.store')); ?>" enctype="multipart/form-data">

                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <div class="form-floating form-floating-outline">
                                <input name="name" type="text" class="form-control" id="floatingInput1" placeholder="Enter Username" aria-describedby="floatingInputHelp1" required>
                                <label for="floatingInput1">Name</label>

                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="form-floating form-floating-outline">
                                <select name="school_type" id="school_type" class="form-select form-select-lg" aria-describedby="floatingInputHelp2">
                                    <option value="guardian">Dependent</option>
                                    <option value="independent">Independent</option>
                                </select>

                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <div class="form-floating form-floating-outline">
                                <input name="email" type="email" class="form-control" id="floatingInput3" placeholder="Enter Email" aria-describedby="floatingInputHelp3" required>
                                <label for="floatingInput3">Email</label>

                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="form-floating form-floating-outline">
                                <input name="phone" type="text" class="form-control" id="floatingInput4" placeholder="Enter Phone" aria-describedby="floatingInputHelp4" required>
                                <label for="floatingInput4">Phone</label>

                            </div>
                        </div>
                    </div>

                    <div class="row">

                        <div class="col-md-6 mb-4">
                            <div class="form-floating form-floating-outline">
                                <input
                                type="date"
                                class="form-control"
                                placeholder="YYYY-MM-DD"
                                name="founded_at"
                                />
                                <label >Founded At</label>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="form-floating form-floating-outline">
                                <input name="web_address" type="url" class="form-control" id="floatingInput6" placeholder="Enter School URL" aria-describedby="floatingInputHelp6" required>
                                <label for="floatingInput6">Url</label>

                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <div class="form-floating form-floating-outline">
                                <input name="address" id="floatingInput9" type="text" placeholder="Enter school Address" class="form-control" aria-describedby="floatingInputHelp9" required>
                                <label for="floatingInput9">Address</label>

                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="form-floating form-floating-outline">
                                <input name="description" id="floatingInput10" type="text" placeholder="Enter school Description" class="form-control" aria-describedby="floatingInputHelp10" required>
                                <label for="floatingInput10">Description</label>

                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <div class="form-floating form-floating-outline">
                                <input name="map_code" id="floatingInput7" type="text" placeholder="Enter school Map Html Code" class="form-control" aria-describedby="floatingInputHelp7" required>
                                <label for="floatingInput7">Map Html Code</label>

                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <label class="form-label text-black">
                                School Picture
                            </label>
                            <input
                            type="file"
                            name="logo"
                            class="dropify"
                            data-allowed-file-extensions='[
                                "png", "PNG", "jpg", "JPG", "jpeg", "JPEG"
                            ]'
                            >
                        </div>
                    </div>
                    <div class="mt-3 d-flex justify-content-between">
                        <a href="<?php echo e(route('schools.index')); ?>" class="btn btn-outline-secondary">
                            <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
                            <span class="align-middle d-sm-inline-block d-none">Back</span>
                        </a>
                        <button
                        class="btn btn-primary ms-2 d-none"
                        id="load-btn"
                        type="button"
                    >
                        <span class="spinner-border me-1" role="status" aria-hidden="true"></span>
                        Processing...
                        </button>
                        <button class="btn btn-primary ms-2" id="submit-btn" type="button">
                            Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/dropify/dropify.min.js')); ?>"></script>

    <script>
        $(function () {
            $('.dropify').dropify();
        });
    </script>

<script>
    $(function() {
         const submitBtn = $("#submit-btn");

        const keys = [
            'name',
            'school_type',
            'email',
            'phone',
            'web_address',
            'address',
            'description',
            'founded_at',
            'logo',
            'map_code'
        ];

        const rules = {
            name: "required|string|max:255",
            school_type: "required|string",
            email: "required|email|unique:schools,email",
            phone: "required|unique:schools,phone",
            web_address: "required|url",
            address: "required|string",
            description: "required",
            founded_at: "required",
            logo: "required",
            map_code: "required"
        };

        const messages = {
            'school_type.required': 'School Category is required!',
            'name.required': 'School Name is required!',
            'name.max': 'School Name should not be more than 255 letters!',
            'email.required': 'School Email is required!',
            'email.email': 'Invalid School Email Format!',
            'email.unique': 'School Email should not be duplicated!',
            'email.regex': 'Invalid School Email Format!',
            'phone.required': 'School Phone number is required!',
            'phone.unique': 'School Phone number should not be duplicated!',
            'phone.regex': 'Invalid School Phone number Format!',
            'web_address.required': 'School Website Link is required!',
            'address.required': 'School Address is required!',
            'description.required': 'School Description is required!',
            'founded_at.required': 'School Founded Date is required!',
            'logo.required': 'School Image is required!',
            'logo.mimes': 'School Image Type Should be *jpg, *png, *jpeg!',
            'map_code.required': 'School map code is required!',
        };


       
        submitBtn.click(function(e) {
            e.preventDefault();
            validateNew({
                keys   : keys,
                rules  : rules,
                fileValidate: true
            }).then(() => {
                if (!submitBtn.hasClass("d-none")) submitBtn.addClass('d-none');
                if ($('#load-btn').hasClass('d-none')) $('#load-btn').removeClass('d-none');
                $("form").submit();
            })
        })
    })
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dropify/dropify.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/schools/create.blade.php ENDPATH**/ ?>