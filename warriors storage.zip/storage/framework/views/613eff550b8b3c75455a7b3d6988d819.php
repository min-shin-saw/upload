<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.dashboard')); ?> / <a
                    href="<?php echo e(route('transaction-names.index')); ?>"><?php echo e(__('admin/breadcrumb/transaction-name.transaction_name')); ?></a> / </span><?php echo e(__('common-breadcrumb.edit')); ?>

        </h4>
        <div class="row">
            <div class="col-md-7">
                <div class="card">
                    <h5 class="card-header  h4 text-primary"><?php echo e(__('admin/admin-transactin-name.transaction_name_edit')); ?></h5>
                    <div class="card-body">
                        <form class="mt-3"  action="<?php echo e(route('transaction-names.update',$transactionName->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <?php echo $__env->make('admin.transaction-name.form-partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/transaction-name/edit.blade.php ENDPATH**/ ?>