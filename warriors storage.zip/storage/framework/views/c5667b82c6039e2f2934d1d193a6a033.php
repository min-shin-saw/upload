<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?> / <a
                    href="<?php echo e(route('lessons.index', $subject)); ?>"><?php echo e($subject->name); ?></a> / </span><?php echo e(__('admin/breadcrumb/lesson.lessons')); ?></h4>
        <div class="row">
            <div class="col-md-9">
                <div class="card">
                    <div class="d-flex align-items-center justify-content-between">
                        <h5 class="card-header mb-3 text-primary"><?php echo e($subject->name); ?> <?php echo e(__('admin/admin-lesson.lesson_create')); ?></h5>

                        <div>
                            <button style="border-bottom-right-radius: 0 !important;border-top-right-radius: 0 !important" class="btn mb-1 d-block btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                <span class="mdi mdi-plus"></span> <?php echo e(__('Section')); ?>

                            </button>
                        </div>
                    </div>

                    <div class="card-body">
                        <form action="<?php echo e(route('lessons.store', $subject)); ?>" enctype="multipart/form-data" method="post" id="lesson-form">
                            <?php echo csrf_field(); ?>
                            <?php echo $__env->make('admin.lessons.form-partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card relative">
                    <div x-data="alpine" class="card-body">
                        <h5 class="card-header mb-3 p-0">
                            Select Batches
                        </h5>

                        <div class="">
                            <input
                                name="batches_type"
                                class="form-check-input"
                                type="radio"
                                value="all"
                                checked="true"
                                id="all-batches-radio"
                                form="lesson-form"
                                @change="batchTypeChange"
                            />
                            <label class="ms-1" for="all-batches-radio">
                                <h6>All Batches</h6>
                            </label>
                        </div>
                        <?php if($subject->courses->first() &&$subject->courses->first()->batches->count() > 0): ?>
                            <div class="">
                                <input
                                    name="batches_type"
                                    class="form-check-input"
                                    type="radio"
                                    value="specific"
                                    id="specific-batches-radio"
                                    form="lesson-form"
                                    @change="batchTypeChange"
                                />
                                <label class="ms-1" for="specific-batches-radio">
                                    <h6>Select Batches</h6>
                                </label>
                            </div>

                            <div x-show="batchType === 'specific'">
                                <select id="select2Multiple" name="batches[]" class="select2 form-select subject-select" multiple form="lesson-form">
                                    <?php $__currentLoopData = $subject->courses->first()->batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($batch->id); ?>"><?php echo e($batch->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('teleport'); ?>
    <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel">Section</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form action="<?php echo e(route('section.store')); ?>" method="POST" id="section-form">
            <?php echo csrf_field(); ?>
                <input type="hidden" name="subject_id" value="<?php echo e($subject->id); ?>">
                <input type="hidden" name="from_model" value="true">

                <div class="form-floating form-floating-outline mb-4">
                    <input name="section_name" type="text" class="form-control" placeholder="Enter Section Name">
                    <label for=""><?php echo e(__('Name')); ?></label>
                </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary waves-effect" data-bs-dismiss="modal"><?php echo e(__('admin/admin-teacher-assign-course.close')); ?></button>

          <button type="button" id="submit-section-btn" class="btn btn-primary"><?php echo e(__('common.submit')); ?></button>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-script'); ?>
    <script
    defer
    src="<?php echo e(asset('assets/js/plugin/alpinejs.min.js')); ?>">
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/tinymce/tinymce.min.js')); ?>"></script>
    <script>
        $(function() {
            tinymce.init({
                selector: '#lesson-description',
            });

            var readURL = function(input, imgContainer, errorContainer) {

                if (input.files && input.files[0]) {

                    var reader = new FileReader();

                    reader.readAsDataURL(input.files[0]);

                    var filePath = input.value;
                    reader.onload = function(e) {
                        var file = input.files[0];
                        var fileSize = file.size;
                        $(imgContainer).attr('src', e.target.result);
                        $(errorContainer).text('');
                    }

                }
            }

            $("[name='content_type']").change(function(e) {
                e.preventDefault();
                setContent();
            });

            const setContent = () => {
                let contentType = $("[name='content_type']:checked").val();
                setDurationInput(contentType);
                setContentInput(contentType);
                setContentFile(contentType);
            }

            const setContentInput = (contentType) => {
                if (contentType == 'Youtube') {
                    $('.content-input-container').html(`
                        <div class="form-floating form-floating-outline lesson-duration">
                            <input
                            type="text"
                            id="youtube-content"
                            class="form-control" placeholder="Enter Youtube Url"
                            name="content"
                            />
                            <label for="youtube-content">Youtube Url</label>
                        </div>
                    `);
                } else if(contentType == 'Drive') {
                    $('.content-input-container').html(`
                        <div class="form-floating form-floating-outline lesson-duration">
                            <input
                            type="text"
                            id="drive-content"
                            class="form-control" placeholder="Enter Drive Url"
                            name="content"
                            />
                            <label for="drive-content">Drive Url</label>
                        </div>
                    `);
                } else {
                    $('.content-input-container').html(`
                        <input
                        name="content"
                        class="form-control"
                        type="file"
                        id="content">
                    `);
                    switch (contentType) {
                        case 'Pdf':
                            $('#content').attr('accept', '.pdf');
                            break;
                        case 'Zip':
                            $('#content').attr('accept', '.zip');
                            break;
                        case 'Audio':
                            $('#content').attr('accept', '.mp3');
                            break;
                        default:
                            $('#content').attr('accept', '.mp4');
                            break;
                    }
                }
            }

            const setContentFile = (contentType) => {
                // content-file-container
                switch (contentType) {
                    case 'Youtube':
                        $('.content-file-container').html(`
                            <img
                            src="<?php echo e(asset('assets/img/placeholders/youtube-placeholder.jpg')); ?>"
                            alt="subject image"
                            class="card-img card-img-right"
                            >
                        `)
                        $('#youtube-content').keyup(function(e) {
                            e.preventDefault();
                            readYoutubeUrl($(this).val());
                        });
                        break;
                    case 'Drive':
                        $('.content-file-container').html(`
                            <img
                            src="<?php echo e(asset('assets/img/placeholders/google-drive.png')); ?>"
                            alt="subject image"
                            class="card-img card-img-right"
                            >
                        `)
                        $('#drive-content').keyup(function(e) {
                            e.preventDefault();
                            readGoogleDriveUrl($(this).val());
                        });
                        break;
                    case 'Pdf':
                        $('.content-file-container').html(`
                            <img
                            src="<?php echo e(asset('assets/img/placeholders/pdf-logo-placeholder.png')); ?>"
                            alt="subject image"
                            class="card-img card-img-right"
                            >
                        `)
                        break;
                    case 'Zip':
                        $('.content-file-container').html(`
                            <img
                            src="<?php echo e(asset('assets/img/placeholders/zip-logo-placeholder.png')); ?>"
                            alt="subject image"
                            class="card-img card-img-right"
                            >
                        `)
                        break;
                    case 'Audio':
                        $('.content-file-container').html(`
                            <img
                            src="<?php echo e(asset('assets/img/placeholders/audio-placeholder.png')); ?>"
                            alt="subject image"
                            class="card-img card-img-right"
                            >
                        `)
                        break;
                    default:
                        $('.content-file-container').html(`
                            <img
                            src="<?php echo e(asset('assets/img/placeholders/video-placeholder.png')); ?>"
                            alt="subject image"
                            class="card-img card-img-right"
                            >`)
                        break;
                }
            }

            const setDurationInput = (contentType) => {
                let unNecessary = ['Zip', 'Pdf']
                if (unNecessary.includes(contentType)) {
                    if (!$('.lesson-duration').hasClass('hide')) {
                        $("[name='duration']").val(0);
                        $('.lesson-duration').addClass('hide');
                    }
                } else {
                    if ($('.lesson-duration').hasClass('hide')) {
                        $("[name='duration']").val(null);
                        $('.lesson-duration').removeClass('hide');
                    }
                }
            }

            const readYoutubeUrl = (url) => {
                let videoID = extractYouTubeVideo(url);
                if (videoID) {
                    $('#content-error').text('');
                    $('.content-file-container').html(`
                        <iframe class="card-img card-img-right" width="400" height="225" src="https://www.youtube.com/embed/${videoID}" frameborder="0" allowfullscreen></iframe>
                    `);
                } else {
                    $('#content-error').text('Invalid YouTube URL');
                }
            }

            const extractYouTubeVideo = (url) => {
                let regExp = /^.*(?:youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=)([^#\&\?]*).*/;
                let match = url.match(regExp);
                return (match && match[1]) || null;
            }

            const readGoogleDriveUrl = (url) => {
                let videoID = extractGoogleDriveVideo(url);
                if (videoID) {
                    $('#content-error').text('');
                    $('.content-file-container').html(`
                        <iframe src="https://drive.google.com/file/d/${videoID}/preview" width="400" height="255" allow="autoplay"></iframe>
                    `);
                } else {
                    $('#content-error').text('Invalid Google Drive URL');
                }
            }

            const extractGoogleDriveVideo = (url) => {
                let regExp = /https:\/\/drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]{25,})/;
                let match = url.match(regExp);
                return (match && match[1]) || null;
            }
        });
    </script>

    <script>
        $(function() {
            const submitBtn = $('#submit-btn');
            const keys = [
                'name',
                'description',
                'content',
                'duration',
                'section_id',
            ];

            const rules = {
                name        : 'required|max:255',
                duration    : 'required',
                content     : 'required',
                description : 'nullable',
                section_id  : 'required',
            };

            const messages = {
                "name.required": "<?php echo e(__('validation.required',['attribute' => __('validation.attributes.lesson_name')])); ?>",
                "duration.required": "<?php echo e(__('validation.required',['attribute' => __('validation.attributes.lesson_duration')])); ?>",
                "content.required": "<?php echo e(__('validation.required',['attribute' => __('validation.attributes.content')])); ?>",
                "description.required": "<?php echo e(__('validation.required',['attribute' => __('validation.attributes.description')])); ?>",
                'section_id.required': "<?php echo e(__('The section field is required')); ?>",
            };

            submitBtn.click(function(e) {
                e.preventDefault();
                if($('[name="batches_type"]:checked').val() === 'specific') {
                    keys.push('batches');
                    rules.batches = 'required';
                }
                validateNew({
                    keys   : keys,
                    rules  : rules,
                    select2: true,
                    messages: messages,
                    fileValidate: false
                }).then(() => {
                    if (!submitBtn.hasClass('d-none')) submitBtn.addClass('d-none');
                    if ($('#load-btn').hasClass('d-none')) $('#load-btn').removeClass('d-none');
                    $('form#lesson-form').submit();
                });
            });
        });
    </script>

    <script>
        $(function() {
            $('#submit-section-btn').click(function (e) {
                e.preventDefault();

                keys  = ['section_name'];
                rules = {section_name: 'required|max:255'};

                validateNew({
                    keys: keys,
                    rules: rules,
                    fileValidate: false
                }).then(() => {
                    $('form#section-form').submit();
                });
            });
        });
    </script>

    <script defer>
        const alpine = {
            batchType: 'all',
            batchTypeChange(e) {
                this.batchType = e.target.value;
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .hide {
            display: none !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/lessons/create.blade.php ENDPATH**/ ?>