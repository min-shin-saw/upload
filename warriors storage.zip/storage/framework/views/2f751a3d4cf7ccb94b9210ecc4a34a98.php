<div id="account-details" class="content">
    <div class="row g-4">
        <div class="col-md-6">
            <div class="form-floating form-floating-outline">
                <input
                type="text"
                id="name"
                class="form-control"
                placeholder="Enter Name"
                name="name"
                value="<?php echo e(isset($employee)?$employee->name:''); ?>"
                />
                <label for="username"><?php echo e(__('admin/admin-employee.user_name')); ?></label>

                <small class="name-error text-danger mt-3"></small>
            </div>

            <div class="form-floating form-floating-outline mt-3">
                <input
                type="email"
                id="email"
                class="form-control"
                placeholder="Enter Email"
                name="email"
                value="<?php echo e(isset($employee)?$employee->email:''); ?>"
                />
                <label for="email"><?php echo e(__('common.email')); ?></label>
                <small class="email-error text-danger mt-3"></small>
            </div>

            <div class="form-floating form-floating-outline mt-3">
                <input
                type="text"
                id="phone"
                class="form-control"
                placeholder="Enter Phone"
                name="phone"
                value="<?php echo e(isset($employee)?$employee->phone:''); ?>"
                />
                <label for="phone"><?php echo e(__('common.phone')); ?></label>
                <small class="phone-error text-danger mt-3"></small>
            </div>
        </div>

        <!-- Custom Icon Radios -->
        <div class="col-md-6">
            <div class="card shadow-sm py-0" id="gender">
                <h5 class="card-header py-3"><?php echo e(__('common.gender')); ?></h5>
                <div class="card-body py-2">
                    <div class="row">
                        <div class="col-md mb-md-0 mb-2">
                            <div class="form-check custom-option custom-option-icon">
                                <label class="form-check-label custom-option-content"
                                    for="teach-male">
                                    <span class="custom-option-body">
                                        <span class="mdi mdi-face-man"></span>
                                        <span class="custom-option-title"><?php echo e(__('common.male')); ?></span>
                                    </span>
                                    <input name="gender" class="form-check-input" type="radio"
                                        value="male" id="teach-male"

                                        <?php if(isset($employee)): ?>
                                            <?php echo e($employee->gender == 'male'?'checked':''); ?>

                                        <?php else: ?>
                                            <?php echo e('checked'); ?>

                                        <?php endif; ?>

                                        />
                                </label>
                            </div>
                        </div>
                        <div class="col-md mb-md-0 mb-2">
                            <div class="form-check custom-option custom-option-icon">
                                <label class="form-check-label custom-option-content"
                                    for="teach-female">
                                    <span class="custom-option-body">
                                        <span class="mdi mdi-face-woman"></span>
                                        <span class="custom-option-title"><?php echo e(__('common.female')); ?></span>
                                    </span>
                                    <input name="gender" class="form-check-input" type="radio"
                                        value="female" id="teach-female"

                                        <?php if(isset($employee)): ?>
                                            <?php echo e($employee->gender == 'female'?'checked':''); ?>

                                        <?php endif; ?>

                                        />
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Custom Icon Radios -->

        <div class="col-md-6">

            <!-- Nrc Start -->

            <div class="form-floating form-floating-outline input-group">
                <select class="form-control select2 nrc-code" id="nrc-code-select">
                    <?php if(!isset($employee)): ?>
                        <option value="0">--</option>
                    <?php endif; ?>
                    <?php $__currentLoopData = $nrc_codes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nrc_code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <option
                       value="<?php echo e($nrc_code); ?>"
                       <?php if(isset($employee)): ?>
                           <?php echo e($employee->nrcInfo?->nrc_code ==  $nrc_code? 'selected' : ''); ?>

                       <?php endif; ?>
                       ><?php echo e($nrc_code); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <?php if(isset($employee)): ?>
                    <?php
                        $nrcs = App\Models\School\Nrc::where('nrc_code', $employee->nrcInfo?->nrc_code)->get();
                    ?>
                    <select class="form-control select2 nrc-name" name="nrc_id" id="nrc-id">
                        <?php $__currentLoopData = $nrcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nrc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($nrc->id); ?>" <?php if($nrc->id == $employee->nrc_id): echo 'selected'; endif; ?>><?php echo e($nrc->name_en); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                <?php else: ?>
                    <select class="form-control select2 nrc-name" name="nrc_id" id="nrc-id"></select>
                <?php endif; ?>

                <select
                class="form-control select2"
                name="nrc_type"
                id="nrc_type"
                >
                    <?php $__currentLoopData = App\Models\School\Nrc::TYPES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option
                        value="<?php echo e($key); ?>"
                        <?php if(isset($employee)): ?>
                            <?php echo e($key == $employee->nrc_type?'selected':''); ?>

                        <?php endif; ?>
                        ><?php echo e($value); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <input
                type="text"
                class="form-control"
                placeholder="Enter Code"
                name="nrc"
                id="nrc"
                value="<?php echo e(isset($employee)?$employee->nrc:''); ?>"
                />


            </div>
            <small class="nrc_id-error text-danger mt-3 me-3"></small>
            <small class="nrc-error text-danger mt-2"></small>

            <!-- Nrc End -->

            <!-- Nationality Start -->

            <div class="form-floating form-floating-outline">
                <input
                type="text"
                id="nationality"
                class="form-control"
                placeholder="Enter Nationality"
                name="nationality"
                value="<?php echo e(isset($employee)?$employee->nationality:''); ?>"
                />
                <label for="nationality"><?php echo e(__('admin/admin-employee.nationality')); ?></label>

                <small class="nationality-error text-danger mt-3"></small>
            </div>

            <!-- Nationality End -->

            <!-- DOB Start -->

            <div class="form-floating form-floating-outline mt-3">
                <input
                type="date"
                class="form-control "
                placeholder="YYYY-MM-DD"
                id="date_of_birth"
                name="date_of_birth"
                value="<?php echo e(isset($employee)?$employee->date_of_birth:''); ?>"
                />
                <label for="date_of_birth"><?php echo e(__('admin/admin-employee.date_of_birth')); ?></label>

                <small class="date_of_birth-error text-danger mt-3"></small>
            </div>

            <!-- DoB End -->

            <!-- Password Start -->

            <div class="mt-3 form-password-toggle fv-plugins-icon-container">
                <div class="input-group input-group-merge">
                    <div class="form-floating form-floating-outline position-relative">
                        <i
                        class="mdi mdi-eye-off-outline position-absolute"
                        style="
                        cursor: pointer;
                        right:4%;
                        top: 15px;
                        "
                        ></i>
                        <input
                        name="password"
                        class="form-control"
                        type="password"
                        id="password"
                        placeholder="············"
                        required
                        >
                        <label for="currentPassword"><?php echo e(__('common.password')); ?></label>

                        <small class="password-error text-danger mt-3"></small>
                    </div>
                </div>
            </div>

            <div class="mt-3 form-password-toggle fv-plugins-icon-container">
                <div class="input-group input-group-merge">
                    <div class="form-floating form-floating-outline position-relative">
                        <i
                        class="mdi mdi-eye-off-outline position-absolute"
                        style="
                        cursor: pointer;
                        right:4%;
                        top: 15px;
                        "
                        ></i>
                        <input
                        name="confirm_password"
                        class="form-control"
                        type="password"
                        id="confirm_password"
                        placeholder="············"
                        required
                        >
                        <label for="currentPassword"><?php echo e(__('common.confirm_password')); ?></label>
                        <small class="confirm_password-error text-danger mt-3"></small>
                    </div>
                </div>
            </div>

            <!-- Password End -->

        </div>

        <div class="col-md-6">

            <!-- Address Start -->

            <div class="form-floating form-floating-outline mb-4">
                <textarea
                name="address"
                class="form-control h-px-120"
                id="address"
                placeholder="Enter Address"><?php echo e(isset($employee)?$employee->address:''); ?></textarea>
                <label for="exampleFormControlTextarea1"><?php echo e(__('admin/admin-employee.address')); ?></label>
                <small class="address-error text-danger mt-3"></small>

            </div>

            <!-- Address End -->

            <!-- Profile Image Start -->

            <div class="">
                <label class="form-label text-black">
                    Profile Image
                </label>
                <input
                type="file"
                name="image"
                class="dropify"
                data-default-file="<?php echo e(isset($employee)?get_file($employee->image):''); ?>"
                data-allowed-file-extensions='[
                    "png", "PNG", "jpg", "JPG", "jpeg", "JPEG"
                ]'
                >
            </div>

            <!-- Profile Image End -->

        </div>

        <div class="col-12 d-flex justify-content-between">
            <a href="<?php echo e(route('employees.index')); ?>" class="btn btn-outline-secondary">
                <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
                <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('common.back')); ?></span>
            </a>

            <button type="button" class="btn-next invisible" id="to-pg2-btn"><?php echo e(__('common.next')); ?></button>

            <button type="button" class="btn btn-primary call-first-step-validation">
                <span class="align-middle d-sm-inline-block d-none me-sm-1"><?php echo e(__('common.next')); ?></span>
                <i class="mdi mdi-arrow-right"></i>
            </button>
        </div>
    </div>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/employees/form-partials/first-step-employee-info.blade.php ENDPATH**/ ?>