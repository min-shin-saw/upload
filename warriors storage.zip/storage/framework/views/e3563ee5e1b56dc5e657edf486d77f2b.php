<meta charset="utf-8" />
<meta name="viewport"
    content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />
<!-- CSRF Token -->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<title><?php echo e(config('app.name', 'Eduplus Admin')); ?></title>
<!-- Favicon -->
<link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/img/favicon/favicon.ico')); ?>" />
<!-- Helpers -->
<script src="<?php echo e(asset('assets/vendor/js/helpers.js')); ?>"></script>
<!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
<script src="<?php echo e(asset('assets/js/config.js')); ?>"></script>
<?php echo $__env->yieldContent('meta-script'); ?>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/layout/shared/meta-script.blade.php ENDPATH**/ ?>