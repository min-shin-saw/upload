<div class="text-start">
    <a
        href="<?php echo e(route('ferries.show',$id)); ?>"
        class="btn btn-sm btn-icon btn-success waves-effect waves-light" title="Show">
        <span class="mdi mdi-information-outline" data-bs-toggle="tooltip" data-bs-placement="top" title="Show"></span>
    </a>

    <a
        href="<?php echo e(route('ferries.edit',$id)); ?>"
        class="btn btn-sm btn-icon btn-primary waves-effect waves-light" title="Edit">
        <span class="mdi mdi-playlist-edit" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit"></span>
    </a>

   

    <button
        type="button"
        class="btn btn-sm btn-icon btn-danger waves-effect waves-light delete-btn"
        data-url="<?php echo e(route('ferries.destroy',$id)); ?>"
    >
            <span class="mdi mdi-delete-circle" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"></span>
    </button>
    <script src="<?php echo e(asset('assets/js/delete-sweet-alert.js')); ?>"></script>

</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/ferries/action.blade.php ENDPATH**/ ?>