<style>
    .notification-wrapper {
        position: relative;
        display: inline-block;
    }
    
    .notification-dot {
        position: absolute;
        top: -2px;
        right: -3px;
        width: 8px;
        height: 8px;
        background-color: red;
        border-radius: 50%;
        box-shadow: 0 0 2px rgba(0, 0, 0, 0.5);
        z-index: 1;
        display: none; /* Hide by default */
    }
    
    .notification-wrapper.has-notification .notification-dot {
        display: block;
    }
    
    </style>
<div>
    <button  
    data-bs-toggle="tooltip" data-bs-placement="top" title="Due Date Edit"
    class="btn btn-sm btn-icon due-date-edit-btn btn-info waves-effect waves-light <?php echo e($status == 'verified' ? 'disabled' : ''); ?> "  data-id="<?php echo e($id); ?>">
    <span class="mdi mdi-alarm"></span>
</button>
    <a 
    data-bs-toggle="tooltip" data-bs-placement="top" title="Invoice"
    href="<?php echo e(route('student-transaction.show',$id)); ?>" 
    class="btn btn-sm btn-icon btn-secondary waves-effect waves-light">
        <span class="mdi mdi-receipt-text"></span>
    </a>
    <div class="notification-wrapper <?php echo e($status == 'pending' ? 'has-notification' : ''); ?>">
        <button 
            data-bs-toggle="tooltip" data-bs-placement="top" title="Payment Approval"
            class="btn btn-sm btn-icon btn-warning student-payment-edit-btn <?php echo e($status == 'verified' ? 'disabled' : ''); ?>" image="<?php echo e($content ?  get_file($content) : ''); ?>" data-id="<?php echo e($id); ?>">
            <span class="mdi mdi-currency-usd"></span>
            <span class="notification-dot"></span>
        </button>
    </div>
    <a 
    data-bs-toggle="tooltip" data-bs-placement="top" title="Transaction Reports"
    href="<?php echo e(route('transaction-reports.notify',$id)); ?>" 
    class="btn btn-sm btn-icon btn-danger <?php echo e($status == 'verified' ? 'disabled' : ''); ?> waves-effect waves-light waves-effect waves-light">
        <span class="mdi mdi-bell-alert-outline"></span>
    </a>
    <script src="<?php echo e(asset('assets/js/transaction-reports/transaction-report-popup.js')); ?>"></script>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/transaction-reports/action.blade.php ENDPATH**/ ?>