<div id="personal-info" class="content">
    <div class="row g-4">
        <h3><?php echo e(__('admin/admin-student.father_information')); ?></h3>
        <div class="col-md-6">
            <div class="form-floating form-floating-outline">
                <input type="text" id="father-name" class="form-control" placeholder="Enter Father Name"
                    name="father_name" value="<?php echo e(isset($student) ? $student->father_name : ''); ?>" />
                <label for="father-name"><?php echo e(__('admin/admin-student.father_name')); ?></label>
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-floating form-floating-outline input-group">
                <select class="form-control select2 nrc-code" id="father-nrc-code-create">
                    <option value="0">--</option>
                    <?php $__currentLoopData = $nrc_codes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nrc_code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($nrc_code); ?>"
                            <?php if(isset($student)): ?> <?php echo e($student->fatherNrcInfo?->nrc_code == $nrc_code ? 'selected' : ''); ?> <?php endif; ?>>
                            <?php echo e($nrc_code); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if(isset($student)): ?>
                    <?php
                        $nrcs = App\Models\School\Nrc::where('nrc_code', $student->fatherNrcInfo?->nrc_code)->get();
                    ?>
                    <select class="form-control select2 nrc-name" name="father_nrc_id" >
                        <?php $__currentLoopData = $nrcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nrc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($nrc->id); ?>" <?php if($nrc->id == $student->father_nrc_id): echo 'selected'; endif; ?>><?php echo e($nrc->name_en); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                <?php else: ?>
                    <select class="form-control select2 nrc-name" name="father_nrc_id" id="father-nrc-id-create"></select>
                <?php endif; ?>
                <select class="form-control select2" name="father_nrc_type" id="father-nrc-type-create">
                    <?php $__currentLoopData = App\Models\School\Nrc::TYPES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>"
                            <?php if(isset($student)): ?> <?php echo e($key == $student->father_nrc_type ? 'selected' : ''); ?> <?php endif; ?>>
                            <?php echo e($value); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <input type="text" class="form-control" placeholder="Enter Code" id="father-nrc-create" name="father_nrc" value="<?php echo e(isset($student)?$student->father_nrc:''); ?>" />
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-floating form-floating-outline">
                <input type="email" id="father-email" class="form-control" placeholder="Enter Father Email"
                    name="father_email" value="<?php echo e(isset($student) ? $student->father_email : ''); ?>" />
                <label for="father-email"><?php echo e(__('admin/admin-student.father_email')); ?></label>
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-floating form-floating-outline">
                <input type="text" id="father-phone" class="form-control" placeholder="Enter Father Phone"
                    name="father_phone" value="<?php echo e(isset($student) ? $student->father_phone : ''); ?>" />
                <label for="father-phone"><?php echo e(__('admin/admin-student.father_phone')); ?></label><label>
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-floating form-floating-outline">
                <input type="text" id="father-job" class="form-control" placeholder="Enter Father Job"
                    name="father_job" value="<?php echo e(isset($student) ? $student->father_job : ''); ?>" />
                <label for="father-job"><?php echo e(__('admin/admin-student.father_job')); ?></label>
            </div>
        </div>

        <div class="col-4">
            <input type="checkbox" class="form-check-input" id="carry-father-as-guardian">
            <label class="form-check-label"><?php echo e(__('admin/admin-student.guardian')); ?></label>
        </div>

        <hr>

        <h3><?php echo e(__('admin/admin-student.mother_information')); ?></h3>

        <div class="col-md-6">
            <div class="form-floating form-floating-outline">
                <input type="text" id="mother-name" class="form-control" placeholder="Enter Mother Name"
                    name="mother_name" value="<?php echo e(isset($student) ? $student->mother_name : ''); ?>" />
                <label for="mother-name"><?php echo e(__('admin/admin-student.mother_name')); ?></label>
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-floating form-floating-outline input-group">
                <select class="form-control select2 nrc-code" id="mother-nrc-code-create">
                    <?php if(!isset($student)): ?>
                        <option value="0">--</option>
                    <?php endif; ?>
                    <?php $__currentLoopData = $nrc_codes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nrc_code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($nrc_code); ?>"
                            <?php if(isset($student)): ?> <?php echo e($student->motherNrcInfo?->nrc_code == $nrc_code ? 'selected' : ''); ?> <?php endif; ?>>
                            <?php echo e($nrc_code); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if(isset($student)): ?>
                    <?php
                        $nrcs = App\Models\School\Nrc::where('nrc_code', $student->motherNrcInfo?->nrc_code)->get();
                    ?>
                    <select class="form-control select2 nrc-name" name="mother_nrc_id" id="mother-nrc-id-create">
                        <?php $__currentLoopData = $nrcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nrc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($nrc->id); ?>" <?php if($nrc->id == $student->mother_nrc_id): echo 'selected'; endif; ?>><?php echo e($nrc->name_en); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                <?php else: ?>
                    <select class="form-control select2 nrc-name" name="mother_nrc_id" id="mother-nrc-id-create" ></select>
                <?php endif; ?>
                <select class="form-control select2" name="mother_nrc_type" id="mother-nrc-type-create">
                    <?php $__currentLoopData = App\Models\School\Nrc::TYPES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>"
                            <?php if(isset($student)): ?> <?php echo e($key == $student->mother_nrc_type ? 'selected' : ''); ?> <?php endif; ?>>
                            <?php echo e($value); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <input type="text" class="form-control" placeholder="Enter Code" name="mother_nrc" id="mother-nrc-create" value="<?php echo e(isset($student)?$student->mother_nrc:''); ?>" />
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-floating form-floating-outline">
                <input type="email" id="mother-email" class="form-control" placeholder="Enter Mother Email"
                    name="mother_email" value="<?php echo e(isset($student) ? $student->mother_email : ''); ?>" />
                <label for="mother-email"><?php echo e(__('admin/admin-student.mother_email')); ?></label>
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-floating form-floating-outline">
                <input type="text" id="mother-phone" class="form-control" placeholder="Enter Mother Phone"
                    name="mother_phone" value="<?php echo e(isset($student) ? $student->mother_phone : ''); ?>" />
                <label for="mother-phone"><?php echo e(__('admin/admin-student.mother_phone')); ?></label>
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-floating form-floating-outline">
                <input type="text" id="mother-job" class="form-control" placeholder="Enter Mother Job"
                    name="mother_job" value="<?php echo e(isset($student) ? $student->mother_job : ''); ?>" />
                <label for="mother-job"><?php echo e(__('admin/admin-student.mother_job')); ?></label>
            </div>
        </div>

        <div class="col-4">
            <input type="checkbox" class="form-check-input" id="carry-mother-as-guardian">
            <label class="form-check-label" ><?php echo e(__('admin/admin-student.guardian')); ?></label>
        </div>  

        <div class="col-12 d-flex justify-content-between">
            <button type="button" class="btn btn-outline-secondary btn-prev">
                <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
                <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('common.previous')); ?></span>
            </button>
            <button type="button" class="btn-next invisible" id="to-pg3-btn"><?php echo e(__('common.next')); ?></button>
            <?php if(isset($student)): ?>
                    <div>
                        <button type="button" id="pg2-submit" class="btn btn-primary me-2">
                            <span class="align-middle d-sm-inline-block d-none me-sm-1"><?php echo e(__('common.submit')); ?></span>
                        </button>                                                                           
                        <button type="button" class="btn btn-primary">
                            <span class="align-middle d-sm-inline-block d-none me-sm-1 call-second-step-validation">Next to Guardian</span>
                            <i class="mdi mdi-arrow-right"></i>
                        </button>
                    </div>
            <?php else: ?>
                <?php if(auth()->user()->school?->school_type == 'guardian'): ?>
                <button type="button" class="btn btn-primary">
                    <span class="align-middle d-sm-inline-block d-none me-sm-1 call-second-step-validation"><?php echo e(__('common.next')); ?></span>
                    <i class="mdi mdi-arrow-right"></i>
                </button>
                <?php else: ?>
                    <div class="">
                        <button type="button" id="pg2-submit" class="btn btn-primary me-2">
                            <span class="align-middle d-sm-inline-block d-none me-sm-1"><?php echo e(__('common.submit')); ?></span>
                        </button>

                        <button type="button" class="btn btn-primary">
                            <span class="align-middle d-sm-inline-block d-none me-sm-1 call-second-step-validation">Next to
                                Guardian</span>
                            <i class="mdi mdi-arrow-right"></i>
                        </button>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/students/form-partials/second-step-parent-info.blade.php ENDPATH**/ ?>