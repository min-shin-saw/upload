<?php
    use App\Helpers\CustomHelpers;
?>
<div class="d-flex">
    <?php if(CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Report Card")): ?>
        <div class="dropdown me-2">
            <button onclick="toggleMenu(event)" class="btn btn-sm btn-icon btn-success waves-effect waves-light report-card-btn" title="<?php echo e(__('Report Card')); ?>" data-bs-toggle="dropdown"  type="button" >
                <span class="mdi mdi-card-account-details-outline" data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo e(__('Report Card')); ?>"></span>
            </button>
            <ul class="dropdown-menu">
                <?php $__currentLoopData = [
                    ['text' => 'Quarterly ( အလယ်တန်းအဆင့် )', 'value' => 'quarterly-middle'],
                    ['text' => 'Quarterly ( အထက်တန်းအဆင့် )', 'value' => 'quarterly-high'],
                    ['text' => 'Consolidated ( မှတ်တမ်းချုပ် )', 'value' => 'consolidated']
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('report-card.index', [
                            'batch' => $batch_id,
                            'course' => $course_id,
                            'student' => $student_id,
                            'type' => $option['value'],
                            'origin' => 'enrollments',

                        ])); ?>">
                            <?php echo e($option['text']); ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <a href="<?php echo e(route('enrollments.show',$id)); ?>" class="btn me-2 btn-sm btn-icon btn-primary waves-effect waves-light ">
        <span class="mdi mdi-information-outline" data-bs-toggle="tooltip" data-bs-placement="top" title="Show"></span>
    </a>
    
    <button
        type="button"
        class="btn btn-sm btn-icon btn-danger  waves-effect waves-light delete-btn"
        data-url="<?php echo e(route('enrollments.destroy',$id)); ?>"
    >
            <span class="mdi mdi-delete-circle" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"></span>
    </button>
    <script src="<?php echo e(asset('assets/js/delete-sweet-alert.js')); ?>"></script>
    <script>
        function toggleMenu(e) {
            let target = e.target.parentElement.parentElement
            let el = target.querySelector('.dropdown-menu')
            el.classList.toggle("show")
        }
    </script>
</div>




<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/enrollments/action.blade.php ENDPATH**/ ?>