<?php
   function getFormatTime($time) {
       return date('h:i A', strtotime($time));
   }

   function getFormatDate($date) {
       return date('d-M-Y', strtotime($date));
   }

   function getSubTeachers($overallTimetableFormat) {

        $teacherAssigns = \App\Models\Teacher\TeacherAssignedSubject::with('teacher')->where([
            'subject_id' => $overallTimetableFormat->subject_id,
            'batch_id'   => $overallTimetableFormat->timetableFormat->batch_id,
        ])->whereNot('teacher_id', $overallTimetableFormat->teacher_id)->get();

        return $teacherAssigns->pluck('teacher');
   }
?>

<div class="text-black">
    <div class="d-flex gap-2">
        <h4><?php echo e($overallTimetableFormat->subject->name); ?></h4>
        <div
          style="
            background: <?php echo e($overallTimetableFormat->subject->color); ?>;
            border-radius: 50%;
            width: 18px;
            height: 18px;
          "
          class=""
        ></div>
    </div>

    <p>
        <b>Week Day</b>&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;: <?php echo e($overallTimetableFormat->day); ?>

    </p>

    <p>
        <b>Start Time</b>&#160;&#160;&#160;&#160;&#160;&#160;&#160;: <?php echo e(getFormatTime($overallTimetableFormat->start_time)); ?>

    </p>

    <p>
        <b>End Time</b>&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;: <?php echo e(getFormatTime($overallTimetableFormat->end_time)); ?>

    </p>

    <p>
        <b>Duration</b>&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;: <?php echo e(getFormatDate($overallTimetableFormat->timetableFormat->start_date)); ?> to <?php echo e(getFormatDate($overallTimetableFormat->timetableFormat->end_date)); ?>

    </p>

    <p>
        <b>Main Teacher</b>&#160;:
        <a href="<?php echo e(route('teachers.show', $overallTimetableFormat->teacher)); ?>">
            <?php echo e($overallTimetableFormat->teacher->name); ?>

        </a>
    </p>

    <?php if(count(getSubTeachers($overallTimetableFormat))): ?>
        <div class="d-flex">
            <b>Sub Teachers</b>&#160;:

            <ul>
                <?php $__currentLoopData = getSubTeachers($overallTimetableFormat); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(route('teachers.show', $teacher)); ?>"><?php echo e($teacher->name); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div>
        <b>Actions</b>&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;:
        <a
        href="<?php echo e(route('overall-timetables.lists',$overallTimetableFormat)); ?>"
        class="btn btn-sm btn-success"
        title="Edit Timetable"
        >
            <span class="mdi mdi-playlist-edit"></span>
        </a>

        <button
        class="btn btn-sm btn-danger"
        data-url="<?php echo e(route('overall-timetables.destroy',$overallTimetableFormat)); ?>"
        id="overall-delete-btn"
        title="Delete"
        >
            <i class="mdi mdi-delete"></i>
        </button>
    </div>
</div>

<script>
    $(function () {
        $('#overall-delete-btn').click(function (e) {
            e.preventDefault();

            const url = $(this).data('url');

            Swal.fire({
                title: "Are you sure?",
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: "Yes, delete it!",
                customClass: {
                    confirmButton: 'btn btn-success me-3 waves-effect waves-light',
                    cancelButton: 'btn btn-label-secondary waves-effect'
                },
                buttonsStyling: false
            }).then(function (result) {
                if (result.value) {
                    $.ajax({
                        type: "GET",
                        url: url,
                        dataType: "JSON",
                        success: function (response) {
                            // window.location.reload();
                            window.location.replace(response.redirect);
                        }
                    });
                }
            });
        });
    });
</script>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/timetables/overall-timetable-format.blade.php ENDPATH**/ ?>