  <!-- Activate User Account Modal -->
  <div class="modal fade" id="activate-account-modal" tabindex="-1"  aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
        <div class="modal-header">
            <h5>Activate User Account</h5>
        </div>

        <div class="modal-body">
            <div class="d-flex gap-2">
                <input type="text" class="form-control" value="https://localhost:8000/activate" id="activate-account-link-input">
                <button class="btn btn-primary btn-sm" id="activate-account-link-copy-btn">Copy</button>
            </div>
        </div>

        <div class="modal-footer">
            <div class="d-flex justify-content-end">
                <button class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
        </div>
    </div>
</div><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/components/activateUserAccount.blade.php ENDPATH**/ ?>