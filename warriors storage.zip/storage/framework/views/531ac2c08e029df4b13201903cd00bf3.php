<div class="row">
    <div class="col-md-6 mb-4">
        <div class="form-floating form-floating-outline">
            <input type="text" id="name" class="form-control" placeholder="Enter Subject Name"
                name="name"
                value="<?php echo e(isset($subject)?$subject->name:''); ?>"
                />
            <label for="name"><?php echo e(__('admin/admin-subject.subject_name')); ?></label>
        </div>
    </div>
    <div class="col-md-6 mb-4">
        <div class="form-floating form-floating-outline">
            <input type="text" id="price" class="form-control" placeholder="Enter Subject Price"
                name="price"
                value="<?php echo e(isset($subject)?$subject->price:''); ?>"
                />
            <label for="price"><?php echo e(__('admin/admin-subject.subject_price')); ?></label>
        </div>
    </div>
    <div class="">
        <div class="form-floating form-floating-outline mb-4">
            <textarea
            name="description"
            class="form-control h-px-120"
            id="description"
            placeholder="Enter Description"><?php echo e(isset($subject)?$subject->description:''); ?></textarea>
            <label for="exampleFormControlTextarea1"><?php echo e(__('admin/admin-subject.description')); ?></label>
        </div>
    </div>

    <div class="col-md-6">
        <label class="form-label text-black">
            <?php echo e(__('admin/admin-subject.subject_image')); ?>

        </label>
        <input
        type="file"
        name="image"
        class="dropify"
        data-default-file="<?php echo e(isset($subject)?get_file($subject->image):''); ?>"
        data-allowed-file-extensions='[
            "png", "PNG", "jpg", "JPG", "jpeg", "JPEG", "jfif"
        ]'
        >
    </div>

    <div class="col-md-6">
        <div class="form-floating form-floating-outline my-4">
            <input
              type="text"
              id="name"
              class="form-control"
              placeholder="Enter Subject Short Name(Optional)"
              name="short_name"
              value="<?php echo e(isset($subject)?$subject->short_name:''); ?>"
            />
            <label for="name">
                <?php echo e(__('admin/admin-subject.subject_short_name')); ?>

            </label>
        </div>

        <div class="form-floating form-floating-outline mb-4">
            <input
              class="form-control"
              type="color"
              id="html5-color-input"
              name="color"
              value="<?php echo e(isset($subject)?$subject->color:'#3569c0'); ?>"
            />
            <label for="html5-color-input">
                Color for Timetable
            </label>
        </div>
    </div>

</div>
<div class="mt-3 d-flex justify-content-between">
    <a href="<?php echo e(route('subjects.index')); ?>" class="btn btn-outline-secondary">
        <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
        <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('common.back')); ?></span>
    </a>
    <button
    class="btn btn-primary ms-2 d-none"
    id="load-btn"
    type="button"
    >
        <span class="spinner-border me-1" role="status" aria-hidden="true"></span>
        Processing...
    </button>
    <button class="btn btn-primary ms-2" id="submit-btn" type="button">
        <?php echo e(__('common.submit')); ?>

    </button>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/subjects/form-partials/form.blade.php ENDPATH**/ ?>