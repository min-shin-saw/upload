<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.dashboard')); ?> / <a
                    href="<?php echo e(route('subjects.index')); ?>"><?php echo e(__('admin/breadcrumb/subject.subjects')); ?></a> / </span><?php echo e(__('common-breadcrumb.create')); ?></h4>

        <div class="col-12 mb-4">
            <div class="card">
                <h5 class="card-header"><?php echo e(__('admin/admin-subject.subject_create')); ?></h5>
                <div class="card-body">
                    <form action="<?php echo e(route('subjects.store')); ?>" enctype="multipart/form-data" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo $__env->make('admin.subjects.form-partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/dropify/dropify.min.js')); ?>"></script>
    <script>
        $(function () {
            $('.dropify').dropify({
                error : {
                    'fileExtension' : "<?php echo e(__('validation.image_type')); ?>",
                }
            });
        });
    </script>
    <?php echo MssValidation::script([
        'request'   => new App\Http\Requests\SubjectForm\CreateSubjectRequest(),
    ]); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dropify/dropify.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/subjects/create.blade.php ENDPATH**/ ?>