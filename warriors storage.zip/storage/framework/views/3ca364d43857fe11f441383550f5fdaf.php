
<div id="account-details" class="content">

    <input type="hidden" id='user-data' value="<?php echo e(isset($student) ?  $student : ''); ?>">

    
    <div class="d-flex gap-3">
        <h5>
            Take Login Account
        </h5>
        <div class="form-check form-switch">
            <input class="form-check-input" <?php echo e(isset($student) && $student->user->take_login_account ? 'checked' : ''); ?> name="take_login_account" type="checkbox" role="switch" id="take-login-account-switch" aria-checked="true">
        </div>
    </div>

    
    <div class="row g-4">

        <div class="col-md-6">

            
            <div class="form-floating form-floating-outline">
                <input
                type="text"
                id="student-name"
                class="form-control"
                placeholder="Enter Student Name"
                name="student_name"
                value="<?php echo e(isset($student)?$student->name:''); ?>"
                />
                <label for="student_name">Student Name</label>
            </div>

            
            <div class="form-floating form-floating-outline mt-3">
                <input
                type="text"
                class="form-control"
                placeholder="Enter Other Name ( Optional )"
                id="other_name"
                name="other_name"
                value="<?php echo e(isset($student)?$student->other_name:''); ?>"
                />
                <label for="other_name"><?php echo e(__('admin/admin-student.other_name')); ?></label>
            </div>


            
            <?php if(!isset($student->student_code)): ?>
                <div class="mt-3 row ">
                    <div class="col-9">
                        <input
                            type="text"
                            class="form-control"
                            disabled
                            id="student_code"
                            name="student_code"
                            data-is-unique="true"
                            value="Student Code Will Be Auto Generated"
                        />
                    </div>
                    <div class="col-3 d-flex align-items-top">
                        <input type="text" hidden value="true" name="is_auto_generate" id='is_auto'>
                        <button class="btn btn-primary col-12 student-code-btn" style="height: 40px;">Manual</button>
                    </div>
                </div>
            <?php endif; ?>

            <?php if(isset($student->student_code)): ?>
            <div class="form-floating form-floating-outline mt-3 row">
                <div class="col-9">
                    <input
                        disabled
                        type="text"
                        class="form-control"
                        id="student_code"
                        name="student_code"
                        data-is-unique="true"
                        data-is-auto-generated="<?php echo e($student->auto_generated); ?>"
                        value="<?php echo e($student->student_code); ?>"
                    />
                </div>
                <div class="col-3">
                    <button 
                        class="btn btn-primary col-12 student-code-edit-btn" 
                        style="height: 40px;"
                        data-is-edit="false"
                    >
                        Edit
                    </button>
                </div>
            </div>
            <?php endif; ?>


            <div id="replace-student-code-place-holder">

            </div>
        

            
            <div class="form-floating form-floating-outline mt-3">
                <input
                type="text"
                id="phone"
                class="form-control"
                placeholder="Enter Phone"
                name="phone"
                value="<?php echo e(isset($student)?$student->phone:''); ?>"
                />
                <label for="phone"><?php echo e(__('common.phone')); ?></label>

            </div>
            

            
            <div class="form-floating form-floating-outline input-group mt-3">
                <select class="form-control select2 nrc-code" id="nrc-code-select">
                    <option value="0">--</option>
                    <?php $__currentLoopData = $nrc_codes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nrc_code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option
                    value="<?php echo e($nrc_code); ?>"
                    <?php if(isset($student)): ?>
                        <?php echo e($student->nrcInfo?->nrc_code ==  $nrc_code? 'selected' : ''); ?>

                    <?php endif; ?>
                    ><?php echo e($nrc_code); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <?php if(isset($student)): ?>
                    <?php
                        $nrcs = App\Models\School\Nrc::where('nrc_code', $student->nrcInfo?->nrc_code)->get();
                    ?>
                    <select class="form-control select2 nrc-name" name="nrc_id" id="">
                        <?php $__currentLoopData = $nrcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nrc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($nrc->id); ?>" <?php if($nrc->id == $student->nrc_id): echo 'selected'; endif; ?>><?php echo e($nrc->name_en); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                <?php else: ?>
                    <select class="form-control select2 nrc-name" name="nrc_id" id=""></select>
                <?php endif; ?>


                <select
                class="form-control select2"
                name="nrc_type"
                id="nrc_type"
                >
                    <?php $__currentLoopData = App\Models\School\Nrc::TYPES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option
                        value="<?php echo e($key); ?>"
                        <?php if(isset($student)): ?>
                            <?php echo e($key == $student->nrc_type?'selected':''); ?>

                        <?php endif; ?>
                        ><?php echo e($value); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <input
                type="text"
                class="form-control"
                placeholder="Enter Code"
                name="nrc"
                id="nrc"
                value="<?php echo e(isset($student)?$student->nrc:''); ?>"
                />
            </div>

            
            <div class="form-floating form-floating-outline mt-3">
                <input
                type="date"
                class="form-control"
                placeholder="YYYY-MM-DD"
                id="date_of_birth"
                name="date_of_birth"
                value="<?php echo e(isset($student)?$student->date_of_birth:''); ?>"
                />
                <label for="date_of_birth"><?php echo e(__('admin/admin-student.date_of_birth')); ?></label>
            </div>

            
            <div class="form-floating form-floating-outline mt-3">
                <input
                type="text"
                id="nationality"
                class="form-control"
                placeholder="Enter Nationality"
                name="nationality"
                value="<?php echo e(isset($student)?$student->nationality:''); ?>"
                />
                <label for="nationality"><?php echo e(__('admin/admin-student.nationality')); ?></label>
            </div>

            
            <div class="form-floating form-floating-outline mt-3">
                <input
                type="text"
                id="family_doctor"
                class="form-control"
                placeholder="Enter Family Doctor"
                name="family_doctor"
                value="<?php echo e(isset($student)?$student->family_doctor:''); ?>"
                />
                <label for="family-doctor"><?php echo e(__('admin/admin-student.family_doctor')); ?></label>
            </div>

            
            <div class="form-floating form-floating-outline mt-3">
                <input
                type="text"
                id="allergy"
                class="form-control"
                placeholder="Enter Allergy"
                name="allergy"
                value="<?php echo e(isset($student)?$student->allergy:''); ?>"
                />
                <label for="allergy"><?php echo e(__('admin/admin-student.allergy')); ?></label>
            </div>

            
            <div class="form-floating form-floating-outline mt-3">
                <input
                type="text"
                id="emergency_phone"
                class="form-control"
                placeholder="Enter Emergrncy Phone"
                name="emergency_phone"
                value="<?php echo e(isset($student)?$student->emergency_phone:''); ?>"
                />
                <label for="emergency-phone"><?php echo e(__('admin/admin-student.emergency_phone')); ?></label>
            </div>

            <div id="user-from">

                
                <div class="form-floating form-floating-outline mt-3">
                    <input
                    type="text"
                    id="user-name"
                    class="form-control"
                    placeholder="Enter User Name"
                    name="user_name"
                    value="<?php echo e(isset($student)? shouldShowInputValue($student->user->name,$student->user->take_login_account) ? $student->user->name : ''   :''); ?>"
                    />
                    <label for="username"><?php echo e(__('admin/admin-student.user_name')); ?></label>
                </div>


                
                <div class="form-floating form-floating-outline mt-3">
                    <input
                    type="email"
                    id="email"
                    class="form-control"
                    placeholder="Enter Email"
                    name="email"
                    value="<?php echo e(isset($student)? shouldShowInputValue($student->user->email,$student->user->take_login_account) ? $student->user->email : '' :''); ?>"
                    />
                    <label for="email"><?php echo e(__('common.email')); ?></label>
                </div>
            
                

                <div class="form-password-toggle fv-plugins-icon-container mt-3">
                    <div class="input-group input-group-merge">
                        <div class="form-floating form-floating-outline position-relative">
                                <i
                                class="mdi mdi-eye-off-outline position-absolute"
                                style="
                                cursor: pointer;
                                right:4%;
                                top: 15px;
                                "
                                ></i>
                                <input
                                name="password"
                                class="form-control"
                                type="password"
                                id="password"
                                placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;"
                                >
                                <label for="currentPassword"><?php echo e(__('common.password')); ?></label>
                        </div>
                    </div>
                </div>
            
                
                <div class="form-password-toggle fv-plugins-icon-container mt-3">
                    <div class="input-group input-group-merge">
                        <div class="form-floating form-floating-outline position-relative">
                            <i
                            class="mdi mdi-eye-off-outline position-absolute"
                            style="
                            cursor: pointer;
                            right:4%;
                            top: 15px;
                            "
                            ></i>
                            <input
                            name="confirm_password"
                            class="form-control"
                            type="password"
                            id="confirm-password"
                            placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;"
                            >
                            <label for="currentPassword"><?php echo e(__('common.confirm_password')); ?></label>
                        </div>
            
                    </div>
                </div>
            
                
                <div class="form-password-toggle fv-plugins-icon-container d-flex align-items-center mt-3">
                    <div class="input-group input-group-merge">
                          <div class="form-check">
                            <?php
                                if (isset($student)) {
                                    if($student->user->take_login_account){
                                        $isFirstTimeLogin = $student->user->firsttime_login;
                                    }else {
                                        $isFirstTimeLogin = false;
                                    }
                                }else{
                                    $isFirstTimeLogin = false;
                                }
                            ?>
                                <input class="form-check-input" name="firsttime_login" type="checkbox"  id="firsttime_login"  <?php echo $isFirstTimeLogin ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="firsttime_login">
                                    <?php echo e(__('admin/admin-student.force_password_reset')); ?>

                                </label>
                          </div>
                    </div>
                    <?php if(isset($student)): ?>
                        <div class="form-group">
                            <label>
                            Active
                            </label> <br>
            
                            <input
                            type="checkbox"
                            name="active"
                            class="switchery"
                            value="true"
                            <?php echo e($student->active?'checked':''); ?>

                            />
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    
        <div class="col-md-6">
            <!-- Gender -->
            <div class="card shadow-sm py-0" id="gender">
                <h5 class="card-header py-3"><?php echo e(__('common.gender')); ?></h5>
                <div class="card-body py-2">
                    <div class="row">
                        <div class="col-md mb-md-0 mb-2">
                            <div class="form-check custom-option custom-option-icon">
                                <label class="form-check-label custom-option-content"
                                    for="std-male">
                                    <span class="custom-option-body">
                                        <span class="mdi mdi-face-man"></span>
                                        <span class="custom-option-title"><?php echo e(__('common.male')); ?></span>
                                    </span>
                                    <input name="gender" class="form-check-input" type="radio"
                                        value="male" id="std-male"
                                        <?php if(isset($student)): ?>
                                            <?php echo e($student->gender == 'male'?'checked':''); ?>

                                        <?php else: ?>
                                            <?php echo e('checked'); ?>

                                        <?php endif; ?>
                                        />
                                </label>
                            </div>
                        </div>
                        <div class="col-md mb-md-0 mb-2">
                            <div class="form-check custom-option custom-option-icon">
                                <label class="form-check-label custom-option-content"
                                    for="std-female">
                                    <span class="custom-option-body">
                                        <span class="mdi mdi-face-woman"></span>
                                        <span class="custom-option-title"><?php echo e(__('common.female')); ?></span>
                                    </span>
                                    <input name="gender" class="form-check-input" type="radio"
                                        value="female" id="std-female"
                                        <?php if(isset($student)): ?>
                                            <?php echo e($student->gender == 'female'?'checked':''); ?>

                                        <?php endif; ?>
                                        />
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="form-floating form-floating-outline mt-3">
                <select name="country_id" id="country-select" class="select2 form-select">
                    <option value="">Select Country</option>
                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <label for="country_id">Country</label>
            </div>

            
            <div class="form-floating form-floating-outline mt-3">
                <select name="city_id" id="city-select" class="select2 form-select">
                    <option value="">Select City</option>
                </select>
                <label for="city_id">City</label>
            </div>


            
            <div class="form-floating form-floating-outline mt-3">
                <select name="township_id" id="township-select" class="select2 form-select">
                    <option value="">Select Township</option>
                </select>
                <label for="township_id">Township</label>
            </div>
            

            
            <div class="form-floating form-floating-outline mb-4 mt-3">
                <textarea
                name="address"
                class="form-control h-px-120"
                id="address"
                placeholder="Enter Address"><?php echo e(isset($student)?$student->address:''); ?></textarea>
                <label for="exampleFormControlTextarea1"><?php echo e(__('admin/admin-student.address')); ?></label>
            </div>

            
            <div class="">
                <label class="form-label text-black">
                    <?php echo e(__('admin/admin-student.profile_image')); ?>

                </label>
                <input
                type="file"
                name="image"
                class="dropify"
                data-default-file="<?php echo e(isset($student->image)?get_file($student->image):''); ?>"
                data-allowed-file-extensions='[
                    "png", "PNG", "jpg", "JPG", "jpeg", "JPEG"
                ]'
                >
            </div>
            

        </div>

    </div>

    
    <div class="col-12 d-flex justify-content-between mt-3">
        <a href="<?php echo e(route('students.index')); ?>" class="btn btn-outline-secondary">
            <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
            <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('common.back')); ?></span>
        </a>
            <button type="button" class="btn-next invisible" id="to-pg2-btn"><?php echo e(__('common.next')); ?></button>
        <button type="button" class="btn btn-primary call-first-step-validation">
            <span class="align-middle d-sm-inline-block d-none me-sm-1"><?php echo e(__('common.next')); ?></span>
            <i class="mdi mdi-arrow-right"></i>
        </button>
    </div>

</div>





<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/students/form-partials/first-step-student-info.blade.php ENDPATH**/ ?>