<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?> / </span> <?php echo e(__('admin/breadcrumb/my-profile.profile')); ?></h4>
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">
                        <h4 class="text-mute mb-5"><?php echo e(__('admin/admin-my-profile.profile_information')); ?></h4>
                        <form action="<?php echo e(route('profile.update')); ?>" method="POST" class="px-2" id="profile">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <div class="form-floating form-floating-outline mb-4">
                                <input type="text" id="name" class="form-control" placeholder="<?php echo e(__('admin/admin-my-profile.name_placeholder')); ?>"
                                    name="name"
                                    value="<?php echo e(auth()->user()->name); ?>"
                                    />
                                <label for="name"><?php echo e(__('admin/admin-my-profile.name')); ?></label>
                            </div>

                            <div class="form-floating form-floating-outline mb-4">
                                <input type="text" id="name" class="form-control" placeholder="<?php echo e(__('admin/admin-my-profile.email_placeholder')); ?>"
                                    name="email"
                                    value="<?php echo e(auth()->user()->email); ?>"
                                    />
                                <label for="name"><?php echo e(__('common.email')); ?></label>
                            </div>

                            <div class="form-floating form-floating-outline mb-4">
                                <input type="text" id="token" class="form-control" placeholder="Enter Auth Token"
                                    name="token"
                                    value="<?php echo e(auth()->user()->token); ?>"
                                    />
                                <label for="token"><?php echo e(__('Auth Token')); ?></label>
                            </div>

                            <button type="submit" id="profile_update" class="btn btn-primary btn-sm">
                                <?php echo e(__('admin/admin-my-profile.save')); ?>

                            </button>
                        </form>

                        <hr>

                        <h4 class="text-mute mb-5"><?php echo e(__('admin/admin-my-profile.update_password')); ?></h4>
                        <form action="<?php echo e(route('profile.password.update')); ?>" method="POST" class="px-2" id="password">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <div class="form-password-toggle fv-plugins-icon-container">
                                <div class="input-group input-group-merge">
                                    <div class="form-floating form-floating-outline position-relative">
                                        <i
                                        class="mdi mdi-eye-off-outline position-absolute"
                                        style="
                                        cursor: pointer;
                                        right:4%;
                                        top: 15px;
                                        "
                                        ></i>
                                        <input
                                        name="current_password"
                                        class="form-control"
                                        type="password"
                                        id="current_password"
                                        placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;"
                                        >
                                        <label for="current_password"><?php echo e(__('admin/admin-my-profile.current_password')); ?></label>
                                    </div>
                                </div>
                            </div>

                            <div class="form-password-toggle mt-4 fv-plugins-icon-container">
                                <div class="input-group input-group-merge">
                                    <div class="form-floating form-floating-outline position-relative">
                                        <i
                                        class="mdi mdi-eye-off-outline position-absolute"
                                        style="
                                        cursor: pointer;
                                        right:4%;
                                        top: 15px;
                                        "
                                        ></i>
                                        <input
                                        name="new_password"
                                        class="form-control"
                                        type="password"
                                        id="new_password"
                                        placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;"
                                        >
                                        <label for="new_password"><?php echo e(__('admin/admin-my-profile.new_password' )); ?></label>
                                    </div>
                                </div>
                            </div>

                            <div class="mt-4 form-password-toggle fv-plugins-icon-container">
                                <div class="input-group input-group-merge">
                                    <div class="form-floating form-floating-outline position-relative">
                                        <i
                                        class="mdi mdi-eye-off-outline position-absolute"
                                        style="
                                        cursor: pointer;
                                        right:4%;
                                        top: 15px;
                                        "
                                        ></i>
                                        <input
                                        name="confirm_password"
                                        class="form-control"
                                        type="password"
                                        id="confirm_password"
                                        placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;"
                                        >
                                        <label for="currentPassword"><?php echo e(__('common.confirm_password')); ?></label>
                                    </div>
                                </div>
                            </div>

                            <button
                            type="button"
                            id="password_update"
                            class="btn btn-primary btn-sm mt-4"
                            data-url="<?php echo e(route('admin-password-update-validtion',auth()->user())); ?>"
                            >
                                <?php echo e(__('admin/admin-my-profile.save')); ?>

                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(function () {
            let keys;
            $('#profile_update').click(function (e) {
                e.preventDefault();

                keys  = ['name', 'email', 'token'];
                rules = {
                    name: 'required|max:255',
                    email: 'required|email',
                    token: 'nullable'
                };

                validateNew({
                    keys: keys,
                    rules: rules,
                    fileValidate: false
                }).then(() => {
                    $('form#profile').submit();
                });
            });

            $('#password_update').click(function (e) {
                e.preventDefault();

                keys  = ['current_password', 'new_password', 'confirm_password'];

                validate({
                    keys: keys,
                    url: $(this).data('url'),
                }).then(() => {
                    $('form#password').submit();
                })
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/admins/profile.blade.php ENDPATH**/ ?>