<div>
    <a 
    data-bs-toggle="tooltip" data-bs-placement="top"
    title="Assignments" 
    href="<?php echo e(route('assignments.list.index',['course'=>$id])); ?>" class="btn btn-sm btn-icon btn-primary waves-effect waves-light">
        <span class="mdi mdi-clipboard-text"></span>
    </a>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/assignment/action.blade.php ENDPATH**/ ?>