<?php $__env->startSection('container'); ?>

<input hidden id="bulk-import-url" value="<?php echo e(route('teacher.teacher-bulk-import')); ?>"/>

<section  id="validation-errors-container" style="display: none">
    <div class="container-xxl flex-grow-1 container-p-y"  >
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?> / </span> <?php echo e(__('admin/breadcrumb/teacher.teachers')); ?></h4>
        <?php echo $__env->make('components.bulkimportissuelist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</section>

<section id='datatable'>
    <div class="container-xxl flex-grow-1 container-p-y"  >
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?> / </span> <?php echo e(__('admin/breadcrumb/teacher.teachers')); ?></h4>
        <div class="table-responsive text-nowrap" style="position: relative">
            <?php echo $dataTable->table(); ?>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('teleport'); ?>
    <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel">
            Import Teachers
            <a
            title="Download Sample Excel"
            download
            href="<?php echo e(asset('bulkimport/TeacherBulkImport.xlsx')); ?>"
            class=""
            >
                <span class="mdi mdi-download"></span>
            </a>
          </h1>

          <button
          type="button"
          class="btn-close"
          data-bs-dismiss="modal"
          aria-label="Close"
          ></button>
        </div>

        <div class="modal-body">
            <input
            id="excel-file-input"
            type="file"
            accept=".xlsx"
            class="form-control" >
        </div>

        <div class="modal-footer">
            <button id="modal-close-btn" type="button" class="btn btn-sm btn-outline-secondary waves-effect" data-bs-dismiss="modal"><?php echo e(__('admin/admin-teacher-assign-course.close')); ?></button>

            <button
            type="button"
            id="excel-file-input-btn"
            class="btn btn-sm btn-primary"
            >
                Import
            </button>

            <button class="btn complete-hide btn-sm btn-primary" id="loading">
                <div class="d-flex gap-2 align-items-center">
                    Importing
                    <div
                    style="width:18px;height:18px;"
                    class="spinner-border text-white" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            </button>
        </div>
      </div>
    </div>
  </div>

<?php echo $__env->make('components.activateUserAccount', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <?php echo e($dataTable->scripts(attributes: ['type' => 'module'])); ?>


    <script type="module">
        $(function () {
            const $btns = `
                <button
                title="Bulk Import"
                class="btn btn-primary btn-sm"
                data-bs-toggle="modal"
                data-bs-target="#exampleModal"
                >
                    <span class="mdi mdi-file-import me-2"></span>
                    <small>Import</small>
                </button>
            `;

            $('.dt-buttons').append($btns);
        });
    </script>

    <script src="<?php echo e(asset('assets/js/bulkimport/bulkimport.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/teachers/index.blade.php ENDPATH**/ ?>