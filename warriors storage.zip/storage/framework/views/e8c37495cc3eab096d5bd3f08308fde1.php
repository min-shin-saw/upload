<div class="row">
    <div class="col-md-6 col-12 mb-4">
        <div class="form-floating form-floating-outline">
            <input type="text" id="name" class="form-control" placeholder="Enter Lesson Name"
                name="name"
                value="<?php echo e(isset($lesson)?$lesson->name:''); ?>"
                />
            <label for="name"><?php echo e(__('admin/admin-lesson.lesson_name')); ?></label>
        </div>
    </div>

    <div class="col-md-6 col-12 mb-4">
        <div class="form-floating form-floating-outline mb-4">
            <select name="section_id" class="select2 form-select form-select-lg">
                <?php if(!isset($lesson)): ?>
                    <option value="">Select Section</option>
                <?php endif; ?>
                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option
                        <?php if(isset($lesson) && $lesson->section_id == $section->id): ?>
                            selected
                        <?php endif; ?>
                        value="<?php echo e($section->id); ?>"
                    >
                        <?php echo e($section->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <label for=""><?php echo e(__('Section')); ?></label>
        </div>
    </div>

    <div class="col-12 mb-4">
        <div class="form-floating form-floating-outline lesson-duration">
            <input type="text" id="duration" class="form-control" placeholder="Enter Course Duration"
                name="duration"
                value="<?php echo e(isset($lesson)?$lesson->duration:''); ?>"
                />
            <label for="duration"><?php echo e(__('admin/admin-lesson.lesson_duration')); ?></label>
        </div>
    </div>

    <div class="col-12 mb-4">
        <div class="card">
          <h6 class="card-header"><?php echo e(__('admin/admin-lesson.content_type')); ?></h6>
          <div class="card-body">
            <div class="row">
                <?php $__currentLoopData = App\Models\Learning\Lesson::TYPES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $content_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col mb-2">
                        <div class="form-check custom-option custom-option-icon">
                        <label class="form-check-label custom-option-content" for="customRadioSvg<?php echo e($index); ?>">
                            <span class="custom-option-body">
                            <img
                                src="<?php echo e(asset(App\Models\Learning\Lesson::TYPEICONS[$content_type])); ?>"
                                class="w-px-20 mb-2"
                                alt="paypal" />
                            <span class="custom-option-title"> <?php echo e($content_type); ?> </span>
                            </span>
                            <input
                            name="content_type"
                            class="form-check-input"
                            type="radio"
                            value="<?php echo e($content_type); ?>"
                            <?php if(isset($lesson)): ?>
                                <?php if($content_type == $lesson->content_type): echo 'checked'; endif; ?>
                            <?php else: ?>
                                <?php if($content_type == "Video"): echo 'checked'; endif; ?>
                            <?php endif; ?>
                            id="customRadioSvg<?php echo e($index); ?>"
                            />
                        </label>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
    </div>

    <div class="col-12">
        <label for="exampleFormControlTextarea1"><?php echo e(__('admin/admin-lesson.description')); ?></label>
        <textarea
        name="description"
        class="form-control"
        id="lesson-description"
        placeholder="Enter Description"><?php echo e(isset($lesson)?$lesson->description:''); ?></textarea>
    </div>

    <div class="col-12">
        <div class="card py-2 shadow-sm">
            <div class="row g-0">
                <div class="col-md-7">
                    <div class="card-body">
                        <label for="profile" class="form-label"><?php echo e(__('admin/admin-lesson.content')); ?></label>
                        <div class="content-input-container">
                            <?php if(isset($lesson)): ?>
                                <?php if($lesson->content_type == 'Youtube'): ?>
                                    <div class="form-floating form-floating-outline lesson-duration">
                                        <input
                                        type="text"
                                        id="youtube-content"
                                        class="form-control" placeholder="Enter Youtube Url"
                                        name="content"
                                        value="https://www.youtube.com/watch?v=<?php echo e($lesson->content); ?>"
                                        />
                                        <label for="youtube-content">Youtube Url</label>
                                    </div>
                                <?php elseif($lesson->content_type == 'Drive'): ?>
                                    <div class="form-floating form-floating-outline lesson-duration">
                                        <input
                                        type="text"
                                        id="drive-content"
                                        class="form-control" placeholder="Enter Youtube Url"
                                        name="content"
                                        value="https://drive.google.com/file/d/<?php echo e($lesson->content); ?>"
                                        />
                                        <label for="drive-content">Drive Url</label>
                                    </div>
                                <?php elseif($lesson->content_type == 'Pdf'): ?>
                                    <input name="content" accept=".pdf" class="form-control" type="file"
                                    id="content">
                                <?php elseif($lesson->content_type == 'Zip'): ?>
                                    <input name="content" accept=".zip" class="form-control" type="file"
                                    id="content">
                                <?php elseif($lesson->content_type == 'Audio'): ?>
                                    <input name="content" accept=".mp3" class="form-control" type="file"
                                    id="content">
                                <?php else: ?>
                                    <input name="content" accept=".mp4" class="form-control" type="file"
                                    id="content">
                                <?php endif; ?>
                            <?php else: ?>
                                <input name="content" accept=".mp4" class="form-control" type="file"
                                id="content">
                            <?php endif; ?>
                        </div>
                        <p class="card-text">
                            <small class="text-danger" id="content-error"></small>
                        </p>
                    </div>
                </div>
                <div class="col-md-5 content-file-container">
                    <?php if(isset($lesson)): ?>
                        <?php if($lesson->content_type == 'Video'): ?>
                        <img
                        src="<?php echo e(asset('assets/img/placeholders/video-placeholder.png')); ?>"
                        alt="subject image"
                        class="card-img card-img-right"
                        >
                        <?php elseif($lesson->content_type == 'Audio'): ?>
                            <div class="h-100 d-flex align-items-center">
                                <img
                                src="<?php echo e(asset('assets/img/placeholders/audio-placeholder.png')); ?>"
                                alt="subject image"
                                class="card-img card-img-right"
                                >
                            </div>
                        <?php elseif(in_array($lesson->content_type,['Pdf','Zip'])): ?>
                        <div class="col-4 mb-2">
                            <div class="form-check custom-option custom-option-icon">
                                <label class="form-check-label custom-option-content" for="customRadioSvg">
                                    <span class="custom-option-body">
                                    <img
                                        src="<?php echo e(asset(App\Models\Learning\Lesson::TYPEICONS[$lesson->content_type])); ?>"
                                        class="w-px-30 mb-2"
                                        alt="paypal" />
                                    <span class="custom-option-title">
                                        <a class="" target="blank" href="<?php echo e(get_file($lesson->content)); ?>">
                                            View
                                        </a>
                                    </span>
                                    </span>
                                </label>
                            </div>
                        </div>
                        <?php elseif($lesson->content_type == 'Drive'): ?>
                            <iframe class="card-img card-img-right" src="https://drive.google.com/file/d/<?php echo e($lesson->content); ?>/preview" width="400" height="225" allow="autoplay"></iframe>
                        <?php else: ?>
                            <iframe class="card-img card-img-right" width="400" height="225" src="https://www.youtube.com/embed/<?php echo e($lesson->content); ?>" frameborder="0" allowfullscreen></iframe>
                        <?php endif; ?>
                    <?php else: ?>
                    <img
                    src="<?php echo e(asset('assets/img/placeholders/video-placeholder.png')); ?>"
                    alt="subject image"
                    class="card-img card-img-right"
                    >
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>

</div>
<div class="mt-3 d-flex justify-content-between">
    <a href="<?php echo e(route('lessons.index',isset($lesson)?$lesson->subject:$subject)); ?>" class="btn btn-outline-secondary">
        <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
        <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('common.back')); ?></span>
    </a>

    <button
    class="btn btn-primary ms-2 d-none"
    id="load-btn"
    type="button"
    >
        <span class="spinner-border me-1" role="status" aria-hidden="true"></span>
        Processing...
    </button>

    <button class="btn btn-primary ms-2" id="submit-btn" type="button">
        <?php echo e(__('common.submit')); ?>

    </button>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/lessons/form-partials/form.blade.php ENDPATH**/ ?>