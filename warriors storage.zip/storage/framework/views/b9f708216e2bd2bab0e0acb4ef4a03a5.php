<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4">
            <span class="text-muted fw-light">
                Dashboard /
                <a href="<?php echo e(route('certificates.templates.index')); ?>">
                    Certificate
                </a> /
            </span>
            Create
        </h4>

        <div class="col-12 mb-4">
            <div class="card">
                <h5 class="card-header">Certificate Create</h5>
                <div x-data="state" class="card-body">
                    <form
                    action="<?php echo e(route('certificates.templates.store')); ?>"
                    enctype="multipart/form-data"
                    method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo $__env->make('admin.certificates.form-partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-script'); ?>
    <script
    defer
    src="<?php echo e(asset('assets/js/plugin/alpinejs.min.js')); ?>">
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/tinymce/tinymce.min.js')); ?>"></script>

    <script defer>
        const state = {
            type: "",
            firstLoad: false,
            bgChange(e) {
                const reader = new FileReader();
                reader.readAsDataURL(e.target.files[0]);

                reader.onload = function(e) {
                    $('.editorText')
                        .css("background-image", "url(" + e.target.result + ")");
                }
            }
        }
    </script>

    <script>
        tinymce.init({
          selector: '#inner_html',
          setup: (editor) => {
            editor.on('keyup', (e) => {
                $('.editorText').html(
                    tinymce.activeEditor.getContent()
                );
            });
          }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .trix-content {
            min-height: 200px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/certificates/create.blade.php ENDPATH**/ ?>