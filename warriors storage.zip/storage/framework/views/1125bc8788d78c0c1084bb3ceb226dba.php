<footer class="content-footer footer bg-footer-theme">
    <div class="container-xxl">
        <div class="footer-container d-flex align-items-center justify-content-center py-3 flex-md-row flex-column">
            <div class="mb-2 mb-md-0 ">
                ©
                <script>
                    document.write(new Date().getFullYear());
                </script>
                , made with <span class="text-danger">❤️</span> by
                <a href="https://www.minshinsaw.com" target="_blank" class="footer-link fw-medium">Min Shin Saw</a>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/layout/shared/footer.blade.php ENDPATH**/ ?>