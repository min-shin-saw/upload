<form
action="<?php echo e(route('timetables.custom-time.update',$customTime)); ?>"
method="POST"
>
    <?php echo csrf_field(); ?>
    <h4><?php echo e($customTime->title); ?> (<?php echo e($customTime->day); ?>) Edit</h4>

    <div class="form-floating form-floating-outline mb-4">
        <input
        type="text"
        id="title"
        class="form-control"
        placeholder="Enter Title"
        name="title"
        value="<?php echo e($customTime->title); ?>"
        />
        <label for="title">
            Title
        </label>
    </div>

    <div class="row mb-4">
        <div class="col-md-6">
            <div class="form-floating form-floating-outline " >
                <input
                type="time"
                id="start-time"
                class="form-control start-time"
                name="start_time"
                value="<?php echo e($customTime->start_time); ?>"
                />
                <label for=""><?php echo e(__('admin/admin-timetable.start_time')); ?></label>
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-floating form-floating-outline " >
                <input
                type="time"
                id="end-time"
                class="form-control end-time"
                name="end_time"
                value="<?php echo e($customTime->end_time); ?>"
                />
                <label for=""><?php echo e(__('admin/admin-timetable.end_time')); ?></label>
            </div>
        </div>
    </div>

    <div class="form-floating form-floating-outline mb-4">
        <input
          class="form-control"
          type ="color"
          id   ="html5-color-input"
          name ="color"
          value="<?php echo e($customTime->color); ?>"
        />
        <label for="html5-color-input">
            Color
        </label>
    </div>

    <button class="btn btn-primary" type="submit">
        <?php echo e(__('common.submit')); ?>

    </button>
</form>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/timetables/custom-time-detail.blade.php ENDPATH**/ ?>