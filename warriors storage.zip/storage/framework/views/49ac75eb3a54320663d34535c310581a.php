<div>
    <a 
    data-bs-toggle="tooltip" data-bs-placement="top" title="Timetable Info"
    href="<?php echo e(route('timetable-formats.index',['course' => $id])); ?>" class="btn btn-sm btn-icon btn-success waves-effect waves-light">
        <span class="mdi mdi-timetable" ></span>
    </a>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/timetables/action.blade.php ENDPATH**/ ?>