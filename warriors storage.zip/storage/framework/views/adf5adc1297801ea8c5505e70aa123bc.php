<div>
    <div class="row">
        <div class="col-md-6">
            <div class="form-floating form-floating-outline mb-4">
                <input
                    name="driver_name"
                    type="text"
                    class="form-control"
                    placeholder="<?php echo e(__('admin/admin-ferry.driver_name_placeholder')); ?>"
                    value="<?php echo e(isset($ferry)? $ferry->driver_name : ''); ?>"
                >
                <label for="driver_name"><?php echo e(__('admin/admin-ferry.driver_name_label')); ?></label>
            </div>
            <div class="form-floating form-floating-outline mb-4">
                <input
                    name="driver_address"
                    type="text"
                    class="form-control"
                    placeholder="<?php echo e(__('admin/admin-ferry.driver_address_placeholder')); ?>"
                    value="<?php echo e(isset($ferry)? $ferry->driver_address : ''); ?>"
                >
                <label for="driver_address"><?php echo e(__('admin/admin-ferry.driver_address_label')); ?></label>
            </div>
            <div class="form-floating form-floating-outline mb-4">
                <input
                    name="driver_phone_number"
                    type="text"
                    class="form-control"
                    placeholder="<?php echo e(__('admin/admin-ferry.driver_phone_number_placeholder')); ?>"
                    value="<?php echo e(isset($ferry)? $ferry->driver_phone_number : ''); ?>"
                >
                <label for="driver_phone_number"><?php echo e(__('admin/admin-ferry.driver_phone_number_label')); ?></label>
            </div>
            <div class="form-floating form-floating-outline mb-4">
                <input
                    name="car_platenumber"
                    type="text"
                    class="form-control"
                    placeholder="<?php echo e(__('admin/admin-ferry.car_platenumber_placeholder')); ?>"
                    value="<?php echo e(isset($ferry)? $ferry->car_platenumber : ''); ?>"
                >
                <label for="car_platenumber"><?php echo e(__('admin/admin-ferry.car_platenumber_label')); ?></label>
            </div>
            <div class="form-floating form-floating-outline mb-4">
                <input
                    name="ferry_name"
                    type="text"
                    class="form-control"
                    placeholder="<?php echo e(__('admin/admin-ferry.ferry_name_placeholder')); ?>"
                    value="<?php echo e(isset($ferry)? $ferry->ferry_name : ''); ?>"
                >
                <label for="ferry_name"><?php echo e(__('admin/admin-ferry.ferry_name_label')); ?></label>
            </div>
            <div class="form-floating form-floating-outline mb-4">
                <input
                    name="ferry_route"
                    type="text"
                    class="form-control"
                    placeholder="<?php echo e(__('admin/admin-ferry.ferry_route_placeholder')); ?>"
                    value="<?php echo e(isset($ferry)? $ferry->ferry_route : ''); ?>"
                >
                <label for="ferry_route"><?php echo e(__('admin/admin-ferry.ferry_route_label')); ?></label>
            </div>
            <div class="form-floating form-floating-outline mb-4">
                <input
                    name="seat_count"
                    type="number"
                    class="form-control"
                    placeholder="<?php echo e(__('admin/admin-ferry.seat_count_placeholder')); ?>"
                    value="<?php echo e(isset($ferry)? $ferry->seat_count : ''); ?>"
                >
                <label for="seat_count"><?php echo e(__('admin/admin-ferry.seat_count_label')); ?></label>
            </div>

        </div>

        <div class="col-md-6">
            
       

            <div class="">
                <label class="form-label text-black">
                    <?php echo e(__('admin/admin-ferry.driver_image_label')); ?>

                </label>
                <input
                    type="file"
                    name="driver_image"
                    class="dropify"
                    data-default-file="<?php echo e(isset($ferry->driver_image) ? get_file($ferry->driver_image):''); ?>"
                    data-allowed-file-extensions='[
                        "png", "PNG", "jpg", "JPG", "jpeg", "JPEG"
                    ]'
                >
            </div>

            
            <div class="mt-4">
                <label class="form-label text-black">
                    <?php echo e(__('admin/admin-ferry.driver_license_label')); ?>

                </label>
                <input
                type="file"
                name="driver_license"
                class="dropify"
                data-default-file="<?php echo e(isset($ferry->driver_license) ? get_file($ferry->driver_license) : ''); ?>"
                data-allowed-file-extensions='[
                    "png", "PNG", "jpg", "JPG", "jpeg", "JPEG"
                ]'
                >
            </div>



        </div>

        <div class="row">

            <div class="form-floating form-floating-outline  col-md-6 mt-3 md-mt-0">
                <select
                    id="city-select"
                    name="city_id"
                    class="form-control select2"
                    value="<?php echo e(isset($ferry)? '' : ''); ?>"
                >
                    <option value=""><?php echo e(__('admin/admin-ferry.select_city')); ?></option>
                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($city->id); ?>" <?php echo e(isset($ferry) && $ferry->township->city->id == $city->id ? 'selected' : ''); ?>><?php echo e($city->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <label for="city_id"><?php echo e(__('admin/admin-ferry.select_city_label')); ?></label>
            </div>


            <div class="form-floating form-floating-outline mt-3 md-mt-0  col-md-6">
                <select
                    id="township-select"
                    name="township_id"
                    class="form-control"
                    value="<?php echo e(isset($ferry)? $ferry->township_id : ''); ?>"
                >
                    <option value=""><?php echo e(__('admin/admin-ferry.select_township')); ?></option>
                </select>
                <label for="township_id"><?php echo e(__('admin/admin-ferry.select_township_label')); ?></label>
            </div>
        </div>

        <div class="col-12 mb-4 mt-4 md-mt-0">
            <div class="form-floating form-floating-outline">
                <textarea
                    name="remark"
                    class="form-control h-px-120"
                    id="remark"
                    
                >
                    <?php echo e(isset($ferry) ? $ferry->remark:''); ?>

                </textarea>
                <label for="remark"><?php echo e(__('admin/admin-ferry.remark_label')); ?></label>
            </div>
        </div>

    </div>
    <div class="mt-3 d-flex justify-content-between">
        <a href="<?php echo e(route('ferries.index')); ?>" class="btn btn-outline-secondary">
            <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
            <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('common.back')); ?></span>
        </a>

        <button class="btn btn-primary ms-2" id="submit-btn" type="button">
            <?php echo e(__('common.submit')); ?>

        </button>
    </div>
</div>

<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/ferries/form.blade.php ENDPATH**/ ?>