<?php $__env->startSection('container'); ?>
 
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?> / <a
                    href="<?php echo e(route('students.index')); ?>"><?php echo e(__('admin/breadcrumb/student.students')); ?></a> / </span><?php echo e(__("common-breadcrumb.create")); ?></h4>
        
        <h5 class="card-header"><?php echo e(__('admin/admin-student.student_create')); ?></h5>
        <div class="col-12 mb-4">
            <div class="bs-stepper wizard-numbered mt-2">
                <div class="bs-stepper-header">
                    <div class="step" data-target="#account-details">
                        <button type="button" class="step-trigger">
                            <span class="bs-stepper-circle"><i class="mdi mdi-check"></i></span>
                            <span class="bs-stepper-label">
                                <span class="bs-stepper-number">01</span>
                                <span class="d-flex flex-column gap-1 ms-2">
                                    <span class="bs-stepper-title"><?php echo e(__('admin/admin-student.student_info')); ?></span>
                                    <span class="bs-stepper-subtitle">Basic Student Details</span>
                                </span>
                            </span>
                        </button>
                    </div>
                    <div class="line"></div>
                    <div class="step" data-target="#personal-info">
                        <button type="button" class="step-trigger">
                            <span class="bs-stepper-circle"><i class="mdi mdi-check"></i></span>
                            <span class="bs-stepper-label">
                                <span class="bs-stepper-number">02</span>
                                <span class="d-flex flex-column gap-1 ms-2">
                                    <span class="bs-stepper-title"><?php echo e(__('admin/admin-student.parent_info')); ?></span>
                                    <span class="bs-stepper-subtitle">Add Parents info</span>
                                </span>
                            </span>
                        </button>
                    </div>
                    <div class="line"></div>
                    <div class="step" data-target="#social-links">
                        <button type="button" class="step-trigger">
                            <span class="bs-stepper-circle"><i class="mdi mdi-check"></i></span>
                            <span class="bs-stepper-label">
                                <span class="bs-stepper-number">03</span>
                                <span class="d-flex flex-column gap-1 ms-2">
                                    <span class="bs-stepper-title"><?php echo e(__('admin/admin-student.guardian_info')); ?></span>
                                    <span class="bs-stepper-subtitle">Add Guardian</span>
                                </span>
                            </span>
                        </button>
                    </div>
                </div>
                <div class="bs-stepper-content">
                    
                    <input type="hidden" id="unique-student-code-check-url" value="<?php echo e(route('student.unique-student-code')); ?>">
                    <input type="hidden" id="replace-student-code-url" value="<?php echo e(route('student.replace-student-code')); ?>">
                    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

                    <form action="<?php echo e(route('students.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="has_guardian">
                        <!-- Student Info -->
                        <input type="hidden" value="<?php echo e(route('student-form.first-step')); ?>" id="first-step-validation">
                        <?php echo $__env->make('admin.students.form-partials.first-step-student-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <!-- Parents Info -->
                        <input type="hidden" value="<?php echo e(route('student-form.second-step')); ?>" id="second-step-validation">
                        <?php echo $__env->make('admin.students.form-partials.second-step-parent-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <!-- Guardian Info -->
                        <input type="hidden" value="<?php echo e(route('student-form.third-step.exist-guardian')); ?>" id="third-step-exist-guardian-validation">
                        <input type="hidden" value="<?php echo e(route('student-form.third-step.new-guardian')); ?>" id="third-step-new-guardian-validation">
                        <?php echo $__env->make('admin.students.form-partials.third-step-guardian-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </form>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>


    
    <script src="<?php echo e(asset(
        'assets/js/form-handling/data-preparation/create-student-first-step.js'
    )); ?>"></script>

    <script src="<?php echo e(asset(
        'assets/js/form-handling/data-preparation/create-student-second-step.js'
    )); ?>"></script>

    <script src="<?php echo e(asset(
        'assets/js/form-handling/data-preparation/create-student-third-step.js'
    )); ?>"></script>

    <script src="<?php echo e(asset('assets/dropify/dropify.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/mohithg-switchery/mohithg-switchery.min.js')); ?>"></script>

 

    <script>
        $(function() {

            const toggleCheckbox = (selector, currentCheckbox) => {
                const disable = $(currentCheckbox).prop('checked');
                $(selector).prop('disabled', disable);
            }

            const getValues = (type) => {
                const name = $(`#${type}-name`).val();
                const email = $(`#${type}-email`).val();
                const phone = $(`#${type}-phone`).val();
                const nrcId = $(`#${type}-nrc-id-create`).val();
                localStorage.setItem('nrc_id', nrcId);
                const nrcCode = $(`#${type}-nrc-code-create`).val();
                const nrcType = $(`#${type}-nrc-type-create`).val();
                const nrcNumber = $(`#${type}-nrc-create`).val();
                if (type == 'mother') {
                    $('[name=guardian_gender]').eq(0).prop('checked', false); 
                    $('[name=guardian_gender]').eq(1).prop('checked', true);  
                } else {
                    $('[name=guardian_gender]').eq(1).prop('checked', false);
                    $('[name=guardian_gender]').eq(0).prop('checked', true); 
                }

                setValue(name, email, phone, nrcCode, nrcType, nrcNumber);
            }


            const setValue = (name,email,phone,nrc_code,nrc_type,nrc_number)=>{
                $('#guardian-name-create').val(name);
                $('#guardian-email-create').val(email);
                $('#guardian-phone-create').val(phone);
                $('#guardian-nrc-code-create').select2('val',nrc_code);
                $('#guardian-type-create').select2('val',nrc_type);
                $('#guardian-nrc-create').val(nrc_number);
            }

            $('.call-second-step-validation').click(function () {
                let isMother =  $("#carry-mother-as-guardian").is(':checked');
                let isFather =  $("#carry-father-as-guardian").is(':checked');

                if (isMother) {
                    getEmailAndheck("[name=mother_email]","mother");
                }else if(isFather){
                    getEmailAndheck("[name=father_email]","father");
                }else{
                    resetForm()
                }
            })

            $("#carry-father-as-guardian").change(function() {
                toggleCheckbox("#carry-mother-as-guardian", this);
            });

            $("#carry-mother-as-guardian").change(function() {
                toggleCheckbox("#carry-father-as-guardian", this);
            });

            let selectTheGuardianWithEmail= (email)=>{
                let selectElement = $('#guardian-select-create');
                let matchFound = false;
                selectElement.find('option').each(function() {
                    var optionEmail = $(this).text().match(/Email:\s*([^\s,]+)/);
                    if (optionEmail) {
                        if (optionEmail[1] === email) {
                            matchFound = true;
                            selectedIdForGuardian = $(this).val()
                           $('#guardian-select-create').select2("val",selectedIdForGuardian);
                        }
                    }
                });
                return matchFound;
            }


            let getEmailAndheck = (selector,type) => {
                email = $(selector).val();
                isEmailHasGuardian = selectTheGuardianWithEmail(email);
                if (!isEmailHasGuardian ) {
                    getValues(type);
                    $('#guardian-select-create').select2("val",'');
                    $('#call-guardian-from').val('new')
                    $('.exist-guardian').hide();
                    $('.new-guardian').show()
                }else{
                    $('#call-guardian-from').val('exist')
                    $('.exist-guardian').show();
                    $('.new-guardian').hide()
                }
             }


             let resetForm = ()=>{
                $('#guardian-name-create').val('');
                $('#guardian-email-create').val('');
                $('#guardian-phone-create').val('');
                $('#guardian-nrc-code-create').select2('val',0);
                $('#guardian-type-create').select2('val','N');
                $('#guardian-nrc-id-create').select2('val',0)
                $('#guardian-nrc-create').val('');
                $('#call-guardian-from').val('exist')
                $('.exist-guardian').show();
                $('.new-guardian').hide()
                $('#guardian-select-create').select2("val",0);
             }
        });
    </script>

    <!-- Region Scripts -->
    <script>
        $(document).ready(function(){

            let cities                      = <?php echo json_encode($cities, 15, 512) ?>;
            let townships                   = <?php echo json_encode($townships, 15, 512) ?>;
            let countrySelect               = $('#country-select');
            let citySelect                  = $('#city-select');
            let townshipSelect              = $('#township-select');
            let defaultTownshipOption       = '<option value="">Select Township</option>';
            let defaultCityOption           = '<option value="">Select City</option>';

            let renderUi = (obj,condition,text) =>  {
                let els = `<option value="">${text}</option>`;
                obj.forEach(el => {
                    if(condition(el)){
                        els += `<option value="${el.id}">${el.name}</option>`;
                    }
                });
                return els
            }

            countrySelect.change(function(){
                let selectedCountryId = $(this).val();
                citySelect.html(
                    renderUi(cities,(el)=>el.country_id == selectedCountryId,'Select City')
                );
                townshipSelect.html(defaultTownshipOption);
            });

            citySelect.change(function(){
                let selectedCityId = $(this).val();
                townshipSelect.html(
                    renderUi(townships,(el)=>el.city_id == selectedCityId,'Select Township')
                )
            })

        })
    </script>

    <!-- Plugin -->
    <script>
        $(function () {
            $('.dropify').dropify({
                error : {
                    'fileExtension' : "<?php echo e(__('validation.image_type')); ?>",
                }
            });

            $('.date-input').flatpickr({
                monthSelectorType: 'static'
            });

            var elems = Array.prototype.slice.call(
                document.querySelectorAll('.switchery')
            );

            elems.forEach(function(html) {
                var switchery = new Switchery(html, {
                    size : 'small',
                    color: '#38D8B2'
                });
            });

        });
    </script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dropify/dropify.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/mohithg-switchery/mohithg-switchery.min.css')); ?>">

    <style>
        .input-group .select2-selection.select2-selection--single {
            border-radius: 0;
        }

        .complete-hide {
            display: none;
        }

        .input-group .select2.select2-container.select2-container--default {
            padding: 0;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('teleport'); ?>

<div class="modal fade" id="duplicate-student-code" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
         
        </div>

        <div class="modal-body">
            <label for="existingcode" class="mb-2">
                Replace student code for <span class="text-primary">Myat Kyaw Thu</span> with new student code -
            </label>
            <input 
                type="text" 
                class="form-control mb-4" 
                name="replace_student_code" 
                id="replace-student-code"
                placeholder="New student code" 
            >
            <span id="new-student-code-validation-message"></span>
        </div>

        <div class="modal-footer d-flex justify-content-between">
            <button class="btn btn-sm btn-secondary" id="duplicate-student-form-cancel" data-bs-dismiss="modal">
                cancel
            </button>
            <button class="btn btn-sm btn-primary" id="replace-btn">
                replace
            </button>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/students/create.blade.php ENDPATH**/ ?>