<style>
    .notification-wrapper {
        position: relative;
        display: inline-block;
    }
    
    .notification-dot {
        position: absolute;
        top: -2px;
        right: -3px;
        width: 8px;
        height: 8px;
        background-color: red;
        border-radius: 50%;
        box-shadow: 0 0 2px rgba(0, 0, 0, 0.5);
        z-index: 1;
        display: none; /* Hide by default */
    }
    
    .notification-wrapper.has-notification .notification-dot {
        display: block;
    }
    
</style>

<div>
    <button class="btn btn-sm btn-icon due-date-edit-btn btn-info waves-effect waves-light <?php echo e($status == 'verified' ? 'disabled' : ''); ?> "  data-id="<?php echo e($id); ?>">
        <span class="mdi mdi-alarm" ></span>
    </button>
    <a href="<?php echo e(route('student-transaction.show',$id)); ?>" class="btn btn-sm btn-icon btn-secondary waves-effect waves-light">
        <span class="mdi mdi-receipt-text" data-bs-toggle="tooltip" data-bs-placement="top" title="Show"></span>
    </a>
    <div class="notification-wrapper <?php echo e($status == 'pending' ? 'has-notification' : ''); ?>">
        <button class="btn btn-sm btn-icon btn-warning student-payment-edit-btn <?php echo e($status == 'verified' ? 'disabled' : ''); ?>" data-id="<?php echo e($id); ?>">
            <span class="mdi mdi-currency-usd" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit"></span>
            <span class="notification-dot"></span>
        </button>
    </div>
    <button data-id="<?php echo e($id); ?>"  data-total="<?php echo e($must_sent_amount); ?>" class="btn btn-sm btn-icon btn-primary split-payment-btn <?php echo e($status == 'verified' ? 'disabled' : ''); ?> waves-effect waves-light" image="<?php echo e($content ?  get_file($content) : ''); ?>" data-id="<?php echo e($id); ?>">
        <span class="mdi mdi-cash-sync" data-bs-toggle="tooltip" data-bs-placement="top" title="Split Payment"></span>
    </button>
    <a href="<?php echo e(route('transaction-reports.notify',$id)); ?>" class="btn btn-sm btn-icon btn-danger <?php echo e($status == 'verified' ? 'disabled' : ''); ?> waves-effect waves-light waves-effect waves-light">
        <span class="mdi mdi-bell-alert-outline" data-bs-toggle="tooltip" data-bs-placement="top" title="Notify"></span>
    </a>
    <script src="<?php echo e(asset('assets/js/transaction-reports/split-payment-popup.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/student-payment/transaction-student-edit-popup.js')); ?>"></script>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/student-transactions/action.blade.php ENDPATH**/ ?>