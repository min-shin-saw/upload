<div class="row">
    <div class="col-md-4 mb-4">
        <input
        type="text"
        name="name"
        value="<?php echo e(isset($template)? $template->name : ''); ?>"
        class="form-control"
        placeholder="Certificate Name">
    </div>

    <div class="col-md-4 mb-4">
        <?php if(isset($template)): ?>
            <select @change="typeChange" class="form-select" name="type" x-model="type">
                <?php if(!isset($template)): ?>
                    <option value="">Select Type</option>
                <?php endif; ?>
                <option
                value="landscape"
                <?php if(isset($template) && $template->type === 'landscape'): echo 'selected'; endif; ?>
                >Landscape</option>
                <option
                value="portrait"
                <?php if(isset($template) && $template->type === 'portrait'): echo 'selected'; endif; ?>
                >Portrait</option>
            </select>
        <?php else: ?>
            <select
            class="form-select"
            name="type"
            x-model="type">
                <?php if(!isset($template)): ?>
                    <option value="">Select Type</option>
                <?php endif; ?>
                <option
                value="landscape"
                <?php if(isset($template) && $template->type === 'landscape'): echo 'selected'; endif; ?>
                >Landscape</option>
                <option
                value="portrait"
                <?php if(isset($template) && $template->type === 'portrait'): echo 'selected'; endif; ?>
                >Portrait</option>
            </select>
        <?php endif; ?>
    </div>

    <div class="col-md-4 mb-4">
        <input
        type="file"
        id="background"
        accept="image/*"
        name="background"
        @change="bgChange"
        class="form-control" >
    </div>

    

    <div class="col-12 mb-4">
        <textarea
        name="inner_html"
        id="inner_html"
        ><?php echo e(isset($template)? $template->inner_html : ''); ?></textarea>
    </div>

    <?php if(isset($template)): ?>
        <div x-show="firstLoad">
            <?php if($template->type === 'landscape'): ?>
                <div
                style="width: 842px; height: 595px; background-size:cover; background-position:center; background-image:url(<?php echo e(get_file($template->background)); ?>);"
                class="editorText mx-auto"><?php echo $template->inner_html; ?></div>
            <?php else: ?>
                <div
                style="width: 595px; height: 842px; background-size:cover; background-position:center; background-image:url(<?php echo e(get_file($template->background)); ?>);"
                class="editorText mx-auto"><?php echo $template->inner_html; ?></div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <div
    style="width: 842px; height: 595px; background-size:cover; background-position:center;"
    x-show="type === 'landscape' && !firstLoad"
    class="editorText mx-auto"></div>

    <div
    style="width: 595px; height: 842px; background-size:cover; background-position:center;"
    x-show="type === 'portrait' && !firstLoad"
    class="editorText mx-auto"></div>

</div>

<div class="mt-3 d-flex justify-content-between">
    <a href="<?php echo e(route('certificates.templates.index')); ?>" class="btn btn-outline-secondary">
        <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
        <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('common.back')); ?></span>
    </a>

    <button class="btn btn-primary ms-2" id="submit-btn" type="submit">
        <?php echo e(__('common.submit')); ?>

    </button>
</div>

<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/certificates/form-partials/form.blade.php ENDPATH**/ ?>