<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4">
            <span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?> /
                <?php if( App\Helpers\CustomHelpers::get_permission_group_list(Auth::user()->role->id, "Admin") ): ?>
                <a href="<?php echo e(route('schools.index')); ?>"><?php echo e(__('admin/breadcrumb/school.schools')); ?></a>
                <?php else: ?>
                    <?php echo e(__('admin/breadcrumb/school.schools')); ?>

                <?php endif; ?> /
            </span>
            Detail
        </h4>

        <div class="card mb-4">
            <div class=" d-flex align-items-center justify-content-between">
                <h5 class="card-header">School Detail</h5>
                <div>
                    <?php if(auth()->user()->role->value == 'superadmin'): ?>
                        <a href="<?php echo e(route('schools.dashboard',$school)); ?>" class="btn me-1 btn-icon btn-label-primary btn-fab demo" title="Dashboard">
                            <span class="mdi mdi-view-dashboard-outline"></span>
                        </a>
                    <?php endif; ?>

                    <a href="<?php echo e(route('schools.edit',$school)); ?>" class="btn me-3 btn-icon btn-label-primary btn-fab demo" title="Edit">
                        <span class="mdi mdi-playlist-edit"></span>
                    </a>
                </div>
            </div>
            <div class="card-body">

                <div class="row">
                    <div class="col-xl-4 col-lg-5 col-md-5">
                        <!-- Profile Overview -->
                        <div class="">
                            <img class="card-img-bottom" src="<?php echo e(get_file($school->logo)); ?>" alt="Card image cap">
                        </div>
                        <!--/ Profile Overview -->
                    <!-- About User -->
                    <div class=" mb-4">
                        <div class="">
                        <small class="card-text text-uppercase text-muted"><?php echo e(__('admin/admin-school.about')); ?></small>
                        <ul class="list-unstyled my-3 py-1">
                            <li class="d-flex align-items-center mb-3">
                            <i class="mdi mdi-account-outline mdi-24px"></i><span class="fw-semibold mx-2"><?php echo e(__('admin/admin-school.school_name')); ?>:</span> <span><?php echo e($school->name); ?></span>
                            </li>
                            <li class="d-flex align-items-center mb-3">
                            <i class="mdi mdi-check mdi-24px"></i><span class="fw-semibold mx-2"><?php echo e(__('admin/admin-school.founded_date')); ?>:</span>
                            <span><?php echo e($school->formattedFounedAtDate() ?? '-'); ?></span>
                            </li>
                        </ul>
                        <small class="card-text text-uppercase text-muted"><?php echo e(__('admin/admin-school.contact_title')); ?></small>
                        <ul class="list-unstyled my-3 py-1">
                            <li class="d-flex align-items-center mb-3">
                            <i class="mdi mdi-phone-outline mdi-24px"></i><span class="fw-semibold mx-2"><?php echo e(__('admin/admin-school.contact')); ?>:</span>
                            <span> <?php echo e($school->phone); ?></span>
                            </li>
                            <li class="d-flex align-items-center mb-3">
                            <i class="mdi mdi-web-check mdi-24px"></i><span class="fw-semibold mx-2"><?php echo e(__('admin/admin-school.web')); ?>:</span>
                            <span> <a href="<?php echo e($school->web_address); ?>">
                            <b>Go To School Url</b>
                            </a></span>
                            </li>
                            <li class="d-flex align-items-center mb-3">
                            <i class="mdi mdi-email-outline mdi-24px"></i><span class="fw-semibold mx-2"><?php echo e(__('common.email')); ?>:</span>
                            <span> <?php echo e($school->email); ?></span>
                            </li>
                        </ul>
                        </div>
                    </div>
                    <!--/ About User -->
                    </div>
                    <div class="col-xl-8 col-lg-7 col-md-7">
                    <!-- Activity Timeline -->
                    <div class="card card-action mb-4">
                        <div class="card-header align-items-center">
                        <h5 class="card-action-title mb-0">
                            <i class="mdi mdi-map-check-outline mdi-24px me-2"></i><?php echo e(__('admin/admin-school.location')); ?>

                        </h5>
                        </div>
                        <div class="card-body pt-3 pb-0">
                            <?php echo $school->map_code; ?>

                        </div>

                        <div class="card">
                            <div class="card-body">
                                <p class="card-text">
                                    <?php echo e($school->description); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/schools/show.blade.php ENDPATH**/ ?>