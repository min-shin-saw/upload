<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4">
            <span class="text-muted fw-light">
                <?php echo e(__('common-breadcrumb.dashboard')); ?> /
                <a href="<?php echo e(route('teachers.index')); ?>">
                    <?php echo e(__('admin/breadcrumb/teacher.teachers')); ?>

                </a> /

                <a href="<?php echo e(route('teachers.courses-subjects', $teacher->id)); ?>">
                    Teacher Assign
                </a> /
            </span>

            <?php echo e(__('admin/breadcrumb/timetable.timetable')); ?>

        </h4>

        <div class="mb-3 row px-3">
            <div style="" class="card shadow-sm rounded-0">
                <div class="card-body">
                    <div class="mb-3">
                        <h5 class="text-primary mb-4">Date Range</h5>
                        <div class="d-md-flex gap-2  align-items-center ">
                            <div class="form-floating form-floating-outline col-md-4 col-12">
                                <input type="date" name="start_date" value="<?php echo e(date('Y-m-01')); ?>" id="start-date" class="form-control" />
                                <label for="start-date" class="form-label">
                                    Start Date
                                </label>
                            </div>

                            <span class="d-none d-md-inline">-</span>

                            <div class="form-floating mt-4 mt-md-0 form-floating-outline col-md-4 col-12">
                                <input type="date" name="end_date" id="end-date" value=<?php echo e(date('Y-m-t')); ?> class="form-control" />
                                <label for="end-date" class="form-label">
                                    End Date
                                </label>
                            </div>

                            <div class="mt-2">
                                <button id="filter-btn" class="btn btn-sm btn-primary" title="filter" >
                                    <span class="mdi mdi-filter-variant"></span>
                                </button>
                            </div>
                        </div>
                    </div>

                    <div id="container">

                    </div>

                    <div id="spinner" class="p-2">
                        <div class="spinner-border text-secondary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="accordion accordion-flush" id="accordionFlushExample">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $format): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                            data-bs-target="#flush-collapse-<?php echo e($index + 1); ?>" aria-expanded="false"
                            aria-controls="flush-collapse-<?php echo e($index + 1); ?>">
                            <?php echo e($format['name']); ?>

                        </button>
                    </h2>

                    <div id="flush-collapse-<?php echo e($index + 1); ?>"
                        class="accordion-collapse collapse <?php echo e($format['active'] ? 'show' : ''); ?>"
                        data-bs-parent="#accordionFlushExample">
                        <div class="accordion-body">
                            <div style="padding: 5px 0" class="d-flex border-bottom w-100">
                                <div style="min-width:50px"></div>

                                <div class="d-flex w-100">
                                    <?php $__currentLoopData = $format['times']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="d-flex align-items-center flex-column gap-2"
                                            style="
                                            border-right: 1px solid gray;
                                            min-width:<?php echo e($time['width']); ?>%
                                        ">
                                            <small>
                                                <?php echo e($time['start']); ?> ~
                                            </small>
                                            <small>
                                                <?php echo e($time['end']); ?>

                                            </small>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                            <?php $__currentLoopData = $format['days']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div style="padding: 10px 0" class="d-flex border-bottom w-100">
                                    <div style="min-width:50px" class="py-1">
                                        <?php echo e($day['name']); ?>

                                    </div>
                                    <div style="position: relative; width: 100%;">
                                        <?php $__currentLoopData = $day['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="d-flex align-items-center justify-content-center"
                                                style="overflow: hidden;
                                                position: absolute;
                                                left: <?php echo e($each['left']); ?>%;
                                                width: <?php echo e($each['width']); ?>%;
                                                height: 100%;
                                                border: <?php echo e($each['color']?'':'1px solid gray'); ?>;
                                                color: <?php echo e($each['color']?'white':'black'); ?>;
                                                background: <?php echo e($each['color']); ?>;">
                                                <?php echo e($each['short_name'] ?? $each['name']); ?>

                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php $__currentLoopData = $day['customs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $custom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="d-flex align-items-center justify-content-center"
                                                style="overflow: hidden;
                                                position: absolute;
                                                left: <?php echo e($custom['left']); ?>%;
                                                width: <?php echo e($custom['width']); ?>%;
                                                height: 100%;
                                                color: white;
                                                background: <?php echo e($custom['color']); ?>;">
                                                <?php echo e($custom['name']); ?>

                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="pb-3 px-3">
            <?php echo $noticeBoard; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(function () {
            const url    = "<?php echo e(route('teacher.status',['teacher'=>$teacher,'batch'=>$batch])); ?>"

            const filter = () => {

                const data = {
                    start_date: $('#start-date').val(),
                    end_date  : $('#end-date').val()
                }

                $.ajax({
                    type: "GET",
                    url: url,
                    data,
                    success: function (response) {
                        $('#container').html(response);
                        $('#spinner').addClass('complete-hide');
                    }
                });
            }

            filter();

            $('#filter-btn').click((e) => {
                $('#spinner').removeClass('complete-hide');
                $('#container').html('');
                filter();
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/teachers/timetable.blade.php ENDPATH**/ ?>