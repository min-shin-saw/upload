<div>
    <a title="Homeworks" href="<?php echo e(route('tasks.list.index',['course'=>$id])); ?>" class="btn btn-sm btn-icon btn-primary waves-effect waves-light">
        <span class="mdi mdi-clipboard-text"></span>
    </a>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/task/action.blade.php ENDPATH**/ ?>