<?php $__env->startSection('container'); ?>

    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__("common-breadcrumb.dashboard")); ?> / <a
                    href="<?php echo e(route('guardians.index')); ?>"><?php echo e(__('admin/breadcrumb/guardian.guardians')); ?></a> / </span><?php echo e(__('common-breadcrumb.create')); ?></h4>
        <h5 class="card-header"><?php echo e(__('admin/admin-guardian.guardian_create')); ?></h5>
        <div class="card mt-3">
            <div class="card-body">
                <form action="<?php echo e(route('guardians.store')); ?>" method="post" enctype="multipart/form-data" id='guardian-form'>
                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('admin.guardians.form-partial.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

    <script src="<?php echo e(asset('assets/dropify/dropify.min.js')); ?>"></script>

    <script>
        $(function () {
            $('.dropify').dropify({
                error : {
                    'fileExtension' : "<?php echo e(__('validation.image_type')); ?>",
                }

            });

            const takeLoginAccountSwitch = $('#take-login-account-switch');
            const email = $('#email');
            const userName = $('#user-name');
    
            let guardianUserFormModule = createUserDataFormModule({
                switchId: 'take-login-account-switch',
                formId: 'user-from',
                userNameId: 'user-name',
                passwordId: 'password',
                confirmPasswordId: 'confirm-password',
                forcePasswordResetId: 'firsttime_login',
                emailId: 'email',
                modelId : 'guardian-data'
            });


            guardianUserFormModule.init();
        
            function validateForm(){
                const keys = [
                    'image',
                    'user_name',
                    'guardian_name',
                    'gender',
                    'email',
                    'phone',
                    'password',
                    'confirm_password',
                    'nrc_id',
                    'nrc_type',
                    'nrc',
                ];

                const rules = {
                    image : 'nullable',
                    user_name : "nullable|string|max:255",
                    guardian_name : 'required|string|max:255',
                    gender : "required",
                    email : "nullable|email|unique:users,email,NULL,id,deleted_at,NULL|unique:guardians,email,NULL,id,deleted_at,NULL",
                    phone : "nullable|unique:guardians,phone,NULL,id,deleted_at,NULL|max:11|min:11",
                    password : "required|min:8",
                    confirm_password : "required|same:password",
                    nrc_id : 'nullable',
                    nrc_type : 'nullable',
                    nrc : "nullable|max:6|min:6",
                };

                validateNew({
                            keys   : keys,
                            rules  : rules,
                            select2: true,
                            fileValidate: false
                }).then(() => {
                    if (!$('#submit-btn').hasClass("d-none")) $('#submit-btn').addClass('d-none');
                    if ($('#load-btn').hasClass('d-none')) $('#load-btn').removeClass('d-none');
                    $('#guardian-form').submit();
                });
            }


            $('#submit-btn').on('click',function(event){
                event.preventDefault();
            
                if(!takeLoginAccountSwitch.is(':checked')) {
                    guardianUserFormModule.setDefaultValueToUserDataForm();
                    validateForm()
                }else {
                    if(email.val() == '' && userName.val() == ''){
                        Swal.fire({
                            title: "Notice !",
                            text: 'Email Or Username is required !',
                            icon: 'info',
                            showCancelButton: true,
                            confirmButtonText:"Ok",
                            customClass: {
                                confirmButton: 'btn btn-success me-3 waves-effect waves-light',
                                cancelButton: 'btn btn-label-secondary waves-effect'
                            },
                            buttonsStyling: false
                        })
                    }else {
                        validateForm()
                    }   
                }
            })

        })
    </script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dropify/dropify.min.css')); ?>">
    <style>
        .input-group .select2-selection.select2-selection--single {
            border-radius: 0;
        }

        .input-group .select2.select2-container.select2-container--default {
            padding: 0;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/guardians/create.blade.php ENDPATH**/ ?>