<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <?php echo $__env->yieldContent('breadcrumbs'); ?>
        <div class="row">
            <div class="col-md-9" >
                <div class="card">
                  <div class="card-body px-5" id="content">
                    <div class="row mb-3">
                        <div class="d-flex align-items-center mb-3">
                            <img width="40%" src="<?php echo e(get_file($course->image)); ?>" alt="<?php echo e($course->name); ?>">
                            <div style="width: 60%" class=" text-end">
                                <h4><?php echo e($course->name); ?> (<?php echo e($batch->name); ?>)</h4>
                            </div>
                        </div>
                        
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <h5><?php echo e(__('admin/admin-invoice.transaction_code')); ?></h5>
                        <h5><?php echo e(// $payment->payment_code.
                            $studentTransaction->payment_transaction_code); ?></h5>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <h6><?php echo e(__('admin/admin-invoice.learner_name')); ?></h6>
                        <h6><?php echo e($student->name); ?></h6>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <h6><?php echo e(__('admin/admin-invoice.transaction_name')); ?></h6>
                        <h6><?php echo e($studentTransaction->transactionname->name); ?></h6>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <h6><?php echo e(__('admin/admin-invoice.transaction_type')); ?></h6>
                        <h6><?php echo e($studentTransaction->payment_type); ?></h6>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <h6><?php echo e(__('admin/admin-invoice.price')); ?></h6>
                        <h6><?php echo e($studentTransaction->formattedMustSentAmount()); ?> mmk  </h6>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <h6><?php echo e(__('admin/admin-invoice.status')); ?></h6>
                        <h6><?php echo get_transaction_status($studentTransaction->status); ?></h6>
                    </div>
                  </div>
                </div>
            </div>

            <div class="col-md-3" id="btn-section">
                <div class="card">
                    <div class="card-body ">
                        <button style="width: 100%" onclick="window.print()" class="btn btn-outline-secondary">
                            <?php echo e(__('admin/admin-invoice.print')); ?>

                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        @media print {
            .container-p-y, .layout-page, body {
                padding: 0 !important;
            }
            footer, nav, #btn-section, .h4 {
                display: none !important;
            }

            .badge.bg-success {
                color: green
            }
            .badge.bg-primary {
                color: blue
            }
            .badge.bg-danger {
                color: red
            }
            .badge.bg-secondary {
                color: #000
            }

            .card {
                box-shadow: none !important
            }

            @page {
                size: auto;
                margin: 0;
                padding: 0;
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/invoice/additional-fee.blade.php ENDPATH**/ ?>