<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?> / <a
                    href="<?php echo e(route('guardians.index')); ?>"><?php echo e(__('admin/breadcrumb/guardian.guardians')); ?></a> / </span><?php echo e(__('common-breadcrumb.detail')); ?></h4>
        <h5 class="card-header mb-3 text-primary"><?php echo e(__('admin/admin-guardian.guardian_detail')); ?></h5>
        <div class=" border-1 border-md-0">
            <div class="row">
                <div class="card col-md-8 mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-xl-4 col-lg-5 col-md-5 border-1 border-md-0">
                                <div class="user-avatar-section">
                                    <div class="d-flex align-items-center flex-column">
                                        <?php if($guardian?->image): ?>
                                            <img class="img-fluid rounded mb-3 mt-4"
                                            src="<?php echo e(get_file($guardian?->image)); ?>"
                                            height="120" alt="User avatar" />
                                        <?php else: ?>
                                            <?php echo getFillerImage(120,120); ?>

                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-8 col-lg-7 col-md-7 border-0 border-md-1">
                                <li class="mb-3">
                                    <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-guardian.name_detail')); ?>:</span>
                                    <span><?php echo e($guardian?->name); ?></span>
                                </li>
                                <li class="mb-3">
                                    <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-guardian.email_detail')); ?>:</span>
                                    <span><?php echo e(!isGeneratedString($guardian->email , 'user') ? $guardian->email : '-'); ?></span>
                                </li>
                                <li class="mb-3">
                                    <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-guardian.phone_detail')); ?>:</span>
                                    <span><?php echo e($guardian?->phone); ?></span>
                                </li>
                                <li class="mb-3">
                                    <span class="fw-semibold text-heading me-2"><?php echo e(__('common.gender')); ?>:</span>
                                    <span><?php echo e($guardian?->gender); ?></span>
                                </li>
                                <li class="mb-3">
                                    <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-guardian.nrc_detail')); ?>:</span>
                                    <span><?php echo e($guardian?->NrcInfo?->nrc_code .
                                        '/' .
                                        $guardian?->nrcInfo?->name_en .
                                        App\Models\School\Nrc::TYPES[$guardian?->nrc_type] .
                                        $guardian?->nrc); ?></span>
                                </li>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php if($guardian->hasStudents->isNotEmpty()): ?>
                <div class="row">
                    <?php $__currentLoopData = $guardian->hasStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="col-xl-4 col-lg-5 col-md-5 border-1 border-md-0 text-secondary"
                            href="<?php echo e(route('students.show', $student->id)); ?>">
                            <!-- User Card -->
                            <div class="card mb-4">
                                <div class="card-body">
                                    <div class="user-avatar-section">
                                        <div class="d-flex align-items-center flex-column">
                                            <?php if($student->image): ?>
                                                <img class="img-fluid rounded mb-3 mt-4"
                                                src="<?php echo e(get_file($student->image)); ?>" height="120"
                                                width="120" alt="User avatar" />
                                            <?php else: ?>
                                                <?php echo getFillerImage(120,120); ?>

                                            <?php endif; ?>
                            
                                            <div class="user-info text-center">
                                                <h4 class="text-primary"><?php echo e($student->name); ?></h4>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="info-container">
                                        <ul class="list-unstyled mb-4">
                                            <li class="mb-3">
                                                <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-guardian.student_code')); ?>:</span>
                                                <span><?php echo e($student->student_code); ?></span>
                                            </li>
                                            <li class="mb-3">
                                                <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-guardian.email_detail')); ?>:</span>
                                                <span><?php echo e(!isGeneratedString($student->email , 'user') ? $student->email : '-'); ?></span>
                                            </li>
                                            <li class="mb-3">
                                                <span class="fw-semibold text-heading me-2"><?php echo e(__('admin/admin-guardian.phone_detail')); ?>:</span>
                                                <span class=""><?php echo e($student->phone); ?></span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <!-- /User Card -->
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/guardians/show.blade.php ENDPATH**/ ?>