<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__("common-breadcrumb.dashboard")); ?> / <a
                    href="<?php echo e(route('guardians.index')); ?>"><?php echo e(__('admin/breadcrumb/guardian.guardians')); ?></a> / </span><?php echo e(__('common-breadcrumb.edit')); ?></h4>
        <h5 class="card-header"><?php echo e(__('admin/admin-guardian.guardian_edit')); ?></h5>
        <div class="card mt-3">
            <div class="card-body">
                <input  value="<?php echo e($guardian); ?>" hidden id="guardian-data" />
                <form action="<?php echo e(route('guardians.update',$guardian)); ?>" method="POST" enctype="multipart/form-data" id='guardian-form'>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <?php echo $__env->make('admin.guardians.form-partial.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/dropify/dropify.min.js')); ?>"></script>

    <script>
        $(function () {
            $('.dropify').dropify();
                const takeLoginAccountSwitch = $('#take-login-account-switch');
                const userName  = $('#user-name');
                const email = $('#email');
                let guardianData = JSON.parse($('#guardian-data').val());

                let guardianUserFormModule = createUserDataFormModule({
                    switchId: 'take-login-account-switch',
                    formId: 'user-from',
                    userNameId: 'user-name',
                    passwordId: 'password',
                    confirmPasswordId: 'confirm-password',
                    forcePasswordResetId: 'firsttime_login',
                    emailId: 'email',
                    modelId : 'guardian-data'
                });

                guardianUserFormModule.init()
                

                function validateForm(){
                    const keys = [
                        'image',
                        'user_name',
                        'guardian_name',
                        'gender',
                        'email',
                        'phone',
                        'password',
                        'confirm_password',
                        'nrc_id',
                        'nrc_type',
                        'nrc',
                    ];

                    
                    const rules = {
                        image: 'nullable',
                        user_name : "nullable|string|max:255",
                        guardian_name : 'required|string|max:255',
                        gender : "required",
                        email : [
                            "required",
                            `unique:guardians,email,${guardianData.id},id,deleted_at,NULL`,
                            `unique:users,email,${guardianData.user_id},id,deleted_at,NULL`,
                            "email"
                        ],
                        phone : [
                            "nullable",
                            `unique:guardians,phone,${guardianData.id},id,deleted_at,NULL`,
                            "min:11",
                            "max:11",
                        ],
                        password : [
                            "nullable"
                        ],
                        confirm_password : "nullable|same:password",
                        nrc_id : 'nullable',
                        nrc_type : 'nullable',
                        nrc : [
                            'nullable',
                            "max:6",
                            "min:6",
                        ],
                    };

                    validateNew({
                                keys   : keys,
                                rules  : rules,
                                select2: true,
                                fileValidate: false
                    }).then(() => {
                        $('#guardian-form').submit();
                    });

                }


                $('#submit-btn').on('click',function(event){
                    event.preventDefault();
                
                    if(!takeLoginAccountSwitch.is(':checked')) {
                        guardianUserFormModule.setDefaultValueToUserDataForm();
                        validateForm()
                    }else {
                        if(email.val() == '' && userName.val() == ''){
                            Swal.fire({
                                title: "Notice !",
                                text: 'Email Or Username is required !',
                                icon: 'info',
                                showCancelButton: true,
                                confirmButtonText:"Ok",
                                customClass: {
                                    confirmButton: 'btn btn-success me-3 waves-effect waves-light',
                                    cancelButton: 'btn btn-label-secondary waves-effect'
                                },
                                buttonsStyling: false
                            })
                        }else {
                            validateForm()
                        }   
                    }
                })
        })
    </script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dropify/dropify.min.css')); ?>">
    <style>
        .input-group .select2-selection.select2-selection--single {
            border-radius: 0;
        }

        .input-group .select2.select2-container.select2-container--default {
            padding: 0;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/guardians/edit.blade.php ENDPATH**/ ?>