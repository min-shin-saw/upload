<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <?php echo $__env->yieldContent('breadcrumbs'); ?>
        <div class="row">
            <div class="col-md-9" >
                <div class="card">
                  <div class="card-body px-5" id="content">
                    <div class="row mb-3">
                        <div class="d-flex align-items-center mb-3">
                            <img width="40%" src="<?php echo e(get_file($course->image)); ?>" alt="<?php echo e($course->name); ?>">
                            <div style="width: 60%" class=" text-end">
                                <h4><?php echo e($course->name); ?> (<?php echo e($batch->name); ?>)</h4>
                            </div>
                        </div>
                        
                    </div>
                    <div style="
                        border-bottom-style: dotted;
                    " class=" mb-3">
                    <div class="d-flex justify-content-between mb-2">
                        <h5><?php echo e(__('admin/admin-invoice.transaction_code')); ?></h5>
                        <h5><?php echo e(// $payment->payment_code.
                            $studentTransaction->payment_transaction_code); ?></h5>
                    </div>
                        <div class="d-flex justify-content-between mb-2">
                            <h6><?php echo e(__('admin/admin-invoice.learner_name')); ?></h6>
                            <h6><?php echo e($student->name); ?></h6>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <h6><?php echo e(__('admin/admin-invoice.course_price')); ?></h6>
                            <h6><?php echo e($payment->formattedTotalAmount()); ?> mmk</h6>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <h6><?php echo e(__('admin/admin-invoice.discount')); ?></h6>
                            <h6><?php if($payment->discount): ?>
                                <?php echo e($payment->discount); ?> %
                            <?php else: ?>
                                <?php echo e($payment->formattedTotalDiscountAmount()); ?>

                            <?php endif; ?></h6>
                        </div>

                        <div class="d-flex justify-content-between mb-2">
                            <h6><?php echo e(__('admin/admin-invoice.total_price')); ?></h6>
                            <h6><?php echo e($payment->formattedTotalNetAmount()); ?></h6>
                        </div>
                    </div>

                    <div style="
                        border-bottom-style: dotted;
                    " class=" mb-3">
                        <div class="d-flex justify-content-between mb-2">
                            <h6><?php echo e(__('admin/admin-invoice.payment_code')); ?></h6>
                            <h6><?php echo e($payment->payment_code); ?></h6>
                        </div>

                        <div class="d-flex justify-content-between mb-2">
                            <h6><?php echo e(__('admin/admin-invoice.payment_method')); ?></h6>
                            <h6><?php echo e($studentTransaction->payment_type); ?></h6>
                        </div>


                        <div class="d-flex justify-content-between mb-2">
                            <h6><?php echo e(__('admin/admin-invoice.payment_terms')); ?></h6>
                            <h6 class="text-end"><?php echo e($payment->payment_time); ?> time <br><?php echo e($payment->payment_option); ?></h6>
                        </div>
                    </div>

                    <div>
                        <div class="d-flex justify-content-between mb-2">
                            <h6><?php echo e(__('admin/admin-invoice.paid_time')); ?></h6>
                            <h6><?php echo e($paidTransactions->count()); ?> time</h6>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <h6><?php echo e(__('admin/admin-invoice.payable_amount')); ?></h6>
                            <h6><?php echo e($studentTransaction->formattedMustSentAmount()); ?> mmk </h6>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <h6><?php echo e(__('admin/admin-invoice.status')); ?></h6>
                            <h6><?php echo get_transaction_status($studentTransaction->status); ?></h6>
                        </div>

                    </div>

                  </div>
                </div>
            </div>

            <div class="col-md-3" id="btn-section">
                <div class="card">
                    <div class="card-body d-flex flex-column">
                        <button style="width: 100%" onclick="window.print()" class="btn btn-outline-secondary">
                            <?php echo e(__('admin/admin-invoice.print')); ?>

                        </button>
                        
                        <?php if($studentTransaction->content): ?>
                        <input type="hidden" id="student-payment-id" value="<?php echo e($studentTransaction); ?>">
                        <a href="<?php echo e(get_file($studentTransaction->content)); ?>" target="_blank" alt="invoice image" class="mt-3 mx-auto">
                            <img src="<?php echo e(get_file($studentTransaction->content)); ?>" id="student-payment-approval-img" alt="" style="width: 100%" class="mt-3 mb-3">
                        </a>
                        
                        <div class="d-flex justify-content-center" style="width: 100%">
                            <button class="btn btn-primary student-payment-edit-btn mx-auto" data-id="<?php echo e($studentTransaction->id); ?>">    
                                Edit
                                <!-- <span data-bs-toggle="tooltip" data-bs-placement="top" title="Edit">Edit</span> -->
                            </button>
                        </div>

                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" >
                            <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('admin/payment/admin-payment.payment_approval')); ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <div id="student-invoice-img" style="display:none">
                                        <img style="width: 100%" class="mb-2" id="student-payment-approval-img" alt="invoice-img">
                                    </div>
                                    <form action="<?php echo e(route('student-transaction.update', $id )); ?>" method="post" id="payment-approve-form" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <div class="container" id="group-transaction-container">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="">
                                                    <h5 class="cursor-pointer" onclick="showSelectInput()">Select</h5>
                                                </div>
                                                <div>
                                                    <h5 class="cursor-pointer" onclick="showUploadInput()">Upload</h5>
                                                </div>
                                            </div>

                                            <!-- Select Input (Shown by Default) -->
                                            <div id="selectInput" class="" >
                                                <img src="https://www.google.com/url?sa=i&url=https%3A%2F%2Fen.wikipedia.org%2Fwiki%2FGoogle_Images&psig=AOvVaw315FhqlXqcllCB46bOjWxv&ust=1738048944363000&source=images&cd=vfe&opi=89978449&ved=0CBQQjRxqFwoTCJia1IGvlYsDFQAAAAAdAAAAABAE" 
                                                id="transaction-image" alt="" class="text-center" style="width: 100%">
                                                <select name="transactionCode" id="group-transaction" class="form-control group-transactions-select2 mt-3" >
                                                    <?php $__currentLoopData = $verifiedTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $verifiedTransaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($verifiedTransaction->transaction_code); ?>" data-img="<?php echo e($verifiedTransaction->content); ?>">
                                                        <?php echo e($verifiedTransaction->transaction_code); ?>-<?php echo e($verifiedTransaction->transactionName->name ?? 'N/A'); ?>

                                                    </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>

                                            <!-- Upload Input (Hidden by Default) -->
                                            <div id="uploadInput" class="mt-3" style="display: none;">
                                                <input type="file" name="content" id="content" class="form-control" accept="image/*" =>
                                            </div>

                                        </div>
                                        <div class="modal-footer col-12 d-flex justify-content-center">
                                            <input type="hidden" name="is_approved" value="0">
                                            <button type="button" class="btn btn-success approve-btn">Submit</button>
                                        </div>
                                    </form>
                            </div>
                            </div>
                        </div>
                        
                        <?php endif; ?>


                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        @media print {
            .container-p-y, .layout-page, body {
                padding: 0 !important;
            }
            footer, nav, #btn-section, .h4 {
                display: none !important;
            }

            .badge.bg-success {
                color: green
            }
            .badge.bg-primary {
                color: blue
            }
            .badge.bg-danger {
                color: red
            }
            .badge.bg-secondary {
                color: #000
            }

            .card {
                box-shadow: none !important
            }

            @page {
                size: auto;
                margin: 0;
                padding: 0;
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(() => {
        $('.student-payment-edit-btn').click(function(e) {
            e.preventDefault();
            let id = $(this).data('id');
            // Get the data-id attribute value
            const dataId = $(this).data('id');
            // Log the data-id value to the console
            console.log("Data ID:", dataId);
            // let obj = getObjectById(id);
            // if (obj.status !== 'verified') {
                $('#exampleModal').modal('show');
            //     
        });

        $('.approve-btn').click(function (e) {
            e.preventDefault();
            $('[name="is_approved"]').val(1);
            $('#payment-approve-form').submit();
        });
    });
</script> 

<script>

    function showUploadInput() {
        document.getElementById('uploadInput').style.display = 'block';
        document.getElementById('selectInput').style.display = 'none';
        document.getElementById('group-transaction').disabled = true;
        document.getElementById('content').disabled = false;
    }

    function showSelectInput() {
        document.getElementById('selectInput').style.display = 'block';
        document.getElementById('uploadInput').style.display = 'none';
        document.getElementById('group-transaction').disabled = false;
        document.getElementById('content').disabled = true;
    }

    document.getElementById('group-transaction').addEventListener('change', function() {
        // Get the selected option
        const selectedOption = this.options[this.selectedIndex];

        // Get the image URL from the "data-image" attribute
        const imgContent = selectedOption.getAttribute('data-img');
        console.log(imgContent + ":in front is img content");

        // Update the image src
        document.getElementById('transaction-image').src = imgContent;
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/invoice/form.blade.php ENDPATH**/ ?>