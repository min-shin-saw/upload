
<!DOCTYPE html>

<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="light-style layout-navbar-fixed layout-menu-fixed"
    dir="ltr" data-theme="theme-default" data-assets-path="<?php echo e(asset('assets/')); ?>"
    data-template="vertical-menu-template">

<head>
    <?php echo $__env->make('layout.shared.meta-script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layout.shared.head-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        #login-container {
            height: 100%;
        }
        @media (max-width:570px) {
            #login-container {
            height: 50% !important;
        }
        }
    </style>
</head>

<body>
    <div
    style="height: 100vh"
    class="overflow-hidden"
    >
        <div class="row" id="login-container">
            <div
            style="background: linear-gradient(180deg, #3254BB 0%, #50BCBF 100%);"

            class="col-sm-6 h-100 d-flex align-items-center justify-content-center">
                <img class="w-75" src="<?php echo e(asset(config('settings.admin-auth-logo'))); ?>" alt="EDU Plus">
            </div>

            <div
            class="col-sm-6 h-100 d-flex align-items-center justify-content-center">
            <form method="POST" action="<?php echo e(route('login')); ?>" class="w-px-500 rounded p-3 p-md-5">
                <?php echo csrf_field(); ?>
                <h3 class="mb-4">LOGIN</h3>

                <div class="form-floating form-floating-outline mb-4">
                    <input type="text" id="form-alignment-username"
                        class="form-control <?php echo e($errors->has('email') ? 'error' : ''); ?>" placeholder="example@gmail.com"
                        name="email" value="<?php echo e(old('email')); ?>" />
                    <?php if($errors->has('email')): ?>
                        <small class="text-danger mt-2">
                            <?php echo e($errors->first('email')); ?>

                        </small>
                    <?php endif; ?>
                    <label for="form-alignment-username">Email</label>
                </div>


                <div class="mb-4 form-password-toggle fv-plugins-icon-container">
                    <div class="input-group input-group-merge">
                        <div class="form-floating form-floating-outline position-relative">
                            <i class="mdi mdi-eye-off-outline position-absolute"
                                style="
                            cursor: pointer;
                            right:4%;
                            top: 15px;
                            "></i>
                            <input name="password" class="form-control <?php echo e($errors->has('password') ? 'error' : ''); ?>"
                                type="password" id="password" placeholder="············">
                            <?php if($errors->has('password')): ?>
                                <small class="text-danger mt-2 ">
                                    <?php echo e($errors->first('password')); ?>

                                </small>
                            <?php endif; ?>
                            <label for="currentPassword">Password</label>
                        </div>
                    </div>
                </div>


                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary">Login</button>
                </div>
            </form>
            </div>
        </div>
    </div>

    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
</body>

</html>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/auth/login.blade.php ENDPATH**/ ?>