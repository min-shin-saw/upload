<!DOCTYPE html>

<?php ($studentCode = App\Models\Setting\StudentSetting::where([
    'school_id' => auth()->user()->school_id,
    'key' => 'student_code_prefix',
])->first()); ?>

<html
  lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>"
  class="light-style layout-navbar-fixed layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="<?php echo e(asset('assets/')); ?>"
  data-template="vertical-menu-template" >
  <head>
    <?php echo $__env->make('layout.shared.meta-script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <?php echo $__env->make('layout.shared.head-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(asset('assets/js/plugin/pusher.min.js')); ?>"></script>
    <?php echo $__env->yieldContent('header-script'); ?>
    <style>
        .modal-mask-app {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.6);
            display: grid;
            place-items: center;
            height: 100vh;
        }

        .modal-container-app {
            background: #fff;
            width: 450px !important;
            padding: 20px;
            border-radius: 7px;
        }
    </style>
  </head>

  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->
        <?php echo $__env->make('layout.shared.aside-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- / Menu -->
        
        <?php echo $__env->make('langHelper.Swal-delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->
          <?php echo $__env->make('layout.shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <!-- / Navbar -->

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->
            <div class="container-xxl flex-grow-1 container-p-y">
                <div class="row gy-4">
                    <?php echo $__env->yieldContent('container'); ?>
                </div>
            </div>
            <!-- / Content -->

            <!-- Footer -->
                <?php echo $__env->make('layout.shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>

      <!-- Drag Target Area To SlideIn Menu On Small Screens -->
      <div class="drag-target"></div>
    </div>
    <!-- / Layout wrapper -->

    <?php echo $__env->make('layout.shared.footer-script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if(auth()->user() && auth()->user()->school_id != 0): ?>
      <script>
        Pusher.logToConsole = false;

        var notiBtn = document.getElementById("getNotificationsButton");
        var markReadBtn = document.getElementById("markAllAsRead");

        var pusher = new Pusher('<?php echo e(env('PUSHER_APP_KEY')); ?>', {
          cluster: '<?php echo e(env('PUSHER_APP_CLUSTER')); ?>',
        });

        var channel = pusher.subscribe('message-to-school-<?php echo e(auth()->user()->school_id); ?>-admin-<?php echo e(auth()->user()->id); ?>');
        channel.bind('on-notify-admin-<?php echo e(auth()->user()->id); ?>-school-<?php echo e(auth()->user()->school_id); ?>', function(data) {
          noficast(data.title, data.message);
        });

        window.onload = (e) => {
          askNotificationPermission();
          getNoti();
          fetchOfflineNotiFx();
        }

        notiBtn.addEventListener('click', (e) => {
          getNoti();
        });

        markReadBtn.addEventListener('click', (e) => {
          markAllAsReadFx();
        });

        function askNotificationPermission() {
          // Function to actually ask the permissions
          function handlePermission(permission) {
            // Whatever the user answers, we make sure Chrome stores the information
            if (!Reflect.has(Notification, 'permission')) {
              Notification.permission = permission;
            }
          };
          // Check if the browser supports notifications
          if (!Reflect.has(window, 'Notification')) {
            console.log('This browser does not support notifications.');
          } else {
            if (checkNotificationPromise()) {
              Notification.requestPermission().then(handlePermission);
            } else {
              Notification.requestPermission(handlePermission);
            }
          }
        };

        function checkNotificationPromise() {
          try {
            Notification.requestPermission().then();
          } catch(e) {
            return false;
          }
          return true;
        };

        function noficast(title, message) {
          if (window.Notification) {
            if (Notification.permission === 'granted') {
              // show notification here
              var notify = new Notification( title , {
                  body: message,
                  icon: '<?php echo e(asset('assets/img/logo-noti.png')); ?>',
              });
              getNoti();
            }
            else {
              askNotificationPermission();
            }
          }
        }

        async function getNoti () {
          try {
            const response = await fetch('<?php echo e(route('notifications.index')); ?>', {
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                }
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

              const res = await response.json();
              bindNoti(res.data.notifications, res.data.unread_count);
          } catch (error) {
              console.error('Error fetching notifications:', error);
          }
        }

        async function markAllAsReadFx () {
          try {
            const response = await fetch('<?php echo e(route('notifications.mark-all-as-read')); ?>', {
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                }
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            } else {
              getNoti();
            }

          } catch (error) {
              console.error('Error fetching notifications:', error);
          }
        }

        async function fetchOfflineNotiFx() {
          try {
            const response = await fetch('<?php echo e(route('notifications.fetch-offline-notifications')); ?>', {
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                }
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
          } catch(error) {
              console.error('Error fetching offline notifications:', error);
          }
        }

        function bindNoti(notifications, unreadCountNo) {
          var notificationList = document.getElementById('notificationList');
          var unreadCount = document.getElementById('unreadCountEl');
          var newNotiMsg = document.getElementById('newNotiEl');

          if (notificationList) {

            notificationList.innerHTML = '';

            unreadCount.innerHTML = '';
            unreadCount.innerHTML = `${unreadCountNo} New`;

            if (unreadCountNo > 0) {

              if(!newNotiMsg.classList.contains('badge')) {
                newNotiMsg.classList.add('badge');
                newNotiMsg.classList.add('badge-dot');
                newNotiMsg.classList.add('bg-danger');
                newNotiMsg.classList.add('mt-2');
                newNotiMsg.classList.add('border');
              }
            }
            else
            {
              if(newNotiMsg.classList.contains('badge')) {
                newNotiMsg.classList.remove('badge');
                newNotiMsg.classList.remove('badge-dot');
                newNotiMsg.classList.remove('bg-danger');
                newNotiMsg.classList.remove('mt-2');
                newNotiMsg.classList.remove('border');
              }
            }

            notifications.forEach(notification => {
              // Create a new list item with the specified classes
              var newNotificationItem = document.createElement("li");
              newNotificationItem.classList.add("list-group-item", "list-group-item-action", "dropdown-notifications-item");

              // Create the inner structure of the new list item
              newNotificationItem.innerHTML = `
                <div class="d-flex gap-2">
                  <div class="flex-shrink-0">
                    <div class="avatar me-1">
                      <img src="<?php echo e(get_file(auth()->user()->school->logo)); ?>" alt class="w-px-40 h-auto rounded-circle" />
                    </div>
                  </div>
                  <div class="d-flex flex-column flex-grow-1 overflow-hidden w-px-200">
                    <h6 class="mb-1 text-truncate">${notification.data.title}</h6>
                    <small class="text-truncate text-body">${notification.data.message}</small>
                  </div>
                  <div class="flex-shrink-0 dropdown-notifications-actions">
                    <small class="text-muted">${ calculateTimeAgo(notification.created_at) }</small>
                  </div>
                </div>
              `;

              // Append the new list item to the unordered list
              notificationList.appendChild(newNotificationItem);
            });
          }
        }

        function calculateTimeAgo(createdAt) {
          const now = new Date();
          const createdDate = new Date(createdAt);
          const timeDifference = now - createdDate;

          // Convert milliseconds to seconds
          const seconds = Math.floor(timeDifference / 1000);

          // Define time intervals
          const intervals = [
              { label: 'year', seconds: 31536000 },
              { label: 'month', seconds: 2592000 },
              { label: 'day', seconds: 86400 },
              { label: 'hour', seconds: 3600 },
              { label: 'minute', seconds: 60 },
              { label: 'second', seconds: 1 }
          ];

          for (let i = 0; i < intervals.length; i++) {
              const interval = intervals[i];
              const elapsed = Math.floor(seconds / interval.seconds);

             if (elapsed >= 1) {
                 return `${elapsed} ${interval.label}${elapsed > 1 ? 's' : ''} ago`;
             }
         }

          return 'Just now';
        }
      </script>


        <?php if(!$studentCode): ?>
            <div style="z-index: 2000" class="modal-mask-app">
                <div class="modal-container-app">
                    <div class="mb-3">
                        <h4>Enter Student Code For Your School</h4>

                        <div class="form-floating form-floating-outline mb-4">
                            <input
                            type="text"
                            id="std-code"
                            class="form-control"
                            placeholder="<?php echo e(__("admin/admin-student-setting.enter_student_code_prefix")); ?>"
                            name="student_code_prefix"
                            value="----"
                            />
                            <label
                            for="std-code"
                            ><?php echo e(__('admin/admin-student-setting.student_code_prefix')); ?></label>
                        </div>

                        <button id="std-code-save-btn" class="btn btn-sm btn-primary">
                            Save
                        </button>
                    </div>
                </div>
            </div>

            <script>
                const studentCode = <?php echo json_encode($studentCode, 15, 512) ?>;
                const schoolId    = <?php echo json_encode(auth()->user()->school_id, 15, 512) ?>;

                $('#std-code-save-btn').click(function (e) {
                    e.preventDefault();
                    const code = $('#std-code').val();

                    const url = `/api/${schoolId}/student-code-create`;

                    if(code==='----') {
                        return;
                    }
                    $.ajax({
                        type: "POST",
                        url: url,
                        data: {
                        'student_code_prefix': code
                        },
                        dataType: "json",
                        success: function (response) {
                            location.reload();
                        }
                    });
                });

            </script>
        <?php endif; ?>
    <?php endif; ?>

  </body>


  <?php echo $__env->yieldContent('teleport'); ?>
</html>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/layout/app.blade.php ENDPATH**/ ?>