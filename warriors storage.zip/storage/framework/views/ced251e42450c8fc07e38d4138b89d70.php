<?php $__env->startSection('container'); ?>
    <div class="container flex-grow0">
        <h4 class="fw-bold py-3 mb-4">
                <span class="text-muted fw-light">
                        <?php echo e(__('common-breadcrumb.dashboard')); ?> /
                        <a href="<?php echo e(route('timetables.index')); ?>"><?php echo e(__('admin/breadcrumb/timetable.timetable')); ?></a> /
                        <a href="<?php echo e(route('timetable-formats.index',['course' => $course->id , 'batch' => $batch->id])); ?>">
                            <?php echo e($course->name); ?>

                        </a>
                        <span>/ <?php echo e($batch->name); ?> / notice board </span> /
                </span>
                <?php echo e(__('common-breadcrumb.create')); ?>

        </h4>
        <div class="card col-10">
            <div class="card-body">
                <form
                  action="<?php echo e(route('notice-board.store',[
                    'course' => $course->id, 'batch' => $batch->id
                  ])); ?>"
                  method="POST"
                >
                    <?php echo csrf_field(); ?>
                    <!-- Date Range Section -->
                    <h5 class="text-primary mb-4">Date Range</h5>
                    <div class="d-md-flex gap-2 mb-4 align-items-center ">
                        <div class="form-floating form-floating-outline col-md-4 col-12">
                            <input
                              type="date"
                              name="from"
                              id="start-date"
                              class="form-control"
                            />
                            <label for="start-date" class="form-label">
                                Start Date
                            </label>
                        </div>

                        <span class="d-none d-md-inline">-</span>

                        <div class="form-floating mt-4 mt-md-0 form-floating-outline col-md-4 col-12">
                            <input
                              type="date"
                              name="to"
                              id="end-date"
                              class="form-control"
                            />
                            <label for="end-date" class="form-label">
                                End Date
                            </label>
                        </div>
                    </div>

                    <div class="col-12">
                        <textarea
                        name="content"
                        id="content"
                        ></textarea>
                    </div>

                    <div class="d-flex gap-2 justify-content-end mt-3">
                        <a
                        href="<?php echo e(route('timetable-formats.index',[
                                'course' => $course,
                                'batch'  => $batch,
                            ])); ?>"
                        class="btn btn-outline-secondary btn-md"
                        >
                            Back
                        </a>

                        <button class="btn btn-primary btn-md" type="submit">
                            Create
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


<script src="<?php echo e(asset('assets/tinymce/tinymce.min.js')); ?>"></script>

<script>
    tinymce.init({
      selector: '#content',
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/timetables/notice-board-create.blade.php ENDPATH**/ ?>