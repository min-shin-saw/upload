<div>
    <p id="yes_or_no" class="sr-only"><?php echo e(__('admin\swal-message\create-assign-chatroom.are_you_sure')); ?></p>
    <p id="create_chatrooms_and_assign_automatically" class="sr-only"><?php echo e(__('admin\swal-message\create-assign-chatroom.create_chatrooms_and_assign_automatically')); ?></p>
    <p id="confirm" class="sr-only"><?php echo e(__('admin\swal-message\create-assign-chatroom.confirm_and_create')); ?></p>
    <p id="cancel" class="sr-only"><?php echo e(__('admin\swal-message\create-assign-chatroom.cancel')); ?></p>

    <a href="<?php echo e(route('schools.show', $id)); ?>" class="btn btn-sm btn-icon btn-success waves-effect waves-light">
        <span class="mdi mdi-information-outline" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Show"></span>
    </a>
    <a href="<?php echo e(route('schools.edit', $id)); ?>" class="btn btn-sm btn-icon btn-primary waves-effect waves-light"
    data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Edit"
    >
        <span class="mdi mdi-playlist-edit" ></span>
    </a>
    <button
    type="button"
    class="btn btn-sm btn-icon btn-warning waves-effect waves-light school-chatroom-btn"
    data-url="<?php echo e(route('schools.create-assign-chatrooms', $id)); ?>"
    >
            <span class="mdi mdi-chat-plus-outline" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Create"></span>
    </button>
    <a href="#" class="btn btn-sm btn-icon btn-danger waves-effect waves-light">
        <span class="mdi mdi-delete-circle" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Delete"></span>
    </a>
    <script src="<?php echo e(asset('assets/js/swals/create-assign-chatrooms-swal.js')); ?>"></script>
</div>
<!-- <div class="dropdown">
    <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown" aria-expanded="true">
        <i class="mdi mdi-dots-vertical"></i>
    </button>
    <div class="dropdown-menu" style>
        <button class="dropdown-item waves-effect" href="<?php echo e(route('schools.show', $id)); ?>"><i class="mdi mdi-information-outline me-1"></i> Detail</button>
        <button class="dropdown-item waves-effect" href="<?php echo e(route('schools.edit', $id)); ?>"><i class="mdi mdi-pencil-outline me-1"></i> Edit</button>
        <button class="dropdown-item waves-effect" data-url="<?php echo e(route('schools.destroy',$id)); ?>"><i class="mdi mdi-trash-can-outline me-1"></i> Delete</button>
        <script src="<?php echo e(asset('assets/js/delete-sweet-alert.js')); ?>"></script>
    </div>
</div> --><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/schools/action.blade.php ENDPATH**/ ?>