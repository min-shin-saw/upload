<?php
    $batch = App\Models\Learning\Batch::find($id);
?>
<div class="text-start">
    
    <a
    href="<?php echo e(route('batches.edit',$id)); ?>" 
    class="btn btn-sm btn-icon btn-primary waves-effect waves-light">
        <span class="mdi mdi-playlist-edit" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit"></span>
    </a>
    <a
      href="<?php echo e(route('set-exam',$id)); ?>"
      class="btn btn-sm btn-icon btn-success waves-effect waves-light"
    >
        <span class="mdi mdi-form-select" data-bs-toggle="tooltip" data-bs-placement="top" title="Set Exam"></span>
    </a>

    

    <?php if($batch->status !== 'ongoing'): ?>
    <button
    type="button"
    class="btn btn-sm btn-icon btn-danger waves-effect waves-light delete-btn"
    data-url="<?php echo e(route('batches.destroy',$id)); ?>"
    >
            <span class="mdi mdi-delete-circle"data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"></span>
    </button>
    <?php endif; ?>
    <script src="<?php echo e(asset('assets/js/delete-sweet-alert.js')); ?>"></script>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/batches/action.blade.php ENDPATH**/ ?>