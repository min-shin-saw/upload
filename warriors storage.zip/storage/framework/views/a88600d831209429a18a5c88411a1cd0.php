<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.dashboard')); ?> / <a
                    href="<?php echo e(route('courses.index')); ?>"><?php echo e(__("admin/breadcrumb/course.courses")); ?></a> / </span><?php echo e(__("common-breadcrumb.create")); ?></h4>

        <div class="col-12 mb-4">
            <div class="card">
                <h5 class="card-header"><?php echo e(__('admin/admin-course.courses_create')); ?></h5>
                <div class="card-body">
                    <form action="<?php echo e(route('courses.store')); ?>" enctype="multipart/form-data" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo $__env->make('
                            admin.courses.form-partials.form
                        ', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/js/mss-repeater/mss-repeater.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dropify/dropify.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/mohithg-switchery/mohithg-switchery.min.js')); ?>"></script>

    <script>
        $(function () {
            const subjects = <?php echo json_encode($subjects, 15, 512) ?>;

            const filterSubjects = (subject_id) => {
                return subjects.filter(subject => subject.id == subject_id)[0];
            }

            let selectedArr = [];

            $('.subject-select').change(function (e) {
            e.preventDefault();
            let parent     = $(this).parent().parent().parent().parent().parent().parent().parent();
                if ($(this).val()) {
                    let subject    = filterSubjects($(this).val());
                    let totalPrice = 0;

                    if (selectedArr.includes($(this).val())) {
                        Swal.fire({
                            title: 'Error!',
                            text: 'This subject was selected!',
                            icon: 'error',
                            customClass: {
                            confirmButton: 'btn btn-primary waves-effect waves-light'
                            },
                            buttonsStyling: false
                        });
                        $(this).val('');
                    } else {
                        parent.find('.price-input').val(subject.price);
                        parent.find('img').attr('src', subject.image);

                        $('.price-input').each(function() {
                            price = getInputPrice($(this).val());
                            totalPrice += price
                        });
                        $('[name="price"]').val(totalPrice);

                        let indexToRemove = selectedArr.indexOf($(this).data('oldValue'));
                        if (indexToRemove !== -1) {
                            selectedArr.splice(indexToRemove, 1);
                        }

                        $(this).data('oldValue',$(this).val());

                        $('.subject-select').each(function() {
                            let currentId = $(this).val();
                            if (currentId && !selectedArr.includes(currentId)) {
                                selectedArr.push($(this).val());
                            }
                        })
                    }

                } else {
                    let indexToRemove = selectedArr.indexOf($(this).data('oldValue'));
                    if (indexToRemove !== -1) {
                        selectedArr.splice(indexToRemove, 1);
                    }
                    let price       = getInputPrice(parent.find('.price-input').val());
                    let totalPrice  = getInputPrice($('[name="price"]').val());
                    parent.find('.price-input').val('');
                    parent.find('img').attr('src', "<?php echo e(asset('assets/img/placeholders/course-subject-placeholder.png')); ?>");
                    $('[name="price"]').val(totalPrice - price);
                }
            });

            setMssRepeater({
                id:'#subject-repeater',
                image: "<?php echo e(asset('assets/img/placeholders/course-subject-placeholder.png')); ?>",
                removing: (el) => {
                    let parent      = $(el).parent().parent();
                    let indexToRemove = selectedArr.indexOf(parent.find('.subject-select').val());
                    if (indexToRemove !== -1) {
                        selectedArr.splice(indexToRemove, 1);
                    }
                    let price       = getInputPrice(parent.find('.price-input').val());
                    let totalPrice  = $('[name="price"]').val();
                    $('[name="price"]').val(totalPrice - price);
                },
            });

            const getInputPrice = (inputPrice) => {
                let price = parseInt(inputPrice);
                return isNaN(price)? 0 : price;
            }
        });
    </script>

    <!-- Plugin -->
    <script>
        $(function () {

            var elems = Array.prototype.slice.call(
                document.querySelectorAll('.switchery')
            );

            elems.forEach(function(html) {
                var switchery = new Switchery(html, {
                    size : 'small',
                    color: '#38D8B2'
                });
            });
            $('.dropify').dropify({
                error : {
                    'fileExtension' : "<?php echo e(__('validation.image_type')); ?>",
                }
            });
        });
    </script>

    <?php echo MssValidation::script([
        'request'   => new App\Http\Requests\CourseForm\CreateCourseRequest()
    ]); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dropify/dropify.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/mohithg-switchery/mohithg-switchery.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/courses/create.blade.php ENDPATH**/ ?>