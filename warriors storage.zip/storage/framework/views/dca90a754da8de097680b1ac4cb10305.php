<?php $__env->startSection('container'); ?>

<input hidden id="bulk-import-url" value="<?php echo e(route('student.student-bulk-import')); ?>"/>


<section  id="validation-errors-container" style="display: none">
    <div class="container-xxl flex-grow-1 container-p-y"  >
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?> / </span> <?php echo e(__('admin/breadcrumb/student.students')); ?></h4>
        <?php echo $__env->make('components.bulkimportissuelist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</section>

<section id='datatable'>
    <div  class="container-xxl flex-grow-1 container-p-y" >
        <div class="d-flex justify-content-between align-items-center text-center" style="position: relative">
            <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?> / </span> <?php echo e(__('admin/breadcrumb/student.students')); ?></h4>
            <div class="d-flex align-items-center">
                <div class="d-flex me-2 align-items-center text-center">
                    <h5 class="text-secondary text-center me-2 col-5 mt-2 ">Filter Type :</h5>
                    <select name="filter_type" style="height: 36px;" id="filter_type" class=" form-control form-select mt-1">
                        <option value="both">Both</option>
                        <option value="dob">Date of birth</option>
                        <option value="status">Status</option>
                    </select>
                </div>

                <div class="d-flex  align-items-center text-center justify-content-between me-2 ">
                    <div class="d-flex align-items-center h-100 ">
                        <input type="text" name="dob" id="dob-date" class="form-control">
                    </div>
                </div>
                <select name="status" style="width: 130px" class="form-control form-select me-2" id="status">
                    <option value="">All</option>
                    <option value="1">Active</option>
                    <option value="0">Inactive</option>
                </select>
                <button class="btn btn-primary" id="filter-btn">Filter</button>
            </div>
        </div>
        <div style="position: relative" class="table-responsive text-nowrap">
            <?php echo $dataTable->table(); ?>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .secondary-button {
        border-radius: 6px;
        padding: 8px;
        color: white;
        background-color: #b3b3b3;
    }

    .secondary-button:hover {
        background-color: #a2a4a7;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('teleport'); ?>
    <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel">
            Import Students
            <a
            title="Download Sample Excel"
            download
            href="<?php echo e(asset('bulkimport/StudentBulkImport.xlsx')); ?>"
            class=""
            >
                <span class="mdi mdi-download"></span>
            </a>
          </h1>

          <button
          type="button"
          class="btn-close"
          data-bs-dismiss="modal"
          aria-label="Close"
          ></button>
        </div>

        <div class="modal-body">
            <input
            id="excel-file-input"
            type="file"
            accept=".xlsx"
            class="form-control" >
        </div>

        <div class="modal-footer">
            <button id="modal-close-btn" type="button" class="btn btn-sm btn-outline-secondary waves-effect" data-bs-dismiss="modal"><?php echo e(__('admin/admin-teacher-assign-course.close')); ?></button>

            <button
            type="button"
            id="excel-file-input-btn"
            class="btn btn-sm btn-primary"
            >
                Import
            </button>

            <button class="btn complete-hide btn-sm btn-primary" id="loading">
                <div class="d-flex gap-2 align-items-center">
                    Importing
                    <div
                    style="width:18px;height:18px;"
                    class="spinner-border text-white" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            </button>
        </div>
      </div>
    </div>
  </div>

<?php echo $__env->make('components.activateUserAccount', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
<?php echo e($dataTable->scripts(attributes: ['type' => 'module'])); ?>


<script type="module">
    $(function () {
        const $btns = `
            <button
            title="Bulk Import"
            class="btn btn-primary btn-sm"
            data-bs-toggle="modal"
            data-bs-target="#exampleModal"
            >
                <span class="mdi mdi-file-import me-2"></span>
                <small>Import</small>
            </button>
        `;

        $('.dt-buttons').append($btns);
    });
</script>

<script type="text/javascript" src="<?php echo e(asset('assets/js/plugin/moment.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/plugin/daterange-picker.min.js')); ?>"></script>

<script>
    $(document).ready(function() {

        let start = '';
        let end = '';
        let onMounted = (fn) => fn();


        let handleChange = () => {
            let status = $('#status').val();
            let dobdate = $('#dob-date').val();
            let filterType = $('#filter_type').val();
            let url = "<?php echo e(route('students.index')); ?>";
            let route = '';
            if (filterType == 'dob') {
                route = url + '?date=' + dobdate;
            } else if (filterType == 'status') {
                route = url + '?status=' + status;
            } else {
                route = url + "?status=" + status + "&date=" + dobdate;
            }
            location.href = route + '&type=' + filterType;
        }

        $('#filter-btn').on('click', handleChange);

        onMounted(() => {
            const queryString = window.location.search;
            const urlParams = new URLSearchParams(queryString);
            const date = urlParams.get('date');
            const status = urlParams.get('status');
            const type = urlParams.get('type');
            $('#status').val(status);
            if (type) {
                $('#filter_type').val(type);
            }
            if (date) {
                const datePart = date.split(' - ');
                start = datePart[0];
                end = datePart[1];
            } else {
                start = moment();
                end = moment();
            }

            $('#dob-date').daterangepicker({
                startDate: start,
                endDate: end,
                ranges: {
                    'Today': [moment(), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                }
            });
        });

    });
</script>

<script src="<?php echo e(asset('assets/js/bulkimport/bulkimport.js')); ?>"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/students/index.blade.php ENDPATH**/ ?>