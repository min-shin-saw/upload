 <!-- Fonts -->
 <link rel="preconnect" href="https://fonts.googleapis.com" />
 <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
 <link
   href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap"
   rel="stylesheet" />

 <!-- Icons -->
 <link rel="stylesheet" href="/assets/vendor/fonts/materialdesignicons.css" />
 <link rel="stylesheet" href="/assets/vendor/fonts/fontawesome.css" />

 <!-- Core CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('/assets/vendor/css/rtl/core.css')); ?>" media='screen,print'  />
 <link rel="stylesheet" href="<?php echo e(asset('/assets/vendor/css/rtl/theme-default.css')); ?>" />
 <link rel="stylesheet" href="<?php echo e(asset('/assets/css/demo.css')); ?>" />

 <!-- Vendors CSS -->

 <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css')); ?>" />
 <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/node-waves/node-waves.css')); ?>" />
 <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/typeahead-js/typeahead.css')); ?>" />
 <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/apex-charts/apex-charts.css')); ?>" />
 <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/swiper/swiper.css')); ?>" />
 <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/animate-css/animate.css')); ?>" />
 <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/sweetalert2/sweetalert2.css')); ?>" />
 <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/select2/select2.css')); ?>" />
 <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/tagify/tagify.css')); ?>" />
 <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/bootstrap-select/bootstrap-select.css')); ?>" />
 <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/typeahead-js/typeahead.css')); ?>" />
 <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/bs-stepper/bs-stepper.css')); ?>" />

 <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/flatpickr/flatpickr.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/jquery-timepicker/jquery-timepicker.css ')); ?>" />

 <!-- Page CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/css/pages/cards-statistics.css')); ?>" />
 <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/css/pages/cards-analytics.css')); ?>" />
 <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/spinkit/spinkit.css')); ?>" />

 <!-- Custom CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/css/eduplus/core.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('vendor/mss-js-validation/css/mss-js-validation.min.css')); ?>">
 <?php echo $__env->yieldContent('custom-css-import'); ?>

<style>
    .table-responsive::-webkit-scrollbar {
        height: 5px;
    }
    .table-responsive::-webkit-scrollbar-track {
        -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
    }
    .table-responsive::-webkit-scrollbar-thumb {
        background-color: darkgrey;
    }

    .complete-hide {
        display: none !important;
    }
</style>

<link rel="stylesheet" href="<?php echo e(asset('assets/summernote/summernote.min.css')); ?>">

<link rel="stylesheet" type="text/css" href="https://unpkg.com/trix@2.0.0/dist/trix.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/simplemde/latest/simplemde.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/markdown.css')); ?>" />


 <?php echo $__env->yieldContent('css'); ?>

 <style>
    .dropify-wrapper .dropify-message span.file-icon {
        font-size: 30px !important;
    }
    .dropify-wrapper .dropify-message span.file-icon p {
        font-size: 20px !important;
    }
</style>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/layout/shared/head-css.blade.php ENDPATH**/ ?>