<div id="personal-info" class="content">
    <div class="row g-4">
        <div class="col-md-6 mb-4">
            <div class="form-floating form-floating-outline">
              <select name="payment_type" class="form-select w-100" >
                
                <option value="cash">Cash</option>
                <option value="bank">Bank</option>
                <option value="mobile">Mobile (Kpay, Wave Pay)</option>
              </select>
              <label for=""><?php echo e(__('admin/admin-enrollment.payment_way')); ?></label>
            </div>
        </div>

        
        <div class="col-md-6"></div>

        <div class="col-md-4 mb-4">
            <div class="form-floating form-floating-outline">
              <select name="discount_type" class="form-select w-100" data-style="btn-default">
                <option value="">Select Discount Type</option>
                <option value="percent">Parcent (5%, 10%)</option>
                <option value="fixed">Fixed Ammount (1000, 3000)</option>
              </select>
              <label for=""><?php echo e(__('admin/admin-enrollment.discount_type')); ?></label>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="form-floating form-floating-outline">
                <input name="discount" type="number" class="form-control" placeholder="Enter Discount" >
                <label for=""><?php echo e(__('admin/admin-enrollment.discount')); ?></label>
            </div>
        </div>


        <div class="col-md-4 mb-4">
            <div class="form-floating form-floating-outline">
                <input name="total_amount" type="text" class="form-control" readonly >
                <label for=""><?php echo e(__('admin/admin-enrollment.course_amount')); ?></label>
            </div>
        </div>

        <div class="form-floating form-floating-outline mb-4 col-md-4 ">
            <input name="total_discount_amount" type="text" value="0" class="form-control" readonly >
            <label for=""><?php echo e(__('admin/admin-enrollment.discount_amount')); ?></label>
        </div>

        <div class="form-floating form-floating-outline col-md-4">
            <input name="total_net_amount" type="text" class="form-control" readonly >
            <label for=""><?php echo e(__('admin/admin-enrollment.net_amount')); ?></label>
        </div>

        <div class="col-md-8">
            <div class="card shadow py-0" id="gender">
                <h5 class="card-header py-0"><?php echo e(__('admin/admin-enrollment.payment_option')); ?></h5>
                <div class="card-body py-1">
                    <div class="row">
                        <div class="col-md mb-md-0 mb-2">
                            <div class="form-check custom-option custom-option-icon">
                                <label class="form-check-label custom-option-content"
                                    for="full-payment">
                                    <span class="custom-option-body">
                                        <span class="mdi mdi-cash"></span>
                                        <span class="custom-option-title"><?php echo e(__('admin/admin-enrollment.full_payment')); ?></span>
                                        <p>(<?php echo e(__('admin/admin-enrollment.one_time_payment')); ?>)</p>
                                    </span>
                                    <input name="payment_option" class="form-check-input" type="radio" value="full payment" id="full-payment" checked/>
                                </label>
                            </div>
                        </div>
                        <div class="col-md mb-md-0 mb-2">
                            <div class="form-check custom-option custom-option-icon">
                                <label class="form-check-label custom-option-content"
                                    for="installment-payment">
                                    <span class="custom-option-body">
                                        <span class="mdi mdi-cash-multiple"></span>
                                        <span class="custom-option-title"><?php echo e(__('admin/admin-enrollment.installment_payment')); ?> </span>
                                        <p>(<?php echo e(__('admin/admin-enrollment.separate_payment')); ?>)</p>
                                    </span>
                                    <input name="payment_option" class="form-check-input" type="radio" value="installment payment" id="installment-payment" />
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4 " id="payment-type-div" >
                <h5 class="card-header py-0">Installment Type</h5>
                    <div class=" py-1">
                        <div class="row">
                            <div class="col-10">
                                 <select class="form-select" aria-label="Default select example" id="payment-type-select">
                                    <option value="1">Custom Installment</option>
                                    <option value="2" selected>Equated Installment</option>
                                </select>
                            </div>
                            <div class="col-10">
                                <div class="col-8 d-flex mt-2">
                                    <input type="text" class="form-control " aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" value="1" id="time" placeholder="time">
                                    <button class="btn btn-primary btn-md" id="add-button-payment-type" >+</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>


        <div class="col-12 mb-4" id="full-payment-div">
            <div>
                    <div class="mt-4">
                        <h5><?php echo e(__('admin/admin-enrollment.payment_and_payment_status')); ?></h5>
                        <div class="row">
                            <div class=" col-md-4 mb-0">
                                <div class="form-floating form-floating-outline">
                                    <input
                                    type="text"
                                    name="payment"
                                    class="form-control attended_class"
                                    placeholder="Enter Payment"
                                    />
                                    <label for="attended_class"><?php echo e(__('admin/admin-enrollment.payment_amount')); ?></label>
                                </div>

                            </div>

                            <div class=" col-md-4 mb-0">
                                <div class="form-floating form-floating-outline">
                                    <select name="payment_status" class="form-select w-100" data-style="btn-default">
                                      <option value="unpaid"><?php echo e(__('admin/admin-enrollment.unpaid')); ?></option>
                                      <option value="pending" selected><?php echo e(__('admin/admin-enrollment.paid')); ?></option>
                                    </select>
                                    <label for=""><?php echo e(__('admin/admin-enrollment.payment_status')); ?></label>
                                </div>
                            </div>

                            <div class=" col-md-4 d-flex align-items-center mb-0">

                            </div>
                        </div>
                    </div>
            </div>
        </div>

        <div style="display: none;" class="col-12  pt-4" id="installment-payment-div"  >
            <div id="payment-repeater">
                <div class="d-flex justify-content-start" >
                    <h5 ><?php echo e(__('admin/admin-enrollment.payment_and_payment_status')); ?></h5>
                    <p id="payment-type-info" class=" ms-2">(Equated Installment )</p>
                </div>

                    <div class="repeater-item">
                        <div class="row">
                            <div class="mb-3 col-md-3 mb-0">
                                <div class="form-floating form-floating-outline">
                                    <input
                                    type="text"
                                    name="payments[]"
                                    class="form-control attended_class"
                                    placeholder="Enter Payment"
                                    />
                                    <label for="paymetn"><?php echo e(__('admin/admin-enrollment.payment_amount')); ?></label>
                                </div>
                            </div>

                            <div class="mb-3 col-md-3 mb-0">
                                <div class="form-floating form-floating-outline">
                                    <select name="payments_status[]" class="form-select w-100 payments-status" data-style="btn-default">
                                      <option value="unpaid" selected><?php echo e(__('admin/admin-enrollment.unpaid')); ?></option>
                                      <option value="pending"><?php echo e(__('admin/admin-enrollment.paid')); ?></option>
                                    </select>
                                    <label for=""><?php echo e(__('admin/admin-enrollment.payment_status')); ?></label>
                                </div>
                            </div>


                            <div class="mb-3 col-md-2 mb-0 due_date_div">
                                <div class="form-floating form-floating-outline">
                                    <input name="due_dates[]" type="date" class="form-control due-dates" min="<?php echo e(date('Y-m-d')); ?>">
                                     <label for="due_date">Due Date</label>
                                </div>
                            </div>



                            <div class="mb-3 col-md-4 d-flex align-items-center mb-0">
                                <button type="button" class="btn btn-label-danger waves-effect me-3 remove-btn payment-delete-btn">
                                    <i class="mdi mdi-close me-1"></i>
                                    <span class="align-middle">Delete</span>
                                </button>
                                <button type="button" class="btn btn-label-success waves-effect repeater-add-btn add-payment-btn-ini" >
                                    <i class="mdi mdi-plus me-1"></i>
                                </button>
                            </div>
                        </div>
                    </div>
            </div>

        </div>


        <div>
            <input type="hidden" name="additional_fee_enable" value="false">
            <div class="d-flex">
                <h5>Addtional Fee</h5>
                <div class="form-check form-switch ms-2">
                    <input  class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckChecked" checked>
                </div>
            </div>
            <?php echo $__env->make('admin.enrollments.form-partials.additionalTransaction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="col-12 d-flex justify-content-between">
            <button type="button" class="btn btn-outline-secondary btn-prev" >
                <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
                <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('common.previous')); ?></span>
            </button>
            <button type="button" class="btn btn-primary" id="submit-btn">
                <span class="align-middle d-sm-inline-block d-none me-sm-1"><?php echo e(__('common.submit')); ?></span>
            </button>
        </div>
    </div>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/enrollments/form-partials/payment-and-transition-step.blade.php ENDPATH**/ ?>