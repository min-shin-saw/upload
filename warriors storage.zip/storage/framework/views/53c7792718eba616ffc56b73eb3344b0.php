<?php $__env->startSection('container'); ?>
    <div class="col-12">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?> / </span> <?php echo e(__('admin/users-guides/breadcrumb.admin_guide')); ?></h4>
        <div class="card">
            <div class="row card-header">
                <div class="col-md-6">
                    <h5><?php echo e(__('admin/users-guides/common.admin_detail_form_title')); ?></h5>
                </div>
                <?php if(auth()->user() && auth()->user()->school_id === 0): ?>
                <div class="col-md-6">
                    <a href="<?php echo e(route('documentations.create')); ?>" class="btn btn-sm btn-success float-end"><?php echo e(__('common-breadcrumb.create')); ?></a>
                </div>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3">
                        <div class="row pb-3">
                            <div class="flex-grow-1 input-group input-group-merge rounded-pill">
                              <span class="input-group-text" ><i class="mdi mdi-magnify lh-1"></i></span>
                              <input type="text" id="searchInput" class="form-control chat-search-input" onkeyup="searchList()" placeholder="Search..." aria-label="Search..." aria-describedby="basic-addon-search31">
                            </div>
                        </div>
                        <ul id="list" class="list-group overflow-auto" style="max-height: 400px;">
                        </ul>
                    </div>
                    <div class="col-md-9 overflow-auto" style="min-height: 350px; max-height: 400px;">
                        <div class="row">
                            <?php if(auth()->user() && auth()->user()->school_id === 0): ?>
                            <div class="col-md-10">
                                <h4 id="title">Title</h4>
                            </div>
                            <div class="col-md-2">
                                <a id="edit" href="#" class="btn btn-sm btn-primary float-end" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit"><i class="mdi mdi-pencil"></i></a>
                            </div>
                            <?php else: ?>
                            <h4 id="title">Title</h4>
                            <?php endif; ?>
                        </div>
                        <div class="row pb-3">
                            <p id="description" class="card-text">Description</p>
                        </div>
                        <hr/>
                        <div class="row markdown-body py-3" id="content">
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        var htmlTag = $(':root');
        if(!htmlTag.hasClass('layout-menu-collapsed'))
        {
            htmlTag.addClass('layout-menu-collapsed');
        }
        getList();
        $('[data-toggle="tooltip"]').tooltip();
    });

    async function getList () {
      try {
        const response = await fetch('<?php echo e(route('documentations.list')); ?>', {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            }
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

          const res = await response.json();
          bindList(res.data.documents);
          bindDetail(res.data.default);
      } catch (error) {
          console.error('Error fetching guides : ', error);
      }
    }

    function bindList(documents) {

        var list = document.getElementById('list');
        list.innerHTML = '';
        documents.forEach(element => {
            var li = document.createElement('li');
            li.classList.add('list-group-item');
            li.classList.add('list-group-item-action');
            li.classList.add('list-group-item-primary');
            li.classList.add('d-flex');
            li.classList.add('align-items-center');
            li.classList.add('cursor-pointer');
            li.onclick = function() {
                getDetail(element.frontMatter?.slug);
            };
            li.id = `li-${element.frontMatter?.id}`
            li.innerHTML = `${element.frontMatter?.title}`;
            li.setAttribute('data-toggle', 'tooltip');
            li.setAttribute('data-placement', 'top');
            li.setAttribute('title', `${element.frontMatter?.title}`);
            list.appendChild(li);
        });
    }

    function searchList() {
        var input, filter, ul, li, a, i, txtValue;
        input = document.getElementById("searchInput");
        filter = input.value.toUpperCase();
        ul = document.getElementById("list");
        li = ul.getElementsByTagName("li");
        for (i = 0; i < li.length; i++) {
            txtValue = li[i].textContent || li[i].innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                li[i].classList.add('d-flex');
                li[i].style.display = "";
            } else {
                li[i].classList.remove('d-flex');
                li[i].style.display = "none";
            }
        }
    }

    function bindDetail(doc) {
        var title = document.getElementById('title');
        var description = document.getElementById('description');
        var content = document.getElementById('content');

        <?php if(auth()->user() && auth()->user()->school_id === 0): ?>
            document.getElementById('edit').href = `<?php echo e(route('documentations.edit', ':slug')); ?>`.replace(':slug', doc.frontMatter?.slug);
        <?php endif; ?>
        
        title.innerHTML = doc.frontMatter?.title;
        description.innerHTML = doc.frontMatter?.description;
        content.innerHTML = doc.content;
    }

    async function getDetail(slug)
    {
        const url = `<?php echo e(route('documentations.detail', ':slug')); ?>`.replace(':slug', slug);
          try {
          const response = await fetch(url, {
              headers: {
                  'Accept': 'application/json',
                  'Content-Type': 'application/json',
                  'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
              }
          });

          if (!response.ok) {
              throw new Error('Network response was not ok');
          }

            const res = await response.json();
            bindDetail(res.data.document);
        } catch (error) {
            console.error('Error fetching guide : ', error);
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/documentations/index.blade.php ENDPATH**/ ?>