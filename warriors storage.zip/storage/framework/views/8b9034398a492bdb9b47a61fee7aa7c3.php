<?php $__env->startSection('container'); ?>
    <div class="col-12">
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?> / <a href="<?php echo e(route('vaccines.index')); ?>"><?php echo e(__('admin/vaccines/breadcrumb.vaccines_breadcrumb')); ?></a> / </span><?php echo e(__('common-breadcrumb.create')); ?></h4>
        <div class="card p-4">
            <h5 class="card-header"><?php echo e(__('admin/vaccines/common.vaccine_create')); ?></h5>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('vaccines.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('admin.vaccines.form-partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php echo MssValidation::script([
    'request'   => new App\Http\Requests\VaccineForm\CreateVaccineRequest()
]); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/vaccines/create.blade.php ENDPATH**/ ?>