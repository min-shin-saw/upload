<?php
    $examInfo = \App\Models\Exam\ExamInfo::find($id);

    $status   = false;

    if($examInfo && $examInfo->exams->count()>0) {
        $batch    = $examInfo->exams[0]->batch;
        $status   = true;

        $exams    = \App\Models\SubjectExam::where([
            'batch_id'   => $batch->id,
        ])->get();

        foreach ($exams as $exam) {
            if ($exam->exam_id == null) {
                $status = false;
                break;
            }
        }
    }

?>

<div>
    <a
      href="<?php echo e(route(
            'set-exam',
            $examInfo->exams[0]->batch
        )); ?>"
      class="btn btn-sm btn-icon btn-primary waves-effect waves-light"
    >
        <span class="mdi mdi-form-select" data-bs-toggle="tooltip" data-bs-placement="top" title="Set Exam"></span>
    </a>

    <?php if($status): ?>
        <form
            class="d-none"
            id="publish-form-<?php echo e($id); ?>"
            action="<?php echo e(route('exams.publish',$id)); ?>"
            method="post"
        ><?php echo csrf_field(); ?></form>
        <button form="publish-form-<?php echo e($id); ?>" type="submit" class="btn btn-sm btn-success">
            Publish Results
        </button>
    <?php endif; ?>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/exam/action.blade.php ENDPATH**/ ?>