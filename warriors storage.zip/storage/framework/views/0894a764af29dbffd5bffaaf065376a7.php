<?php $__env->startSection('container'); ?>
    <div class="col-12">
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Dashboard / <a href="<?php echo e(route('custom-notifications.index')); ?>">Custom Notifications</a> / </span>Create</h4>
        <div class="card p-4">
            <h5 class="card-header">Notification Create</h5>
            <div class="card-body">
                <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('custom-notifications.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-floating form-floating-outline mb-4">
                                <input
                                name="title"
                                type="text"
                                class="form-control"
                                id="title"
                                placeholder="Enter Notification Message Title"
                                required
                                >
                                <label for="title">Notification Message Title</label>
                            </div>

                            <div class="form-floating form-floating-outline mb-4">
                                <textarea
                                name="body"
                                class="form-control h-px-150"
                                id="body"
                                placeholder="Enter Notification Message Body"></textarea>
                                <label for="body">Notification Message Body</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="row">
                                <div class="col-md-6 mb-4">
                                    <label class="form-label text-black">
                                        Notification Image
                                    </label>
                                    <input
                                    type="file"
                                    name="content"
                                    class="dropify"
                                    data-allowed-file-extensions='[
                                        "png", "PNG", "jpg", "JPG", "jpeg", "JPEG"
                                    ]'
                                    >
                                </div>
                                <div class="col-md-6 mb-4">
                                    <div class="form-floating form-floating-outline mb-4">
                                        <select id="to-users" name="to_users" class="form-select form-select-lg overflow-auto mb-4">
                                            <optgroup label="--Select Without Batch--">
                                                <option value="1">All Users (Teacher, Student, Guardian)</option>
                                                <option value="2">All Teachers</option>
                                                <option value="3">All Students</option>
                                                <option value="4">All Guardians</option>
                                                <option value="5">All Teachers, Students</option>
                                                <option value="6">All Teachers, Guardians</option>
                                                <option value="7">All Students and their Guardian</option>
                                            </optgroup>
                                            <optgroup label="--Select With Batch--">
                                                <option value="8">All Users (Teacher, Student, Guardian)</option>
                                                <option value="9">All Teachers</option>
                                                <option value="10">All Students</option>
                                                <option value="11">All Guardians</option>
                                                <option value="12">All Teachers, Students</option>
                                                <option value="13">All Teachers, Guardians</option>
                                                <option value="14">All Students and their Guardian</option>
                                            </optgroup>
                                        </select>
                                        <label for="to-users">To</label>
                                    </div>

                                    <div class="form-floating form-floating-outline mb-4">
                                        <select
                                          id="select2Basic"
                                          class="select2 form-select form-select-lg"
                                          name="batch_id"
                                          >
                                            <option value="" selected><?php echo e(__('--Select Batch--')); ?></option>
                                            <?php $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($batch->id); ?>"
                                                >
                                                <?php echo e($batch->name); ?> || <?php echo e($batch->status); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <label for="select2Basic"><?php echo e(__('Batch')); ?></label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="mt-3 d-flex justify-content-between">
                        <a href="<?php echo e(route('custom-notifications.index')); ?>" class="btn btn-outline-secondary">
                            <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
                            <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('common.back')); ?></span>
                        </a>

                        <button class="btn btn-primary ms-2" id="submit-btn" type="button">
                            Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/dropify/dropify.min.js')); ?>"></script>

<script>
    $(function () {
        $('.dropify').dropify();
    });
</script>

<script>
    $(function () {
        $('#select2Basic').select2();

        $('#select2Basic').prop('disabled', true);

        $('#to-users').on('change', function () {
            if (this.value == null || this.value == 1 || this.value == 2 || this.value == 3 || this.value == 4 || this.value == 5 || this.value == 6 || this.value == 7) {
                $('#select2Basic').prop('disabled', true);
            } else {
                $('#select2Basic').prop('disabled', false);
            }
        });
    });
</script>

<?php echo MssValidation::script([
    'request'   => new App\Http\Requests\CreateCustomNotificationRequest(),
    'select2'   => true
]); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dropify/dropify.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/custom-notifications/create.blade.php ENDPATH**/ ?>