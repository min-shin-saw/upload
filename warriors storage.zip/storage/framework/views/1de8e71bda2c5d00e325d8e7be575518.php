<div id="account-details" class="content">
    <div class="row g-4">
        <div class="col-md-12">
            <div class="form-floating form-floating-outline mb-4">
                <select
                  id=""
                  class="select2 form-select form-select-lg"
                  name="student_id"
                  >
                    <?php if(!isset($enrollment)): ?>
                        <option value=""><?php echo e(__('admin/admin-enrollment.select_student')); ?></option>
                    <?php endif; ?>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($student->id); ?>"
                        <?php if(isset($enrollment)): ?>
                            <?php echo e($enrollment->student_id == $student->id?'selected':''); ?>

                        <?php endif; ?>
                        >
                        Name: <?php echo e($student->name); ?>, NRC: <?php if($student->nrc_id): ?>
                        <?php echo e($student->nrcInfo?->nrc_code .'/' .$student->nrcInfo?->name_en .App\Models\School\Nrc::TYPES[$student->nrc_type] .$student->nrc); ?>

                        <?php else: ?>
                         <?php echo e('---'); ?>

                        <?php endif; ?>, Phone: <?php echo e($student->phone); ?>, Email:
                            <?php echo e(isGeneratedString($student->email,'user') ? '-'   : $student->email); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <label for="select2Basic"><?php echo e(__('admin/admin-enrollment.select_student')); ?></label>
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-floating form-floating-outline mb-4">
                <select
                  id=""
                  class="select2 form-select form-select-lg"
                  name="course_id"
                  >
                    <?php if(!isset($enrollment)): ?>
                        <option value=""><?php echo e(__('admin/admin-enrollment.select_course')); ?></option>
                    <?php endif; ?>
                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($course->id); ?>"
                        <?php if(isset($enrollment)): ?>
                            <?php echo e($enrollment->course_id == $course->id?'selected':''); ?>

                        <?php endif; ?>
                        >
                        <?php echo e($course->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <label for="select2Basic"><?php echo e(__('admin/admin-enrollment.select_course')); ?></label>
            </div>
        </div>

        <div class="col-md-6">
            
        </div>

        <div class="col-md-6">
            <div class="form-floating form-floating-outline mb-4">
                <select
                  id=""
                  class="select2 form-select form-select-lg batch-select"
                  name="initial_batch_id"
                  >
                    <?php if(!isset($enrollment)): ?>
                        <option value=""><?php echo e(__('admin/admin-enrollment.select_initial_batch')); ?></option>
                    <?php else: ?>
                        <?php $__currentLoopData = $enrollmentBatches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($batch->id); ?>"
                                <?php echo e($enrollment->batch_id == $batch->id?'selected':''); ?>

                            >
                            <?php echo e($batch->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
                <label for="select2Basic"><?php echo e(__('admin/admin-enrollment.select_initial_batch')); ?></label>
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-floating form-floating-outline">
                <select
                  id=""
                  class="select2 form-select form-select-lg batch-select"
                  name="batch_id"
                  >
                    <?php if(!isset($enrollment)): ?>
                        <option value=""><?php echo e(__('admin/admin-enrollment.select_current_batch')); ?></option>
                    <?php else: ?>
                        <?php $__currentLoopData = $enrollmentBatches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($batch->id); ?>"
                            <?php echo e($enrollment->batch_id == $batch->id?'selected':''); ?>

                            >
                            <?php echo e($batch->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
                <label for="select2Basic"><?php echo e(__('admin/admin-enrollment.select_current_batch')); ?></label>
            </div>
        </div>

        <div style="margin-top: 5px !important;" class="col-md-12 subject-container">
            <div></div>
        </div>

        <div class="col-12 d-flex justify-content-between">
            <a href="<?php echo e(route('enrollments.index')); ?>" class="btn btn-outline-secondary">
                <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
                <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('common.back')); ?></span>
            </a>
                <button type="button" class="btn-next invisible" id="to-payment-step-btn"><?php echo e(__('common.next')); ?></button>
            <button type="button" class="btn btn-primary call-enrollment-step-validation">
                <span class="align-middle d-sm-inline-block d-none me-sm-1"><?php echo e(__('common.next')); ?></span>
                <i class="mdi mdi-arrow-right"></i>
            </button>
        </div>
    </div>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/enrollments/form-partials/enrollment-step.blade.php ENDPATH**/ ?>