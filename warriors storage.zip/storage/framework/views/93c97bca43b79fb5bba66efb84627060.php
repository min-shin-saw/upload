<div class="text-start"> <a href="<?php echo e(route('subjects.show',$id)); ?>" class="btn btn-sm btn-icon btn-success waves-effect waves-light" title="Show">
        <span class="mdi mdi-information-outline" data-bs-toggle="tooltip" data-bs-placement="top" title="Show"></span>
    </a>

    <a
    href="<?php echo e(route('subjects.edit',$id)); ?>"
    class="btn btn-sm btn-icon btn-primary waves-effect waves-light" title="Edit">
        <span class="mdi mdi-playlist-edit" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit"></span>
    </a>

    <button
    type="button"
    class="btn btn-sm btn-icon btn-danger waves-effect waves-light delete-btn"
    data-url="<?php echo e(route('subjects.destroy',$id)); ?>"
    title="Delete"
    >
        <span class="mdi mdi-delete-circle"></span>
    </button>

    <?php
        $subject   = App\Models\Learning\Subject::with('courses')->find($id);
        $condition = $subject->courses->count()>0
                        ?$subject->courses[0]->batches->count()>0
                        :false;
    ?>

    <?php if($condition): ?>
    <button form="certificate-form-<?php echo e($id); ?>"
    title="Certificate"
    class="btn btn-sm btn-icon btn-warning waves-effect waves-light">
        <span class="mdi mdi-certificate-outline"></span>
    </button>

    <form
    method="get"
    class="d-none"
    id="certificate-form-<?php echo e($id); ?>"
    action="<?php echo e(route('certificates.index')); ?>" >
        <input type="hidden" name="subject_id" value="<?php echo e($id); ?>">
        <input type="hidden" name="for" value="subject">
    </form>
    <?php endif; ?>

    <script src="<?php echo e(asset('assets/js/delete-sweet-alert.js')); ?>"></script>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/subjects/action.blade.php ENDPATH**/ ?>