<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?> / </span> <?php echo e(__('admin/breadcrumb/user-report.user_reports')); ?></h4>
        <div class="table-responsive text-nowrap">
            <?php echo $dataTable->table(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <?php echo e($dataTable->scripts(attributes: ['type' => 'module'])); ?>

    <script type="text/javascript" src="<?php echo e(asset('assets/js/plugin/moment.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/plugin/daterange-picker.min.js')); ?>"></script>

    <script type="module">
        $(document).ready(function() {
         var firstRow = $('.dt-buttons').parent().addClass('d-flex');
         firstRow.append(`
                <form class="col-8 d-flex" action="<?php echo e(route('user-reports.index')); ?>" method="get" >
                    <?php echo csrf_field(); ?>
                    <div class="col-4  ms-3">
                        <select name="user_type" id="usertype-select" class="form-select select2 subject-select" style="height:43px ;" >
                            <option value="all">All</option>
                            <option value="guardian">Guardian</option>
                            <option value="student">Student</option>
                            <option value="teacher">Teacher</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                    <div class="ms-2 ">
                        <input type="text" name="dates" style="height:43px;" >
                    </div>
                    <button id="filter" class="btn btn-primary btn-sm  ms-2">
                        filter
                    </button>
                </form>
            `)

            const urlParams = new URLSearchParams(window.location.search);
            let start = '';
            let end =  '';
           
            if (urlParams.size != 0) {
                const userTypeParam = urlParams.get('user_type');
                const datesParam = urlParams.get('dates');
                const datePart = datesParam.split(' - ');
                start = datePart[0];
                end =  datePart[1];
                $('#usertype-select').val(userTypeParam);
            }else{
                start = moment();
                end = moment();
            }
         
            
            $('input[name="dates"]').addClass('form-control col-4').daterangepicker({
                startDate: start,
                endDate: end,
                ranges: {
                    'Today': [moment(), moment()],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                }
            });
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/user-reports/index.blade.php ENDPATH**/ ?>