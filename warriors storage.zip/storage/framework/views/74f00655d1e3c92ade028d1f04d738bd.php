<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Dashboard / <a
                    href="<?php echo e(route('employees.index')); ?>">Employees</a> / </span>Create</h4>
        <h5 class="card-header">Employee Registration</h5>
        <div class="col-12 mb-4">
            <div class="bs-stepper wizard-numbered mt-2">
                <div class="bs-stepper-header">
                    <div class="step" data-target="#account-details">
                        <button type="button" class="step-trigger">
                            <span class="bs-stepper-circle"><i class="mdi mdi-check"></i></span>
                            <span class="bs-stepper-label">
                                <span class="bs-stepper-number">01</span>
                                <span class="d-flex flex-column gap-1 ms-2">
                                    <span class="bs-stepper-title">Employee Info</span>
                                    <span class="bs-stepper-subtitle">Basic Employee Details</span>
                                </span>
                            </span>
                        </button>
                    </div>
                    <div class="line"></div>
                    <div class="step" data-target="#personal-info">
                        <button type="button" class="step-trigger">
                            <span class="bs-stepper-circle"><i class="mdi mdi-check"></i></span>
                            <span class="bs-stepper-label">
                                <span class="bs-stepper-number">02</span>
                                <span class="d-flex flex-column gap-1 ms-2">
                                    <span class="bs-stepper-title">Guardian Info</span>
                                    <span class="bs-stepper-subtitle">Add Parents info</span>
                                </span>
                            </span>
                        </button>
                    </div>
                    <div class="line"></div>
                    <div class="step" data-target="#social-links">
                        <button type="button" class="step-trigger">
                            <span class="bs-stepper-circle"><i class="mdi mdi-check"></i></span>
                            <span class="bs-stepper-label">
                                <span class="bs-stepper-number">03</span>
                                <span class="d-flex flex-column gap-1 ms-2">
                                    <span class="bs-stepper-title">Education Info</span>
                                    <span class="bs-stepper-subtitle">Add Education info</span>
                                </span>
                            </span>
                        </button>
                    </div>
                </div>
                <div class="bs-stepper-content">
                    <form action="<?php echo e(route('employees.store')); ?>" method="POST" enctype="multipart/form-data" id="employee-form">
                        <?php echo csrf_field(); ?>
                        <!-- employee Info -->
                        <input type="hidden" value="<?php echo e(route('employee-form.first-step')); ?>" id="first-step-validation">
                        <?php echo $__env->make('admin.employees.form-partials.first-step-employee-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <!-- Parents Info -->
                        <input type="hidden" value="<?php echo e(route('employee-form.second-step')); ?>" id="second-step-validation">
                        <?php echo $__env->make('admin.employees.form-partials.second-step-guardian-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <!-- Education Info -->
                        <input type="hidden" value="<?php echo e(route('employee-form.third-step')); ?>" id="third-step-validation">
                        <?php echo $__env->make('admin.employees.form-partials.third-step-edu-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset(
        'assets/js/form-handling/employee-data-preparation/create-employee-first-step.js'
    )); ?>"></script>

    <script src="<?php echo e(asset(
        'assets/js/form-handling/employee-data-preparation/create-employee-second-step.js'
    )); ?>"></script>

    <script src="<?php echo e(asset(
        'assets/js/form-handling/employee-data-preparation/create-employee-third-step.js'
    )); ?>"></script>

    <script src="<?php echo e(asset('assets/dropify/dropify.min.js')); ?>"></script>

    <!-- Plugin -->
    <script>
        $(function () {
            $('.dropify').dropify();
        })
    </script>

    <script>
        $(function () {
            //data
            const nrc_datum = <?php echo json_encode($nrc_datum, 15, 512) ?>;

            //event
            $('.nrc-code').change(function (e) {
                e.preventDefault();
                let el = $(this).parent().parent().parent().parent();
                let nrc_name_select = el.find('.nrc-name');
                nrc_name_select.html(nrcNameSelectRender($(this).val()));
            });

            $('.marital_status').click(function() {
                if($(this).val() == "single"){
                    $(".husband_wife").hide();
                }else{
                    $(".husband_wife").show();
                }
            });

            //computed Fand variable method
            let filterNrcs = (nrc_code) => {
              return nrc_datum.filter(nrc_data => nrc_data.nrc_code == nrc_code)
            }

            let nrcNameSelectRender = (nrc_code) => {
                let html = '';
                filterNrcs(nrc_code).forEach(element => {
                    html+= `
                    <option value="${element.id}">${element.name_en}</option>
                    `
                });
                return html;
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dropify/dropify.min.css')); ?>">
    <style>
        .input-group .select2-selection.select2-selection--single {
            border-radius: 0;
        }
        .input-group .select2.select2-container.select2-container--default {
            padding: 0;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-css-import'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/quill/typography.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/quill/katex.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/quill/editor.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-vendor-js-import'); ?>
    <script src="<?php echo e(asset('assets/vendor/libs/jquery-repeater/jquery-repeater.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js-import'); ?>
    <script src="<?php echo e(asset('assets/js/forms-extras.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/employees/create.blade.php ENDPATH**/ ?>