<?php $__env->startSection('breadcrumbs'); ?>
    <h4 class="fw-bold py-3 mb-4 h4"><span class="text-muted fw-light">Admin / <a href="javascript:history.back()"># <?php echo e($payment->payment_code); ?> / </a></span> Invoice</h4>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($studentTransaction->transactionname->id  == 1 ?'admin.invoice.form' : 'admin.invoice.additional-fee', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/student-transactions/show.blade.php ENDPATH**/ ?>