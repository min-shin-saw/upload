<div id="personal-info" class="content">
    <div class="row g-4">

        <h3><?php echo e(__('admin/admin-employee.employee_marital_information')); ?></h3>

        <div class="col col-md-6 mb-4">
            <div class="form-group">
                <div class="form-check-inline">
                  <label class="form-check-label">
                    <input type="radio" class="form-check-input permission-offcanvas-body-item-body marital_status" name="marital_status" value="married"
                    <?php if(isset($employee)): ?>
                        <?php echo e($employee->marital_status == 'married' ? 'checked' : ''); ?>

                    <?php else: ?>
                        <?php echo e('checked'); ?>

                    <?php endif; ?>
                    > <?php echo e(__('admin/admin-employee.married')); ?>

                  </label>
                </div>
                <div class="form-check-inline">
                  <label class="form-check-label">
                    <input type="radio" class="form-check-input permission-offcanvas-body-item-body marital_status" name="marital_status" value="single"
                    <?php if(isset($employee)): ?>
                        <?php echo e($employee->marital_status == 'single' ? 'checked' : ''); ?>

                    <?php endif; ?>
                    > <?php echo e(__('admin/admin-employee.single')); ?>

                  </label>
                </div>
            </div>
        </div>
    </div>

    <div class="row husband_wife">

        <div class="col-md-6 mb-4">
            <div class="form-floating form-floating-outline">
                <input
                type="text"
                id="husband_wife_name"
                class="form-control"
                placeholder="Enter Husband/Wife's Name"
                name="husband_wife_name"
                value="<?php echo e(isset($employee)?$employee->husband_wife_name:''); ?>"
                />
                <label for="husband_wife_name"><?php echo e(__('admin/admin-employee.husband_or_wife_name')); ?></label>
            </div>
        </div>
        <div class="col-md-6 mb-4">
            <div class="form-floating form-floating-outline">
                <input
                type="text"
                id="husband_wife_job"
                class="form-control"
                placeholder="Enter Husband/Wife's Job"
                name="husband_wife_job"
                value="<?php echo e(isset($employee)?$employee->husband_wife_job:''); ?>"
                />
                <label for="husband_wife_job"><?php echo e(__('admin/admin-employee.husband_or_wife_job')); ?></label>
            </div>
        </div>
    </div>

    <hr>

    <div class="row g-4">

        <h3><?php echo e(__('admin/admin-employee.employee_parent_information')); ?></h3>

        <div class="col-md-6 mb-4">
            <div class="form-floating form-floating-outline">
                <input
                type="text"
                id="parent_name"
                class="form-control"
                placeholder="Enter Parent Name"
                name="parent_name"
                value="<?php echo e(isset($employee)?$employee->parent_name:''); ?>"
                />
                <label for="parent_name"><?php echo e(__('admin/admin-employee.parent_name')); ?></label>
            </div>
        </div>

        <div class="col-md-6 mb-4">
            <div class="form-floating form-floating-outline input-group">
                <select
                class="form-control select2 nrc-code"
                >
                    <?php if(!isset($employee)): ?>
                        <option value="0">--</option>
                    <?php endif; ?>
                    <?php $__currentLoopData = $nrc_codes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nrc_code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <option
                       value="<?php echo e($nrc_code); ?>"
                       <?php if(isset($employee)): ?>
                           <?php echo e($employee->parentNrcInfo?->parent_nrc_code ==  $nrc_code? 'selected' : ''); ?>

                       <?php endif; ?>
                       ><?php echo e($nrc_code); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <?php if(isset($employee)): ?>
                    <?php
                        $nrcs = App\Models\School\Nrc::where('nrc_code', $employee->parentNrcInfo?->parent_nrc_code)->get();
                    ?>
                    <select class="form-control select2 nrc-name" name="parent_nrc_id" id="parent-nrc-id">
                        <?php $__currentLoopData = $nrcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nrc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($nrc->id); ?>" <?php if($nrc->id == $employee->parent_nrc_id): echo 'selected'; endif; ?>><?php echo e($nrc->name_en); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                <?php else: ?>
                    <select class="form-control select2 nrc-name" name="parent_nrc_id" id="parent-nrc-id"></select>
                <?php endif; ?>

                <select
                class="form-control select2"
                name="parent_nrc_type"
                >
                    <?php $__currentLoopData = App\Models\School\Nrc::TYPES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option
                        value="<?php echo e($key); ?>"
                        <?php if(isset($employee)): ?>
                            <?php echo e($key == $employee->parent_nrc_type?'selected':''); ?>

                        <?php endif; ?>
                        ><?php echo e($value); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <input
                type="text"
                class="form-control"
                placeholder="Enter Code"
                name="parent_nrc"
                value="<?php echo e(isset($employee)?$employee->parent_nrc:''); ?>"
                />
            </div>
        </div>
    </div>

    <div class="row g-4">

        <div class="col-md-6 mb-4">
            <div class="form-floating form-floating-outline">
                <input
                type="text"
                id="parent_job"
                class="form-control"
                placeholder="Enter Father Job"
                name="parent_job"
                value="<?php echo e(isset($employee)?$employee->parent_job:''); ?>"
                />
                <label for="parent_job"><?php echo e(__('admin/admin-employee.parent_job')); ?></label>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-12 d-flex justify-content-between">
            <button class="btn btn-outline-secondary btn-prev">
                <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
                <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('admin/admin-employee.previous')); ?></span>
            </button>
            <button type="button" class="btn-next invisible" id="to-pg3-btn"><?php echo e(__('admin/admin-employee.next')); ?></button>
            <button type="button" class="btn btn-primary call-second-step-validation">
                <span class="align-middle d-sm-inline-block d-none me-sm-1"><?php echo e(__('admin/admin-employee.next')); ?></span>
                <i class="mdi mdi-arrow-right"></i>
            </button>
        </div>
    </div>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/employees/form-partials/second-step-guardian-info.blade.php ENDPATH**/ ?>