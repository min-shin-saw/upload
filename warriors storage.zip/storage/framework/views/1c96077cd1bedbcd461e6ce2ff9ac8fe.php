<div>
    <button
    type="button"
    class="btn btn-sm btn-icon btn-danger waves-effect waves-light delete-btn"
    data-url="<?php echo e(route('timetables.destroy',$id)); ?>"
    title="Delete"
    >
            <span class="mdi mdi-delete-circle"></span>
    </button>
    <script  src="<?php echo e(asset('assets/js/delete-sweet-alert.js')); ?>"></script>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/timetables/list-action.blade.php ENDPATH**/ ?>