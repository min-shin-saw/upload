<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__("common-breadcrumb.dashboard")); ?> / <a
                    href="<?php echo e(route('enrollments.index')); ?>"><?php echo e(__('admin/breadcrumb/enrollment.enrollments')); ?></a> / </span><?php echo e(__('common-breadcrumb.create')); ?></h4>

        <div class="col-12 mb-4">
            <h5 class="card-header mb-4"><?php echo e(__('admin/admin-enrollment.enrollment_create')); ?></h5>
            <div class="col-12 mb-4">
                <div class="bs-stepper wizard-numbered mt-2">
                    <div class="bs-stepper-header">
                        <div class="step" data-target="#account-details">
                            <button type="button" class="step-trigger">
                                <span class="bs-stepper-circle"><i class="mdi mdi-check"></i></span>
                                <span class="bs-stepper-label">
                                    <span class="bs-stepper-number">01</span>
                                    <span class="d-flex flex-column gap-1 ms-2">
                                        <span class="bs-stepper-title"><?php echo e(__('admin/admin-enrollment.enrollment_info')); ?></span>
                                        <span class="bs-stepper-subtitle">Enrollment</span>
                                    </span>
                                </span>
                            </button>
                        </div>
                        <div class="line"></div>
                        <div class="step" data-target="#personal-info">
                            <button type="button" class="step-trigger">
                                <span class="bs-stepper-circle"><i class="mdi mdi-check"></i></span>
                                <span class="bs-stepper-label">
                                    <span class="bs-stepper-number">02</span>
                                    <span class="d-flex flex-column gap-1 ms-2">
                                        <span class="bs-stepper-title"><?php echo e(__('admin/admin-enrollment.payment_and_transition_info')); ?></span>
                                        <span class="bs-stepper-subtitle">Payment and Transition</span>
                                    </span>
                                </span>
                            </button>
                        </div>
                    </div>
                    <div class="bs-stepper-content">
                        <form action="<?php echo e(route('enrollments.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <!-- Enrollment Info -->
                            <input type="hidden" id="enrollment-step-validation" value="<?php echo e(route('enrollment-create-validate')); ?>">
                            <?php echo $__env->make('admin.enrollments.form-partials.enrollment-step', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <!-- Payment and Transition Info -->

                            <?php echo $__env->make('admin.enrollments.form-partials.payment-and-transition-step', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/js/mss-repeater/mss-repeater.js')); ?>"></script>
    <script>
        $(function () {
            const batches  = <?php echo json_encode($batches, 15, 512) ?>;
            const courses  = <?php echo json_encode($courses, 15, 512) ?>;
            const course_subjects = <?php echo json_encode($course_subjects, 15, 512) ?>;
            const transactionNames = <?php echo json_encode($transactionNames, 15, 512) ?>;


            function getFormattedDate() {
                const today = new Date();
                const year = today.getFullYear();
                const month = String(today.getMonth() + 1).padStart(2, '0');
                const day = String(today.getDate()).padStart(2, '0');
                return `${year}-${month}-${day}`;
            }

            $('.additional-payments-status').change(function (e) {
                e.preventDefault();
                const additionalDueDateInput = $(this)
                    .closest('.row')
                    .find('.additional-due-dates');
                if ($(this).val() === 'pending') {
                    additionalDueDateInput.val(getFormattedDate());
                } else {
                    additionalDueDateInput.val(null);
                }
            });

            $('.payments-status').change(function (e) {
                e.preventDefault();
                const dueDateInput = $(this)
                    .closest('.row')
                    .find('.due-dates');
                if ($(this).val() === 'pending') {
                    dueDateInput.val(getFormattedDate());
                } else {
                    dueDateInput.val(null);
                }
            });

            /*
            *   Toggle the additional fee  based on the check box
            */
            $('#flexSwitchCheckChecked').change(function(){
                if($(this).is(':checked')){
                    $('[name="additional_fee_enable"]').val(true)
                    $('#additional-fee-repeater').show()
                }else{
                    $('[name="additional_fee_enable"]').val(false)
                    $('#additional-fee-repeater').hide()
                }
            })

            /*
            *   Default additional toggle to off
            */

            $('#flexSwitchCheckChecked').click()

            /**
             * Iterates through each dropdown element specified by the given selector
             * and invokes the provided callback function for each option within the dropdown.
             *
             * @param {string} selector - The jQuery selector for the dropdown elements ( class name only ).
             * @param {function} fn -  this function will get two parameter each optionValue and currentOption ( html element )
             *                         you can you conditional check and do what you want
             *
             */

            function hideAndShowTheSelectOption(selector, fn) {
                $(selector).each(function (index, element) {
                    let currentDropdown = $(element);
                    currentDropdown.find('option').each(function () {
                        // Retrieves the value of the current option
                        let optionValue = $(this).val();

                        // Wraps the current option element in a currentOption to pass to the function as parameter
                        let currentOption = $(this);

                        // Invokes the provided callback function with the option value and element
                        fn(optionValue, currentOption);
                    });
                });
            }



            /*
            *    This code will find the  delete row value
            *    reopen the option for each select
            */

            $(document).on('click','.addition-payment-delete-btn', function(e){
                //get the value of deleted row
                 let valueOfDeletedRow = $(this).parent().parent().find('.transaction-name-dropdown').val()

                // hideAndShowTheSelectOption('.transaction-name-dropdown', function(optionValue,currentOption){
                //     if (optionValue == valueOfDeletedRow) {
                //         currentOption.show();
                //     }
                // })
            })

            /*
            *   This code loop transactionName
            *   array when name is select and
            *   find the data that match the id and
            *   get the value and add to nearest transaction-name-value input
            *   remove the selected option for each select
            */

            $(document).on('change','.transaction-name-dropdown',function(e) {

                e.preventDefault();

                let currentValue = $(this).val();
                let value;

                transactionNames.forEach((el) => el.id == currentValue ? value = el.value : null);

                //  Get the root element and fint the value input and set the value
                $(this).parent().parent().parent().find('.additional-transaction-value-input').val(value);

                // Get an array of selected values
                let selectedValues = $('.transaction-name-dropdown').map(function() {
                    return $(this).val();
                }).get();

                // hideAndShowTheSelectOption('.transaction-name-dropdown', function(optionValue,currentOption){
                //     if (selectedValues.includes(optionValue) && optionValue !== "") {
                //         // Hide selected options
                //         currentOption.hide();
                //     } else {
                //         // Show unselected options
                //         currentOption.show();
                //     }
                // })

            });

            // Add repeater item
            $(".addition-add-payment-btn-ini").click(function () {
                var newItem = $("#additional-fee-repeater .additional-repeater-item:first").clone(true);
                newItem.find("input").val("");
                newItem.find("additional_payments_status").val('unpaid')
                newItem.find("transaction-name-dropdown").val('')
                $("#additional-fee-repeater").append(newItem);
                updateDeleteButtonStatus();
                $('.addition-add-payment-btn-ini').not(':first').remove();
            });

            // Remove repeater item
            $("#additional-fee-repeater").on("click", ".addition-payment-delete-btn", function () {
                if ($("#additional-fee-repeater .additional-repeater-item").length > 1) {
                    $(this).closest(".additional-repeater-item").remove();
                    updateDeleteButtonStatus();
                }
            });

            // Function to update delete button status
            function updateDeleteButtonStatus() {
                var deleteButtons = $(".addition-payment-delete-btn");
                deleteButtons.prop("disabled", false); // Enable all delete buttons
                deleteButtons.first().prop("disabled", true); // Disable the delete button for the first row
            }

            // Initial update of delete button status
            updateDeleteButtonStatus();


            $('[name="student_id"]').change(function (e) {
                e.preventDefault();
                html = '<option value="">Select Course</option>';
                courses.forEach(el => {
                    html += `
                        <option value="${el.id}">${el.name}</option>
                    `
                });
                $('[name="course_id"]').html(html);
                $('.batch-select').html('<option value="">Select Batch</option>');
                reset();
            })

            $('[name="course_id"]').change(function (e) {
                e.preventDefault();
                let courseId = $(this).val();
                $('[name="batch_id"]').html(renderBatchSelect(courseId));
                $('[name="initial_batch_id"]').html(renderBatchSelect(courseId,'init-batch'));
                reset();
                let course = filterCourse(courseId)[0];

                $('[name="total_amount"]').val(course?.price);
                $('[name="total_net_amount"]').val(course?.price);
                $('[name="payment"]').val(course?.price);
                $('[name="payments[]"]').val(course?.price);


                if(course?.is_custom) {
                    $('.subject-container').html(renderSubjects(courseId))
                } else {
                    $('.subject-container').html('');
                }
            });

            $('[name="discount"]').keyup(function (e) {
                e.preventDefault();
                price = $('[name="total_amount"]').val();
                discount = $(this).val();
                discount_type = $('[name="discount_type"]').val();
                setDiscount(price, discount, discount_type);
            });

            $('[name="discount_type"]').change(function (e) {
                e.preventDefault();
                price = $('[name="total_amount"]').val();
                discount = $('[name="discount"]').val();
                discount_type = $(this).val();
                setDiscount(price, discount, discount_type);
            })

            $('[name="payment_option"]').change(function (e) {
                e.preventDefault();
                payment_option = $('[name="payment_option"]:checked').val();
                showHidePayment(payment_option);
            })


            const changeThePayTypeTitle = ()=>{
                let text = $('#payment-type-select option:selected').text()
                $('#payment-type-info').text('('+text+')');
            }


            // const setTheDatePickerToDefault = ()=>{
            //         let currentDate =new Date() ;
            //         currentDate.setDate(currentDate.getDate() + 1);
            //         // Format the next day as yyyy-mm-dd
            //         let nextDay = currentDate.toISOString().split('T')[0];

            //         $('input[name="due_dates[]"]').each(function(){
            //             $(this).attr('min', nextDay);
            //     });
            // }

            $('.due_date_div:first').hide();

            const showDateInput = ()=>{
                $('.due_date_div:not(:first)').show();
            }

            $('select[name="payment_status"]').prop('disabled', true);

            /*
            *This code to limit the date input example  if user choose tomorrow and the next input for date will not be avalible in date input
            *
            */
            // $('input[name="due_dates[]"]').change(function () {
            //         let selectedDate = $(this).val();
            //         let dateObj = new Date(selectedDate);
            //         // Calculate the next day by adding one day to the selected date
            //         dateObj.setDate(dateObj.getDate() + 1);

            //         // Format the next day as yyyy-mm-dd
            //         let nextDay = dateObj.toISOString().split('T')[0];

            //         $('input[name="due_dates[]"]').each(function(){
            //             $(this).attr('min', nextDay);
            //         });
            //   });

            $("#add-button-payment-type").click(function(e) {
                e.preventDefault();
                let time = $('#time').val();
                let selectedOption = $('#payment-type-select').val();
                let total_net_amount = $('[name="total_net_amount"]').val();
                if (selectedOption == 1) {
                    changeThePayTypeTitle()
                    // setTheDatePickerToDefault()
                    $('.add-payment-btn-ini').prop("disabled", false);
                    $('.repeater-item:not(:first)').remove();
                    $('input[name="payments[]"]').val($('[name="total_net_amount"]').val());
                    for (let index = 0; index < time-1; index++) {
                        $($('.repeater-add-btn')[0]).click();
                        //this two line is to fix when the created event is triggered and adding time
                        let fixTime = parseInt($('#time').val(), 10);
                        $('#time').val(fixTime - 1);
                    }
                    showDateInput();
                    toggleInput(false)
                    changeFirstInitalAmountToPaid()
                }else{
                    changeThePayTypeTitle()
                    // setTheDatePickerToDefault()
                    let length = $('.repeater-item').length;
                   $('.repeater-item:not(:first)').remove();
                    if(total_net_amount % time == 0 ){
                        for (let index = 0; index < time-1; index++) {
                            $($('.repeater-add-btn')[0]).click();
                            //this two line is to fix when the created event is triggered and adding time
                            let fixTime = parseInt($('#time').val(), 10);
                            $('#time').val(fixTime - 1);
                        }
                        $('.payment-delete-btn').prop("disabled", true);
                        $('.add-payment-btn-ini').prop("disabled", true);
                        var paymentInputs = $('input[name="payments[]"]');
                        // Set a new value for each input
                        paymentInputs.each(function(index) {
                            $(this).val(total_net_amount/time); // You can set your desired value here
                        });
                        showDateInput();
                        toggleInput(true)
                        changeFirstInitalAmountToPaid()
                    }else{
                        $('#time').val(1);
                        $('.repeater-item:not(:first)').remove();
                        $('input[name="payments[]"]').val($('[name="total_net_amount"]').val());
                        changeFirstInitalAmountToPaid()
                        alertingImpossible('Equated Installment for this time is impossible!');
                    }
                }
            });

            const toggleInput = (status) =>{
                $('input[name="payments[]"]').prop("readonly", status)
            }

            const changeFirstInitalAmountToPaid = ()=>{
                // Get the first <select> element and its second <option> element (index 1)
                var selectElement = $('.repeater-item select[name="payments_status[]"]:first');
                var optionToSelect = selectElement.find('option:eq(1)'); // eq(1) selects the second option (index 1)

                // Set the selected property of the option to true
                optionToSelect.prop('selected', true);
            };

            const alertingImpossible = (message) => {
                Swal.fire({
                    icon: 'error',
                    title: 'Notice!',
                    html: `<b class="text-secondary">${message}</b>`,
                    customClass: {
                        confirmButton: 'btn btn-primary waves-effect'
                    }
                });
            }

            const showHidePayment = (payment_option) => {
                if (payment_option == 'installment payment') {
                    changeFirstInitalAmountToPaid();
                    $('#installment-payment-div').show();
                    $('#full-payment-div').hide();
                    $('#payment-type-div').show();
                } else {
                    var selectElement = $('select[name="payment_status"]');
                    // Find and select the "Unpaid" option by value
                    selectElement.find('option[value="pending"]').prop('selected', true);
                    $('.add-payment-btn-ini').prop("disabled", true);
                    $('#full-payment-div').show();
                    $('#installment-payment-div').hide();
                    $('#payment-type-div').hide();
                }
            }

            const setDiscount = (price, discount,discount_type) => {
                if (discount_type) {
                    discount = discount?discount:0;
                    discount_amount = calculateDiscount(price, discount, discount_type);
                    $('[name="total_discount_amount"]').val(discount_amount);
                    $('[name="total_net_amount"]').val(price-discount_amount);
                    $('[name="payment"]').val(price-discount_amount);
                    $('[name="payments[]"]:first').val(price-discount_amount);
                }
            }

            const calculateDiscount = (price, discount, discount_type) => {
                // console.log(discount_type);
                if (discount_type == "percent") {
                    val = (price / 100) * discount;
                } else {
                    val = discount;
                }
                return val;
            }

            const renderBatchSelect = (course_id,status = 'batch') => {
                html = '<option value="">Select Batch</option>';
                filterBatches(course_id,status).forEach(element => {
                    html += `
                    <option value="${element.id}">${element.name}</option>
                    `;
                });
                return html;
            }

            const renderSubjects    = (course_id) => {
                html = '<h5>Choose Subjects</h5>';
                filterCourseSubjects(course_id).forEach(element => {
                    html += `
                        <div class="d-inline-block me-2">
                            <input type="checkbox" class="form-check-input" name="subjects[]" value="${element.id}" checked>
                            <label class="form-check-label">${element.subject.name}</label>
                        </div>
                    `;
                });
                return html;
            }

            const filterCourse = (course_id) => {
                return courses.filter(course => course_id == course.id);
            }

            const filterCourseSubjects = (course_id) => {
                return course_subjects.filter(subject => course_id == subject.course_id);
            }

            const filterBatches = (course_id,status) => {
                if (status === 'batch') {
                    return batches.filter(batch => course_id == batch.course_id && enrollmentsStudentStatus(batch.enrollments));
                }
                return batches.filter(batch => course_id == batch.course_id);
            }


            const enrollmentsStudentStatus = (enrollments) => {
                // Get the student ID from the form input.
                const studentId = $(`[name="student_id"]`).val();
                // Iterate over the enrollments array.
                for (const enrollment of enrollments) {
                    // Check if the student ID matches the enrollment student ID.
                    if (enrollment.student_id == studentId) {
                    // If the student ID matches, return false.
                        return false;
                    }
                }

                // If the student ID was not found in the enrollments array, return true.
                return true;
            };

            const reset = () => {
                $('[name="total_amount"]').val(0);
                $('[name="total_net_amount"]').val(0);
                $('[name="payment_status"]').val('unpaid');
                $('[name="payment"]').val(0);
                $('[name="payments_status[]"]').val('unpaid');
                $('[name="payments[]"]').val(0);
                $('.remove-btn:not(.disabled)').click();
                $('[name="total_discount_amount"]').val(0);
                // $('[name="payment_option"]').val('full payment');
                if (!$('#full-payment').prop('checked')) {
                    $('#full-payment').prop('checked', true);
                }
                showHidePayment('full payment');
                $('[name="payment_type"]').val('cash');
                $('[name="discount"]').val(0);
                $('[name="discount_type"]').val('');
            }

            setMssRepeater({
                id:'#payment-repeater',
                unselect: true,
                clicked: () => {
                    let time = parseInt($('#time').val(), 10);
                    $('#time').val(time + 1);
                },
                removing:()=>{
                    let time = parseInt($('#time').val(), 10);
                    $('#time').val(time - 1);
                }
            });
        });
    </script>
    <script src="<?php echo e(asset('assets/js/form-handling/enrollment-data-preparation/enrollment-step.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/form-handling/enrollment-data-preparation/payment-and-transition-step.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/enrollments/create.blade.php ENDPATH**/ ?>