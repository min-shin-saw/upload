<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow0 container-p-y">
        <h4 class="fw-bold py-3 mb-4">
                <span class="text-muted fw-light">
                        <?php echo e(__('common-breadcrumb.dashboard')); ?> /
                        <a href="<?php echo e(route('timetables.index')); ?>"><?php echo e(__('admin/breadcrumb/timetable.timetable')); ?></a> /
                        <a
                        href="<?php echo e(route('timetable-formats.index',[
                            'course' => $format->batch->course,
                            'batch'  => $format->batch,
                            'format' => $format->id
                        ])); ?>">
                            <?php echo e($format->batch->course->name); ?>

                        </a>
                        <span>/ <?php echo e($format->batch->name); ?> / format </span> /
                </span>
                <?php echo e(__('common-breadcrumb.create')); ?>

        </h4>
        <div class="card">
            <div class="card-body">
                <form
                  action="<?php echo e(route('timetable-formats.update',$format)); ?>"
                  method="POST"
                  id="format-form"
                >
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <!-- Date Range Section -->
                    <h5 class="text-primary mb-4">Date Range</h5>
                    <div class="d-md-flex gap-2  align-items-center ">
                        <div class="form-floating form-floating-outline col-md-4 col-12">
                            <input
                              type="date"
                              name="start_date"
                              id="start-date"
                              value="<?php echo e($format->start_date); ?>"
                              class="form-control"
                            />
                            <label for="start-date" class="form-label">
                                Start Date
                            </label>
                        </div>

                        <span class="d-none d-md-inline">-</span>

                        <div class="form-floating mt-4 mt-md-0 form-floating-outline col-md-4 col-12">
                            <input
                              type="date"
                              name="end_date"
                              id="end-date"
                              value="<?php echo e($format->end_date); ?>"
                              class="form-control"
                            />
                            <label for="end-date" class="form-label">
                                End Date
                            </label>
                        </div>
                    </div>

                    <!-- Days Section -->
                    <h5 class="text-primary mt-4">Select Days</h5>
                    <div class="d-flex gap-3 flex-wrap">
                        <?php $__currentLoopData = App\Models\School\TimetableFormat::DAYS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex gap-2">
                                <input
                                  name="days[]"
                                  id="<?php echo e($key); ?>"
                                  value="<?php echo e($key); ?>"
                                  <?php if(in_array($key, unserialize($format->days))): echo 'checked'; endif; ?>
                                  type="checkbox"
                                />
                                <label for="<?php echo e($key); ?>">
                                    <?php echo e($value); ?>

                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <!-- Time Range Section -->
                    <h5 class="text-primary my-4"a>Time Range</h5>
                    <div class="d-flex gap-2 align-items-center ">
                        <div class="d-flex form-floating form-floating-outline col-md-4 col-12">
                            <input
                              type="time"
                              name="start_time"
                              id="start-time"
                              value="<?php echo e($format->start_time); ?>"
                              class="form-control"
                            />
                            <label for="start-time" class="form-label">
                                Start Time
                            </label>
                        </div>
                        -
                        <div class="d-flex form-floating form-floating-outline col-md-4 col-12">
                            <input
                              type="time"
                              name="end_time"
                              id="end-time"
                              value="<?php echo e($format->end_time); ?>"
                              class="form-control"
                            />
                            <label for="end-time" class="form-label">
                                End Time
                            </label>
                        </div>
                    </div>

                   <!--  Time Interval -->
                    <div class="mt-4 col-12">
                        <h5 class="text-primary">Time Interval</h5>
                        <div class="d-flex gap-2 ">
                            <input
                              type="number"
                              class="form-control" name="time_interval"
                              min="0"
                              id="interval"
                              value="<?php echo e($format->time_interval); ?>"
                              style="width: 70px;"
                            />
                            <h6 class="mt-2">min</h6>
                        </div>
                    </div>

                    <div id="header-container" class="mt-4 col-12">

                    </div>

                    <div class="d-flex gap-2 justify-content-end mt-3">
                        <a
                        href="<?php echo e(route('timetable-formats.index',[
                                'course' => $format->batch->course,
                                'batch'  => $format->batch,
                                'format' => $format->id
                            ])); ?>"
                        class="btn btn-outline-secondary btn-md"
                        >
                            Back
                        </a>
                        <button class="btn btn-success btn-md" type="submit">
                            Save
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(function () {
        let intervals = <?php echo json_encode($format->timetable_header, 15, 512) ?>;

        function getTimetableHeader() {
            const startTime = $('#start-time').val();
            const endTime   = $('#end-time').val();
            const interval  = $('#interval').val();
            const url       = "<?php echo e(route('timetables.get-header')); ?>";

            if(startTime && endTime && interval) {
                $('#header-container').html(`
                    <div class="spinner-border" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                `);

                let data;

                if (intervals === null) {
                    data = {
                        startTime,
                        endTime,
                        interval
                    }
                } else {
                    data = {
                        intervals: JSON.parse(intervals)
                    }
                }

                $.ajax({
                    type: "get",
                    url: url,
                    data ,
                    success: function (response) {
                        $('#header-container').html(response);
                    }
                });
            }
        }

        getTimetableHeader();

        $('#start-time').change(function (e) {
            e.preventDefault();

            intervals = null;
            getTimetableHeader();
        });

        $('#end-time').change(function (e) {
            e.preventDefault();

            intervals = null;
            getTimetableHeader();
        });

        $('#interval').keyup(function (e) {
            e.preventDefault();

            intervals = null;
            getTimetableHeader();
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/timetables/format-edit.blade.php ENDPATH**/ ?>