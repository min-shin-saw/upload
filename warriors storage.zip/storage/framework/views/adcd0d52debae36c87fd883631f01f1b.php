<?php $__env->startSection('container'); ?>
    <?php
        use App\Models\School\Application;
        $firstRecord = Application::first();
    ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4">Application</h4>

        <div class="row">
            <div class="col-7">
                <div class="card">
                    <div class="card-body">
                        <?php if($firstRecord): ?>
                            <form action="<?php echo e(route('update-application',$firstRecord)); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo method_field('PATCH'); ?>
                                <?php echo csrf_field(); ?>
                                <select name="type" class="mb-4 form-select w-25">
                                    <?php $__currentLoopData = Application::TYPES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php if( $firstRecord->type === $key ): echo 'selected'; endif; ?>>
                                            <?php echo e($value); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div class="form-floating form-floating-outline mb-4">
                                    <input type="text" id="name" class="form-control" placeholder="Enter App Name"
                                    name="name"
                                    value="<?php echo e($firstRecord->name); ?>"
                                    />
                                    <label for="name">App Name</label>
                                </div>
                                <div class="form-floating form-floating-outline mb-4 <?php echo e($firstRecord->type==='upload'?'':'complete-hide'); ?>" id='file'>
                                    <input type="file" accept=".zip" id="file" class="form-control" placeholder="Enter App File"
                                    name="file"
                                    />
                                    <label for="file">App File</label>
                                </div>
                                <div class="<?php echo e($firstRecord->type==='upload'?'complete-hide':''); ?>" id="store-link">
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input type="text" id="play_store_link" class="form-control" placeholder="Enter Play Store Link"
                                        name="play_store_link" value="<?php echo e($firstRecord->play_store_link); ?>"
                                        />
                                        <label for="play_store_link">Enter Play Store Link</label>
                                    </div>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input type="text" id="app_store_link" class="form-control" placeholder="Enter App Store Link"
                                        name="app_store_link" value='<?php echo e($firstRecord->app_store_link); ?>'
                                        />
                                        <label for="app_store_link">Enter App Store Link</label>
                                    </div>
                                </div>
                                <div class="text-end">
                                    <button type="button" class="btn btn-label-linkedin waves-effect" id="submit-btn">
                                        <span class="mdi mdi-update"></span>
                                        Update
                                    </button>
                                </div>
                            </form>
                        <?php else: ?>
                            <form method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <select name="type" class="mb-4 form-select w-25">
                                    <?php $__currentLoopData = Application::TYPES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>">
                                            <?php echo e($value); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div class="form-floating form-floating-outline mb-4">
                                    <input type="text" id="name" class="form-control" placeholder="Enter App Name"
                                    name="name"
                                    />
                                    <label for="name">App Name</label>
                                </div>
                                <div class="form-floating form-floating-outline mb-4" id='file'>
                                    <input type="file" accept=".zip" id="file" class="form-control" placeholder="Enter App File"
                                    name="file"
                                    />
                                    <label for="file">App File</label>
                                </div>
                                <div class="complete-hide" id="store-link">
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input type="text" id="play_store_link" class="form-control" placeholder="Enter Play Store Link"
                                        name="play_store_link"
                                        />
                                        <label for="play_store_link">Enter Play Store Link</label>
                                    </div>
                                    <div class="form-floating form-floating-outline mb-4">
                                        <input type="text" id="app_store_link" class="form-control" placeholder="Enter App Store Link"
                                        name="app_store_link"
                                        />
                                        <label for="app_store_link">Enter App Store Link</label>
                                    </div>
                                </div>
                                <div class="text-end">
                                    <button type="button" class="btn btn-label-linkedin waves-effect" id="submit-btn">
                                        <span class="mdi mdi-cloud-upload-outline me-2"></span>
                                        Upload
                                    </button>
                                </div>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php if($firstRecord): ?>
                <div class="col-5">
                    <div class="card">
                        <div class="card-body">
                            <div>
                                <h6>App Name</h6>
                                <p><?php echo e($firstRecord->name); ?></p>

                                <?php if($firstRecord->type === 'upload'): ?>
                                    <a href="<?php echo e(get_file($firstRecord->file)); ?>">
                                        Download
                                    </a>
                                <?php else: ?>

                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(function () {
            let keys = [
                'name', 'file'
            ];
            let rules = {
                name: 'required',
                file: "<?php echo e(isset($firstRecord)); ?>"?'':'required',
            };
            $('[name="type"]').change(function (e) {
                e.preventDefault();
                if ($(this).val() == 'upload') {
                    if(!$('#store-link').hasClass('complete-hide')){
                        $('#store-link').addClass('complete-hide');
                    }
                    if($('#file').hasClass('complete-hide')) {
                        $('#file').removeClass('complete-hide');
                    }
                    keys = [
                        'name', 'file'
                    ];
                    rules = {
                        name: 'required',
                        file: "<?php echo e(isset($firstRecord)); ?>"?'':'required',
                    };
                } else {
                    if($('#store-link').hasClass('complete-hide')) {
                        $('#store-link').removeClass('complete-hide');
                    }
                    if(!$('#file').hasClass('complete-hide')) {
                        $('#file').addClass('complete-hide')
                    };
                    keys = [
                        'name', 'play_store_link', 'app_store_link'
                    ];
                    rules = {
                        name: 'required',
                        play_store_link:'nullable',
                        app_store_link:'nullable',
                    };
                }
            });

            $('#submit-btn').click(function (e) {
                e.preventDefault();
                validateNew({
                    keys: keys,
                    rules: rules,
                    submit: true,
                    fileValidate: false
                })
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/applications/index.blade.php ENDPATH**/ ?>