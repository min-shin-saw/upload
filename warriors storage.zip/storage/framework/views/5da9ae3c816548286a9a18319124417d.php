<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('admin/breadcrumb/student-setting.admin_student_setting')); ?></span></h4>
        <div class="row">
            <div class="col-8">
                <div class="card">
                    <h5 class="card-header mb-3 text-primary"><?php echo e(__("admin/admin-student-setting.student_settings_edit")); ?></h5>
                    <div class="card-body">
                        <form action="<?php echo e(route('student-settings.update')); ?>" enctype="multipart/form-data" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-floating form-floating-outline mb-4">
                                <input type="text" id="name" class="form-control" placeholder="<?php echo e(__("admin/admin-student-setting.enter_student_code_prefix")); ?>"
                                    name="student_code_prefix"
                                    value="<?php echo e(isset($prefix)?$prefix->value:'---'); ?>"
                                    />
                                <label for="name"><?php echo e(__('admin/admin-student-setting.student_code_prefix')); ?></label>
                            </div>

                            <div>
                                <button type="submit" id="profile_update" class="btn btn-primary btn-sm">
                                    <?php echo e(__("admin/admin-student-setting.save")); ?>

                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php
    class StudentSettingRequest {

        function rules(): array {
            return [
                'student_code_prefix' => 'required',
            ];
        }

        function messages(): array {
            return [
                'student_code_prefix.required' => 'Student Code Prefix is required',
            ];
        }
    }
?>

<?php $__env->startSection('script'); ?>
    <?php echo MssValidation::script([
            'request'   => new StudentSettingRequest(),
    ]); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/student-settings/index.blade.php ENDPATH**/ ?>