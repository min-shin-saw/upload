<div>           
    <div class="form-floating form-floating-outline mb-4">
        <input name="name" value="<?php echo e(isset($transactionName)? $transactionName->name:''); ?>" type="text" class="form-control" placeholder="Enter Name">
        <label for=""><?php echo e(__('admin/admin-transactin-name.name')); ?></label>
    </div>

    <div class="form-floating form-floating-outline mb-4">
        <input name="value" value="<?php echo e(isset($transactionName)?(int) $transactionName->value:''); ?>" type="number" class="form-control" placeholder="Enter value">
        <label for=""><?php echo e(__('admin/admin-transactin-name.value')); ?></label>
    </div>

    <div class="mt-3 d-flex justify-content-between">
        <a href="<?php echo e(route('transaction-names.index')); ?>" class="btn btn-outline-secondary">
            <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
            <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('common.back')); ?></span>
        </a>

        <button class="btn btn-primary ms-2"  type="submit">
            <?php echo e(__('common.submit')); ?>

        </button>
    </div>
</div><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/transaction-name/form-partials/form.blade.php ENDPATH**/ ?>