<div>
    <a href="<?php echo e(route('control-settings.edit',$id)); ?>" class="btn btn-sm btn-icon btn-primary waves-effect waves-light">
        <span class="mdi mdi-playlist-edit" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit"></span>
    </a>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/control-settings/action.blade.php ENDPATH**/ ?>