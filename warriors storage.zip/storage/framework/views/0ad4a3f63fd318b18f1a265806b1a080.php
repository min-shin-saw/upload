<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y ">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?> / </span> <?php echo e(__('admin/breadcrumb/lesson-plan.lesson-plan')); ?></h4>
        <div id="teacher-card" class="card">
            <div id="teacher-card-body" class="card-body mt-4 py-1 d-flex  ">
                <img id="teacher-card-image" class="mb-3 me-3" src="<?php echo e($currentTeacher ? $currentTeacher->image : asset('assets/img/user-filler-image.jpg')); ?>" alt="" width="50px" height="50px" style="border-radius:50%">
                <div class="d-flex align-items-center ">
                    <h6 class="me-5 my-auto fw-bold d-flex">Total Assigned Subjects: <p class="fw-normal"><?php echo e($teacherAssignedSubjectsCount ? $teacherAssignedSubjectsCount : "-"); ?></p></h6>     
                    <h6 class="me-5 my-auto fw-bold d-flex">Email: <p class="fw-normal"><?php echo e($currentTeacher ? $currentTeacher->email : "-"); ?></p></h6>     
                    <h6 class="me-5 my-auto fw-bold d-flex">Phone: <p class="fw-normal"><?php echo e($currentTeacher ? $currentTeacher->phone : "-"); ?></p></h6> 
                </div>
            </div>
        </div>
        <div class="table-responsive text-nowrap">
            <?php echo $dataTable->table(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <?php echo e($dataTable->scripts(attributes: ['type' => 'module'])); ?>

    <script type="text/javascript" src="<?php echo e(asset('assets/js/plugin/moment.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/plugin/daterange-picker.min.js')); ?>"></script>


    <script type="module">
        $(document).ready(function() {
            
            addMarginToDataTableBtn();  //add margin to action buttons from Yajra DataTable
            let teachers = <?php echo json_encode($teachers, 15, 512) ?>;
            let assignedSubjects = <?php echo json_encode($assignedSubjects, 15, 512) ?>;
            let onMounted = (fn) => fn(); 
            let firstRow = $('#teacher-card-body').parent().addClass('d-flex');
            let urlParams = new URLSearchParams(window.location.search);
            localStorage.setItem('queryParams', window.location.search);
            // let start = '';
            // let end =  '';

            function setSubjectOptions(teacherId){
                let html = '';
                const addedSubjectIds = new Set(); // To keep track of added subject IDs
                html += '<option value="">All Subjects</option>'

                teachers.map(teacher=>{

                    if(teacher.id == teacherId){
                        assignedSubjects.map(assignedSubject => {
                            if (!addedSubjectIds.has(assignedSubject.subject.id)) { // For filtering duplicate subjects 
                                html += `<option selected value="${assignedSubject.subject.id}">${assignedSubject.subject.name}</option>`
                                addedSubjectIds.add(assignedSubject.subject.id); 
                            }
                        })
                    }

                    if(teacherId == ''){
                        $('#subject-select').val('<option value="">Select Subject</option>');
                    }
                })

                
                $('#subject-select').html(html);
            }

            function setBatchOptions(subjectId){
                let html = '';
                html += '<option value="">All Batches</option>'

                assignedSubjects.map(assignedSubject => { //loop thru assignedSubjects array and get batch's name from relation with assignedSubjects
                    if(assignedSubject.subject_id == subjectId){
                            html += `<option value="${assignedSubject.batch.id}">${assignedSubject.batch.name}</option>`
                    }
                    if(assignedSubject.subject_id == ''){
                        $('#batch-select').val('<option value="">Select Batch</option>');
                    }
                })

                $('#batch-select').html(html);
            }


            // function setDatePicker(startDate , endDate) {
            //     $('input[name="dates"]').addClass('form-control col-4').daterangepicker({
            //         startDate: startDate,
            //         endDate: endDate,
            //         minDate :  moment($('#batch-select option:selected').data('date')),
            //         maxDate : moment(),
            //     });
            // }

            firstRow.prepend(`
                <form class="col-12 pt-3 d-flex" action="<?php echo e(route('lesson-plans.index')); ?>" method="get" >
                    <?php echo csrf_field(); ?>
            
                    <div class="col-md-3 col-sm-3 ms-2 form-floating form-floating-outline">
                        <select name="teacher_id" id="teacher-select" class="form-select select2 subject-select" style="height:43px ;font-size: 0.75rem" >
                            <option value="">Select Teacher</option>
                            ${teachers.map(teacher =>`<option value="${teacher.id}">${teacher.name}</option>` )}
                        </select>
                    </div>
                    <div class="col-md-2 col-sm-1 ms-auto form-floating form-floating-outline">
                        <select name="subject_id" id="subject-select" class="form-select subject-select" style="height:43px ;font-size: 0.75rem" >
                            <option value="">Select Subject</option>
                        </select>
                    </div>
                    <div class="col-md-2 col-sm-1 ms-1 form-floating form-floating-outline">
                        <select name="batch_id" id="batch-select" class="form-select batch-select" style="height:43px ;font-size: 0.75rem" >
                            <option value="">Select Batch</option>
                        </select>
                    </div>
                    <button id="filter" class="btn btn-primary btn-sm ms-1 me-2" style="width:70px">
                        Search
                    </button>
                    
                </form>
            `)

            // $('#select2basic').select2();
            // $('#course-select').select2({
            //     theme: 'bootstrap4',
            // });
           
            if (urlParams.size != 0) {
                // const datesParam = urlParams.get('dates');
                const teacherParam = urlParams.get('teacher_id');
                const subjectParam = urlParams.get('subject_id');
                const batchParam = urlParams.get('batch_id');
                // start = datePart[0];
                // end =  datePart[1];
                $('#teacher-select').val(teacherParam);
                setSubjectOptions(teacherParam);
                $('#subject-select').val(subjectParam);
                setBatchOptions(subjectParam);
                $('#batch-select').val(batchParam);

            }else{
                // start = moment();
                // end = moment();
            }

            $('#teacher-select').on('change', function() {
                setSubjectOptions('');
                setBatchOptions('');
            })

            $('#subject-select').on('change', function() {
                setBatchOptions($(this).val());
            })

            onMounted(()=>{
                // setDatePicker(start,end);
            })
            
            function addMarginToDataTableBtn(){
                $('.dt-buttons').addClass('mt-3');
            }
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/lesson-plans/index.blade.php ENDPATH**/ ?>