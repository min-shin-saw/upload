<?php $__env->startSection('container'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">CMS / </span> Themes-Settings
        </h4>

        <form class="mt-3"
        method="post"
        enctype="multipart/form-data"
        action="<?php echo e(route('settings.update')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <input type="hidden" name="_page" value="themes">
            <div class="card mb-4">
                <div class="card-body">
                    <h5 class="card-title">Themes</h5>
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <label class="form-label text-black">
                                Landing Navigation Logo
                            </label>
                            <input
                            type="file"
                            class="dropify"
                            name="landing-nav-logo"
                            data-default-file="<?php echo e(asset(config('settings.landing-nav-logo'))); ?>"
                            data-allowed-file-extensions='[
                                "png", "PNG", "jpg", "JPG", "jpeg", "JPEG"
                            ]'
                            >
                        </div>

                        <div class="col-md-3 mb-3">
                            <label class="form-label text-black">
                                Teacher Navigation Logo
                            </label>
                            <input
                            type="file"
                            class="dropify teal-color"
                            name="teacher-nav-logo"
                            data-default-file="<?php echo e(asset(config('settings.teacher-nav-logo'))); ?>"
                            data-allowed-file-extensions='[
                                "png", "PNG", "jpg", "JPG", "jpeg", "JPEG"
                            ]'
                            >
                        </div>

                        <div class="col-md-3 mb-3">
                            <label class="form-label text-black">
                                Guardian Navigation Logo
                            </label>
                            <input
                            type="file"
                            class="dropify blue-color"
                            name="guardian-nav-logo"
                            data-default-file="<?php echo e(asset(config('settings.guardian-nav-logo'))); ?>"
                            data-allowed-file-extensions='[
                                "png", "PNG", "jpg", "JPG", "jpeg", "JPEG"
                            ]'
                            >
                        </div>

                        <div class="col-md-3 mb-3">
                            <label class="form-label text-black">
                                Student Navigation Logo
                            </label>
                            <input
                            type="file"
                            class="dropify purple-color"
                            name="student-nav-logo"
                            data-default-file="<?php echo e(asset(config('settings.student-nav-logo'))); ?>"
                            data-allowed-file-extensions='[
                                "png", "PNG", "jpg", "JPG", "jpeg", "JPEG"
                            ]'
                            >
                        </div>

                        <div class="col-md-4 mb-3">
                            <label class="form-label text-black">
                                (Teacher/Default) Auth Logo
                            </label>
                            <input
                            type="file"
                            class="dropify"
                            name="default-auth-logo"
                            data-default-file="<?php echo e(asset(config('settings.default-auth-logo'))); ?>"
                            data-allowed-file-extensions='[
                                "png", "PNG", "jpg", "JPG", "jpeg", "JPEG"
                            ]'
                            >
                        </div>

                        <div class="col-md-4 mb-3">
                            <label class="form-label text-black">
                                Guardian Auth Logo
                            </label>
                            <input
                            type="file"
                            class="dropify"
                            name="guardian-auth-logo"
                            data-default-file="<?php echo e(asset(config('settings.guardian-auth-logo'))); ?>"
                            data-allowed-file-extensions='[
                                "png", "PNG", "jpg", "JPG", "jpeg", "JPEG"
                            ]'
                            >
                        </div>

                        <div class="col-md-4 mb-3">
                            <label class="form-label text-black">
                                Student Auth Logo
                            </label>
                            <input
                            type="file"
                            class="dropify"
                            name="student-auth-logo"
                            data-default-file="<?php echo e(asset(config('settings.student-auth-logo'))); ?>"
                            data-allowed-file-extensions='[
                                "png", "PNG", "jpg", "JPG", "jpeg", "JPEG"
                            ]'
                            >
                        </div>
                    </div>
                    <div class="text-end">
                        <button class="btn btn-primary btn-sm">Save</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/dropify/dropify.min.js')); ?>"></script>

    <script>
        $(function () {
            $('.dropify').dropify();
        });
    </script>

    <!-- Setting for different color themes -->
    <script>
        $(function () {
            const diffColorDropifies = [
                'teal-color',
                'blue-color',
                'purple-color'
            ];

            const colorMapping = {
                'teal-color': '#2CB5B3',
                'blue-color': '#3d64a4',
                'purple-color': '#b601ff'
            };

            for (const colorDiv of diffColorDropifies) {
                const dropify = $(`.${colorDiv}`);
                const color = colorMapping[colorDiv];

                dropify.parent()
                    .find('.dropify-preview')
                    .add(
                        dropify.parent()
                        .find('.dropify-render')
                        .children()
                    )
                    .css("background-color", color);
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dropify/dropify.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/CMS/themes/index.blade.php ENDPATH**/ ?>