<?php $__env->startSection('container'); ?>
    <div class="col-12">
        <h4 class="fw-bold py-3"><span class="text-muted fw-light"><?php echo e(__('common-breadcrumb.admin')); ?> / </span> <?php echo e(__('admin/chat-logs/breadcrumb.chat_logs')); ?></h4>
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <select id="select2Basic_course" class="select2 form-select form-select-lg" name="course_id">
                            <option value="">Select Course</option>
                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($course->id); ?>"><?php echo e($course->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <select id="select2Basic_batch" class="select2 form-select form-select-lg" name="batch_id">
                            <option value="">Select Batch</option>
                        </select>
                    </div>
                </div>
                <div class="row pt-3">
                    <div class="col-md-3">
                        <div class="row pb-3">
                            <div class="flex-grow-1 input-group input-group-merge rounded-pill">
                              <span class="input-group-text" ><i class="mdi mdi-magnify lh-1"></i></span>
                              <input type="text" id="searchInput" class="form-control chat-search-input" onkeyup="searchList()" placeholder="<?php echo e(__('admin/chat-logs/common.search')); ?>" aria-label="<?php echo e(__('admin/chat-logs/common.search')); ?>" aria-describedby="basic-addon-search31">
                            </div>
                        </div>
                        <ul id="list-rooms" class="list-group" style="max-height: 500px; overflow-y: auto;">
                        </ul>
                    </div>
                    <div class="col-md-9" id="chat-log">
                        <div class="row">
                            <div class="col-md-12">
                                <h4 id="title">Title</h4>
                                <span id="total-members" class="text-muted"></span>
                            </div>
                        </div>
                        <div class="row px-3 position-relative" id="content" style="background-color: #f8f8f8; border: 1px solid #d4d4d6; overflow-y: auto; min-height: 300px; max-height: 400px;">
                            <!-- Content will be dynamically added here -->
                            <div class="d-flex justify-content-end p-2 align-items-start position-sticky top-0 start-0">
                                <div class="btn-group " role="group" aria-label="Button group with nested dropdown">
                                    <button 
                                        title="Refresh"
                                        id="refresh-btn"
                                        type="button" 
                                        class="btn btn-primary">
                                        <svg 
                                            xmlns="http://www.w3.org/2000/svg" 
                                            height="24px" 
                                            viewBox="0 -960 960 960" 
                                            width="24px" 
                                            fill="#ffffff"
                                        >
                                            <path d="M204-318q-22-38-33-78t-11-82q0-134 93-228t227-94h7l-64-64 56-56 160 160-160 160-56-56 64-64h-7q-100 0-170 70.5T240-478q0 26 6 51t18 49l-60 60ZM481-40 321-200l160-160 56 56-64 64h7q100 0 170-70.5T720-482q0-26-6-51t-18-49l60-60q22 38 33 78t11 82q0 134-93 228t-227 94h-7l64 64-56 56Z"/>
                                        </svg>
                                    </button>
                                    <button 
                                        title="Fullscreen"
                                        id="fullscreen-btn"
                                        type="button" 
                                        class="btn btn-primary"
                                    >
                                        <svg 
                                            xmlns="http://www.w3.org/2000/svg" 
                                            height="24px" 
                                            viewBox="0 -960 960 960" 
                                            width="24px" 
                                            fill="#ffffff"
                                        >
                                            <path d="M120-120v-200h80v120h120v80H120Zm520 0v-80h120v-120h80v200H640ZM120-640v-200h200v80H200v120h-80Zm640 0v-120H640v-80h200v200h-80Z"/>
                                        </svg>
                                    </button>
                                    <button 
                                        title="Screenshot"
                                        id="screenshot-btn"
                                        type="button" 
                                        class="btn btn-primary"
                                    >
                                        <svg 
                                            xmlns="http://www.w3.org/2000/svg" 
                                            height="24px" 
                                            viewBox="0 -960 960 960" 
                                            width="24px" 
                                            fill="#ffffff"
                                        >
                                            <path d="M480-280v-60h100v-100h60v160H480ZM320-520v-160h160v60H380v100h-60ZM280-40q-33 0-56.5-23.5T200-120v-720q0-33 23.5-56.5T280-920h400q33 0 56.5 23.5T760-840v720q0 33-23.5 56.5T680-40H280Zm0-120v40h400v-40H280Zm0-80h400v-480H280v480Zm0-560h400v-40H280v40Zm0 0v-40 40Zm0 640v40-40Z"/>
                                        </svg>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    let messagesArr = [];
    let currentRoomId = '';
    let totalPages = 0;
    let currentPage = 1;

    $(document).ready(function() {
        var htmlTag = $(':root');
        if(!htmlTag.hasClass('layout-menu-collapsed'))
        {
            htmlTag.addClass('layout-menu-collapsed');
        }
        $('[data-toggle="tooltip"]').tooltip();

        $('#select2Basic_course').select2({
            placeholder: "<?php echo e(__('admin/chat-logs/common.select_course')); ?>",
            allowClear: true
        });

        $('#select2Basic_batch').select2({
            placeholder: "<?php echo e(__('admin/chat-logs/common.select_batch')); ?>",
            allowClear: true
        });

        $('#select2Basic_course').on('change', function() {
            getBatchList($(this).val());
        });

        $('#select2Basic_batch').on('change', function() {
            getRoomsList($(this).val());
        });

        $('#refresh-btn').on('click', function() {
            if(currentRoomId != '') {
                resetDefault();
                getMessagesList(currentRoomId);
                scrollToBottom();
            }
            else
            {
                Swal.fire({
                    title: 'Oops!',
                    text: 'Please select a room!',
                    icon: 'error',
                    customClass: {
                      confirmButton: 'btn btn-primary waves-effect waves-light'
                    },
                    buttonsStyling: false
                });
            }
        });

        $('#fullscreen-btn').on('click', function() {
            if($('#fullscreen-btn').data('mode') == 'full-screen')
            {
                $('#content').removeClass('position-relative');
                $('#content').addClass('position-fixed');
                $('#content').removeClass('px-3');
                $('#content').addClass('px-5');
                $('#content').css('width', '100vw');
                $('#content').css('height', '100vh');
                $('#content').css('top', '0');
                $('#content').css('left', '0');
                $('#content').css('z-index', '10000');
                $('#content').css('min-height', '');
                $('#content').css('max-height', '');
                $('#fullscreen-btn').html(`
                    <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#FFFFFF">
                        <path d="M240-120v-120H120v-80h200v200h-80Zm400 0v-200h200v80H720v120h-80ZM120-640v-80h120v-120h80v200H120Zm520 0v-200h80v120h120v80H640Z"/>
                    </svg>
                `).attr('title','Exit Full Screen').data('mode','exit-full-screen');
            }
            else
            {
                $('#content').removeClass('position-fixed');
                $('#content').addClass('position-relative');
                $('#content').removeClass('px-5');
                $('#content').addClass('px-3');
                $('#content').css('width', 'auto');
                $('#content').css('height', 'auto');
                $('#content').css('top', '');
                $('#content').css('left', '');
                $('#content').css('z-index', '');
                $('#content').css('min-height', '300px');
                $('#content').css('max-height', '400px');
                $('#fullscreen-btn').html(`
                    <svg 
                        xmlns="http://www.w3.org/2000/svg" 
                        height="24px" 
                        viewBox="0 -960 960 960" 
                        width="24px" 
                        fill="#ffffff"
                    >
                        <path d="M120-120v-200h80v120h120v80H120Zm520 0v-80h120v-120h80v200H640ZM120-640v-200h200v80H200v120h-80Zm640 0v-120H640v-80h200v200h-80Z"/>
                    </svg>
                `).attr('title','Full Screen').data('mode','full-screen');
            }
        });

        $('#screenshot-btn').on('click', function() {
            html2canvas(document.querySelector("#content"), {
                allowTaint: false,
                useCORS: true
            }).then(canvas => {
                var link = document.createElement('a');
                link.download = 'chatlog_screenshot_' + Date.now() + '.png';
                link.href = canvas.toDataURL('image/png');
                link.click();
            });
        });

        $('#content').on('scroll', function() {
            if($(this).scrollTop() === 0 && currentPage < totalPages) {
                currentPage++;
                getMoreMessages(currentRoomId, currentPage);
            }
        });
    });

    async function getBatchList (courseId) {
        try {
            const response = await fetch('<?php echo e(route('chat-logs.batches')); ?>?course_id=' + courseId, {
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                }
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const res = await response.json();
            bindBatchList(res.data);
        } catch (error) {
            console.error('Error fetching batches : ', error);
        }
    }

    function bindBatchList(batches) {
        $('#select2Basic_batch').empty();
        $('#select2Basic_batch').append('<option value="">Select Batch</option>');
        batches.forEach(element => {
            $('#select2Basic_batch').append('<option value="' + element.id + '">' + element.name + '</option>');
        });
    }

    function searchList() {
        var input, filter, ul, li, a, i, txtValue;
        input = document.getElementById("searchInput");
        filter = input.value.toUpperCase();
        ul = document.getElementById("list-rooms");
        li = ul.getElementsByTagName("li");
        for (i = 0; i < li.length; i++) {
            txtValue = li[i].textContent || li[i].innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                li[i].classList.add('d-flex');
                li[i].style.display = "";
            } else {
                li[i].classList.remove('d-flex');
                li[i].style.display = "none";
            }
        }
    }

    async function getRoomsList(batchId) {
        try {
            const response = await fetch('<?php echo e(route('chat-logs.rooms')); ?>?batch_id=' + batchId, {
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                }
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const res = await response.json();
            bindRoomsList(res.data);
        } catch (error) {
            console.error('Error fetching rooms : ', error);
        }
    }

    function bindRoomsList(rooms) {
        var list = document.getElementById('list-rooms');
        list.innerHTML = '';
        rooms.forEach(element => {
            var li = document.createElement('li');
            li.classList.add('list-group-item');
            li.classList.add('list-group-item-action');
            li.classList.add('list-group-item-primary');
            li.classList.add('d-flex');
            li.classList.add('align-items-center');
            li.classList.add('cursor-pointer');
            li.onclick = function() {
                
                resetDefault();
                getMessagesList(element.id);
                currentRoomId = element.id;
                $('#title').html(element.name + ' <span class="text-muted float-end"><?php echo e(__('admin/chat-logs/common.total_members')); ?>: ' + element.member_count + '</span>');
                scrollToBottom();
            };
            li.id = `li-${element.id}`
            li.innerHTML = `${ shortenString(element.name, 30) }`;
            li.setAttribute('data-toggle', 'tooltip');
            li.setAttribute('data-placement', 'top');
            li.setAttribute('title', `${element.name}`);
            list.appendChild(li);
        });
    }

    async function getMessagesList(roomId) {
        try {
            const response = await fetch('<?php echo e(route('chat-logs.messages')); ?>?chat_room_id=' + roomId + '&page=1', {
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                }
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            const res = await response.json();
            totalPages = res.metadata.last_page;
            bindMessagesList(res.data);
        } catch (error) {
            console.error('Error fetching messages : ', error);
        }
    }

    function bindMessagesList(messages) {
        messages.reverse().forEach(element => {
            messagesArr.push(element);
        });
        messagesArr.forEach(message => {
            addMessage(message);
        })
    }

    function addMessage(message) {
        var content = document.getElementById('content');

        var newDiv = document.createElement('div');
        newDiv.classList.add('row');
        newDiv.classList.add('px-3');
        newDiv.classList.add('py-2');
        newDiv.classList.add('chat-data');

        var del_mark = '';
        var messageData = '';

        if(message.is_deleted == 1) {
            del_mark = '<span class="mdi mdi-trash-can-outline text-danger"></span>';
            messageData = message.message.replace(/<[^>]+>/g, '') + ' <span><bold><small class="font-weight-bold">[Deleted Message!]</small></bold></span>';
        } else {
            messageData = message.message.replace(/<[^>]+>/g, '')
        }

        var msg = `
            <div class="col-md-8">
                <div class="card">
                    <div class="px-3 py-3">
                        <div class="card-title">
                            <img class="rounded-circle" width="40" height="40" src="${message.avatar}" alt="Avatar">
                            <span class="mx-3 h6 ${message.user_type === 'teacher' ? 'text-danger' : message.user_type ? 'text-success' : 'text-secondary'}">${message.sender_name ? message.sender_name : 'Unknown user'} 
                                ${
                                    message.user_type ? 
                                    `
                                        <span class="badge rounded-pill pl-2 ${message.user_type === 'teacher' ? 'bg-danger' : 'bg-success'}"><small>${message.user_type.toUpperCase()}</small></span> 
                                    `
                                    : ''
                                }
                                ${del_mark}
                                <span class="text-muted float-end"><small>${message.date_time}</small></span>
                            </span>
                        </div>
                        <p class="card-text mb-0 ${message.is_deleted === 1 ? 'text-danger' : ''}">${messageData}</p>
                    </div>
                </div>
            </div>
        `;


        content.appendChild(newDiv).innerHTML = msg;
    }

    function scrollToBottom() {
        var content = document.getElementById('content');
        content.scrollTop = content.scrollHeight;
    }

    function shortenString(inputString, maxLength) {
        if (inputString.length > maxLength) {
            return inputString.substring(0, maxLength - 3) + '...';
        }
        return inputString;
    }

    function resetDefault() {
        var chatDataDivs = document.getElementsByClassName('chat-data');
        if(chatDataDivs.length > 0) {
            while(chatDataDivs.length > 0) {
                chatDataDivs[0].remove();
            }
        }
        messagesArr = [];
        totalPages = 0;
        currentPage = 1;
    }

    async function getMoreMessages(roomid, page) {
        try {
            const response = await fetch('<?php echo e(route('chat-logs.messages')); ?>?chat_room_id=' + roomid + '&page=' + page, {
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                }
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            const res = await response.json();
            currentPage = res.metadata.current_page;
            bindMoreMessagesList(res.data);
        } catch (error) {
            console.error('Error fetching messages : ', error);
        }
    }

    function bindMoreMessagesList(messages) {
        let tempMsgArr = [];
        messages.reverse().forEach(element => {
            tempMsgArr.push(element);
        });
        messagesArr = [...tempMsgArr, ...messagesArr];

        var chatdataDivs = document.getElementsByClassName('chat-data');
        if(chatdataDivs.length > 0) {
            while(chatdataDivs.length > 0) {
                chatdataDivs[0].remove();
            }
        }

        messagesArr.forEach(element => {
            addMessage(element);
        })
    }


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/chat-logs/index.blade.php ENDPATH**/ ?>