<?php $__env->startSection('container'); ?>
    <div class="col-12">
        <h4 class="fw-bold py-3 mb-4">
            <span class="text-muted fw-light">
                Dashboard /
                <a href="<?php echo e(route('announcements.index')); ?>">
                    School Announcement
                </a> /
            </span>
            Create
        </h4>

        <div class="card p-4">
            <h5 class="card-header">Announcement Create</h5>

            <div class="card-body">
                <form
                method="POST"
                enctype="multipart/form-data"
                action="<?php echo e(route('announcements.store')); ?>"
                >
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-floating form-floating-outline mb-4">
                                <input
                                name="title"
                                type="text"
                                class="form-control"
                                id="title"
                                placeholder="title"
                                required
                                >
                                <label for="title">Announcement Title</label>
                            </div>
                        </div>

                        <div class="col-md-8">
                            <div class="row">
                                <div class="col-7">
                                    <div class="form-floating form-floating-outline">
                                        <select
                                        id="to-users"
                                        name="to_users"
                                        class="form-select form-select-lg overflow-auto mb-4"
                                        >
                                            <optgroup label="--Select Without Batch--">
                                                <option value="1">All Users (Teacher, Student, Guardian)</option>
                                                <option value="2">All Teachers</option>
                                                <option value="3">All Students</option>
                                                <option value="4">All Guardians</option>
                                                <option value="5">All Teachers, Students</option>
                                                <option value="6">All Teachers, Guardians</option>
                                                <option value="7">All Students and their Guardian</option>
                                            </optgroup>
                                            <optgroup label="--Select With Batch--">
                                                <option value="8">All Users (Teacher, Student, Guardian)</option>
                                                <option value="9">All Teachers</option>
                                                <option value="10">All Students</option>
                                                <option value="11">All Guardians</option>
                                                <option value="12">All Teachers, Students</option>
                                                <option value="13">All Teachers, Guardians</option>
                                                <option value="14">All Students and their Guardian</option>
                                            </optgroup>
                                        </select>
                                        <label for="to-users">To</label>
                                    </div>
                                </div>

                                <div class="col-5">
                                    <div class="form-floating form-floating-outline">
                                        <select
                                          id="select2Basic"
                                          class="select2 form-select form-select-lg"
                                          name="batch_id"
                                          >
                                            <option value="" selected>
                                                <?php echo e(__('--Select Batch--')); ?>

                                            </option>
                                            <?php $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($batch->id); ?>"
                                                >
                                                <?php echo e($batch->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <label for="select2Basic"><?php echo e(__('Batch')); ?></label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 mb-4">
                            <h5>
                                <?php echo e(__('admin/admin-lesson.description')); ?>

                            </h5>

                            <textarea
                            name="description"
                            class="form-control"
                            id="description"
                            placeholder="Enter Description"></textarea>
                        </div>

                        <div>
                            <h5 class="">Files</h5>

                            <div id="file-repeater" class="row">
                                <div class="col-md-3 mb-3">
                                    <input
                                    type="file"
                                    name="contents[]"
                                    class="dropify"
                                    >
                                    <div class="mt-3 d-flex align-items-center mb-0">
                                        <button
                                        type="button"
                                        id="repeater-add-btn"
                                        class="btn btn-label-success waves-effect"
                                        >
                                            <i class="mdi mdi-plus me-1"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="mt-3 d-flex justify-content-between">
                        <a href="<?php echo e(route('announcements.index')); ?>" class="btn btn-outline-secondary">
                            <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
                            <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('common.back')); ?></span>
                        </a>
                        <button
                        class="btn btn-primary ms-2 d-none"
                        id="load-btn"
                        type="button"
                        >
                            <span class="spinner-border me-1" role="status" aria-hidden="true"></span>
                            Processing...
                        </button>
                        <button class="btn btn-primary ms-2" id="submit-btn" type="button">
                            Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/dropify/dropify.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/tinymce/tinymce.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/mss-repeater/mss-repeater.js')); ?>"></script>

<script>
    $(function () {
        $('.dropify').dropify();

        tinymce.init({
            selector: '#description',
        });

        $('#repeater-add-btn').click(function (e) {
            e.preventDefault();

            $('#file-repeater').append(`
                <div class="col-md-3 mb-3">
                    <input
                    type="file"
                    name="contents[]"
                    class="dropify"
                    >
                    <div class="mt-3 d-flex align-items-center mb-0">
                        <button
                        type="button"
                        class="btn btn-label-danger waves-effect repeater-del"
                        >
                            <i class="mdi mdi-close me-1"></i>
                        </button>
                    </div>
                </div>
            `);

            $('.dropify').dropify();

            $('.repeater-del').click(function (e) {
                e.preventDefault();

                $($(this).parent().parent()).remove();
            });
        });
    });
</script>

<script>
    $(function () {
        $('#select2Basic').select2();

        $('#select2Basic').prop('disabled', true);

        $('#to-users').on('change', function () {
            if (this.value == null || this.value == 1 || this.value == 2 || this.value == 3 || this.value == 4 || this.value == 5 || this.value == 6 || this.value == 7) {
                $('#select2Basic').prop('disabled', true);
            } else {
                $('#select2Basic').prop('disabled', false);
            }
        });
    });
</script>
<script>
    $(function() {
        const submitBtn = $("#submit-btn");

        const keys = [
            'title',
            'description',
            'to_users',
            'batch_id',
        ];

        const rules = {
            batch_id : "nullable",
            to_users : "required",
            description : "nullable",
            title : "required|string|max:255",
        };
        const messages = {
            batch_id: 'Announcement Message Title is required!',
            to_users: 'Announcement Message Title should not be more than 255 letters!',
            description: 'Announcement Message Body is required!',
            title: 'Please select at least one user type!',
        };

        submitBtn.click(function(e) {
            e.preventDefault();
            validateNew({
                keys   : keys,
                rules  : rules,
                fileValidate: true
            }).then(() => {
                if (!submitBtn.hasClass("d-none")) submitBtn.addClass('d-none');
                if ($('#load-btn').hasClass('d-none')) $('#load-btn').removeClass('d-none');
                $("form").submit();
            })
        })
    })
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dropify/dropify.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/announcements/create.blade.php ENDPATH**/ ?>