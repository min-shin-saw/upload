<div class="row">
    <div class="col-md-6 mb-4">
        <div class="form-floating form-floating-outline mb-4">
            <input type="text" id="name" class="form-control" placeholder="Enter Course Name"
                name="name"
                value="<?php echo e(isset($course)?$course->name:''); ?>"
                />
            <label for="name"><?php echo e(__('admin/admin-course.course_name')); ?></label>
        </div>

        <div class="form-floating form-floating-outline ">
            <textarea
            name="description"
            class="form-control h-px-120"
            id="description"
            placeholder="Enter Description"><?php echo e(isset($course)?$course->description:''); ?></textarea>
            <label for="exampleFormControlTextarea1"><?php echo e(__('admin/admin-course.description')); ?></label>
        </div>
    </div>

    <div class="col-md-6">
        <label class="form-label text-black">
            <?php echo e(__('admin/admin-course.course_image')); ?>

        </label>
        <input
        type="file"
        name="image"
        class="dropify"
        data-default-file="<?php echo e(isset($course)?get_file($course->image):''); ?>"
        data-allowed-file-extensions='[
            "png", "PNG", "jpg", "JPG", "jpeg", "JPEG"
        ]'
        >
    </div>

    <div class="col-12">
        <div id="subject-repeater">
            <?php if(isset($course) && $course->subjects->count() > 0): ?>
                <input type="hidden" id="selectedArr" value="<?php echo e($course->subjects->pluck('id')); ?>">
                <?php $__currentLoopData = $course->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courseSubject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="repeater-item">
                        <div class="row">
                            <div class="mb-3 mt-3 col-md-3 mb-0">
                                <div class="form-floating form-floating-outline">
                                    <select name="subjects[]" class="form-select select2 subject-select" data-old-value="<?php echo e($courseSubject->id); ?>">
                                        <option value=""><?php echo e(__('admin/admin-course.select_subject')); ?></option>
                                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($subject->id); ?>" <?php if($courseSubject->id == $subject->id): echo 'selected'; endif; ?>>
                                                <?php echo e($subject->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <label for="attended_class"><?php echo e(__('admin/admin-course.select_subject')); ?></label>
                                </div>
                            </div>
                            <div class="mb-3 mt-3 col-md-3 mb-0">
                                <div class="form-floating form-floating-outline">
                                    <input
                                    type="text"
                                    class="form-control price-input"
                                    placeholder="0"
                                    value="<?php echo e($courseSubject->price); ?>"
                                    readonly
                                    />
                                    <label for="attended_class_date"><?php echo e(__('admin/admin-course.subject_price')); ?></label>
                                </div>
                            </div>
                            <div class="mb-3 mt-3 col-md-1 mb-0">
                                <img height="45" src="<?php echo e($courseSubject->image); ?>">
                            </div>
                            <div class="mb-3 mt-3 col-md-3 d-flex align-items-center mb-0">
                                <button type="button" class="btn btn-label-danger waves-effect me-1 remove-btn">
                                    <i class="mdi mdi-close me-1"></i>
                                </button>
                                <button type="button" class="btn btn-label-success waves-effect repeater-add-btn">
                                    <i class="mdi mdi-plus me-1"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="repeater-item">
                    <div class="row">
                        <div class="mb-3 mt-3 col-md-3 mb-0">
                            <div class="form-floating form-floating-outline">
                                <select name="subjects[]" class="form-select select2 subject-select">
                                    <option value=""><?php echo e(__('admin/admin-course.select_subject')); ?></option>
                                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($subject->id); ?>">
                                            <?php echo e($subject->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label for="attended_class"><?php echo e(__('admin/admin-course.select_subject')); ?></label>
                            </div>
                        </div>
                        <div class="mb-3 mt-3 col-md-3 mb-0">
                            <div class="form-floating form-floating-outline">
                                <input
                                type="text"
                                class="form-control price-input"
                                placeholder="0"
                                readonly
                                />
                                <label for="attended_class_date"><?php echo e(__('admin/admin-course.subject_price')); ?></label>
                            </div>
                        </div>
                        <div class="mb-3 mt-3 col-md-1 mb-0">
                            <img height="45" src="<?php echo e(asset('assets/img/placeholders/course-subject-placeholder.png')); ?>" alt="">
                        </div>
                        <div class="mb-3 mt-3 col-md-3 d-flex align-items-center mb-0">
                            <button type="button" class="btn btn-label-danger waves-effect me-1 remove-btn">
                                <i class="mdi mdi-close me-1"></i>
                            </button>
                            <button type="button" class="btn btn-label-success waves-effect repeater-add-btn">
                                <i class="mdi mdi-plus me-1"></i>
                            </button>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-12">
        <div class="row">
            <div class="col-md-3 ">
                <div class="pt-3 align-items-center">
                    <h6><?php echo e(__('admin/admin-course.total_subjects_price')); ?></h6>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-floating form-floating-outline">
                    <input type="text" class="form-control" placeholder="Enter Course Price"
                        name="price"
                        value="<?php echo e(isset($course)?$course->price:''); ?>"
                        />
                    <label for="price"><?php echo e(__('admin/admin-course.course_price')); ?></label>
                </div>
            </div>
            <?php if(!isset($course)): ?>
            <div class="col-md-4">
                <div class="form-group mb-3">
                   <label>
                    Is Custom
                    </label> <br>
                   <input
                   type="checkbox"
                   name="is_custom"
                   class="switchery"
                   value="true"
                   />
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<div class="mt-3 d-flex justify-content-between">
    <a href="<?php echo e(route('courses.index')); ?>" class="btn btn-outline-secondary">
        <i class="mdi mdi-arrow-left me-sm-1 me-0"></i>
        <span class="align-middle d-sm-inline-block d-none"><?php echo e(__('common.back')); ?></span>
    </a>
    <button
    class="btn btn-primary ms-2 d-none"
    id="load-btn"
    type="button"
    >
        <span class="spinner-border me-1" role="status" aria-hidden="true"></span>
        Processing...
    </button>
    <button class="btn btn-primary ms-2" id="submit-btn" type="button">
        <?php echo e(__('common.submit')); ?>

    </button>
</div>
<?php /**PATH /Newdata/vhosts.bak/warriorsedu.com/admin.warriorsedu.com/resources/views/admin/courses/form-partials/form.blade.php ENDPATH**/ ?>